package com.surveytest.agent

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.surveytest.agent.core.DataGen
import com.surveytest.agent.core.Dataset
import com.surveytest.agent.core.parseRange
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var txtService: TextView
    private lateinit var txtKobo: TextView
    private lateinit var txtData: TextView
    private lateinit var edForm: EditText
    private lateinit var edRange: EditText
    private lateinit var rgSpeed: RadioGroup
    private lateinit var cbMdy: CheckBox

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { importFile(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        txtService = findViewById(R.id.txtService); txtKobo = findViewById(R.id.txtKobo); txtData = findViewById(R.id.txtData)
        edForm = findViewById(R.id.edForm); edRange = findViewById(R.id.edRange); rgSpeed = findViewById(R.id.rgSpeed); cbMdy = findViewById(R.id.cbMdy)

        edRange.setText(AppStore.get(this, "range", "1"))
        rgSpeed.check(when (AppStore.get(this, "speed", "normal")) { "fast" -> R.id.spFast; "slow" -> R.id.spSlow; else -> R.id.spNormal })
        cbMdy.isChecked = AppStore.get(this, "dateOrder", "dmy") == "mdy"

        findViewById<Button>(R.id.btnA11y).setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        findViewById<Button>(R.id.btnAppInfo).setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
        }
        findViewById<Button>(R.id.btnGenerate).setOnClickListener { generate() }
        findViewById<Button>(R.id.btnImport).setOnClickListener { pickFile.launch(arrayOf("*/*")) }
        findViewById<Button>(R.id.btnPreview).setOnClickListener { preview() }
        findViewById<Button>(R.id.btnStart).setOnClickListener { startRun() }
        findViewById<Button>(R.id.btnLog).setOnClickListener { showText("Log (latest at the bottom)", AppStore.logTail(this), scrollToEnd = true) }
        findViewById<Button>(R.id.btnShare).setOnClickListener { shareReport() }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            AlertDialog.Builder(this).setMessage("Clear the log and snapshots?").setPositiveButton("Clear") { _, _ -> AppStore.clearLog(this); toast("Log cleared") }
                .setNegativeButton("Cancel", null).show()
        }
        findViewById<Button>(R.id.btnRules).setOnClickListener { startActivity(Intent(this, RulesActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        if (!edForm.hasFocus()) edForm.setText(AppStore.rules(this).formName)
        refresh()
    }

    private fun refresh() {
        val on = AgentService.instance != null
        txtService.text = if (on) "✅ Agent is ON (Accessibility)" else "❌ Agent is OFF — tap the button below, find Kobo Test Agent, switch it on"
        val rules = AppStore.rules(this)
        val kobo = packageManager.getLaunchIntentForPackage(rules.packageName) != null
        txtKobo.text = if (kobo) "✅ KoboCollect found (${rules.packageName})" else "❌ ${rules.packageName} is not installed"
        val d = AppStore.dataset(this)
        txtData.text = if (d == null) "No test data yet. Generate or import." else "✅ ${d.records.size} records, ${d.appliances.size} appliance rows (${d.source})"
    }

    private fun generate() {
        val n = findViewById<EditText>(R.id.edCount).text.toString().toIntOrNull()?.coerceIn(1, 1000) ?: return toast("Type how many records")
        val seed = findViewById<EditText>(R.id.edSeed).text.toString().toLongOrNull() ?: 1L
        val d = DataGen(seed).generate(n)
        AppStore.saveDataset(this, d); refresh(); toast("Generated ${d.records.size} test records")
    }

    private fun importFile(uri: Uri) {
        try {
            var name = "file"
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: name }
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return toast("Could not read the file")
            val (d, msg) = Dataset.import(name, bytes, AppStore.dataset(this))
            AppStore.saveDataset(this, d); refresh()
            AlertDialog.Builder(this).setTitle("Imported").setMessage(msg).setPositiveButton("OK", null).show()
        } catch (e: Exception) {
            AlertDialog.Builder(this).setTitle("Import failed").setMessage(e.message ?: e.toString()).setPositiveButton("OK", null).show()
        }
    }

    private fun preview() {
        val d = AppStore.dataset(this) ?: return toast("No test data yet")
        val id = try { parseRange(edRange.text.toString(), d.ids()).first() } catch (e: Exception) { d.ids().first() }
        val rec = d.record(id) ?: return
        val body = rec.filter { it.value.isNotEmpty() }.entries.joinToString("\n") { "${it.key}: ${it.value}" } +
            "\n\nAppliances:\n" + d.appliancesFor(id).joinToString("\n") { "• ${it["Appliance"]}: owned ${it["Number_owned"]}, working ${it["Number_working_W"]}, partly ${it["Number_partly_working_PW"]}" }
        showText("Record $id", body)
    }

    private fun startRun() {
        val svc = AgentService.instance ?: return AlertDialog.Builder(this).setTitle("Agent is off")
            .setMessage("Turn on Kobo Test Agent in Accessibility settings first (step 1).").setPositiveButton("OK", null).show().let { }
        val d = AppStore.dataset(this) ?: return toast("Generate or import test data first")
        val ids = try { parseRange(edRange.text.toString(), d.ids()) } catch (e: Exception) { return toast(e.message ?: "Bad record list") }
        val form = edForm.text.toString().trim()
        if (form.isEmpty()) return toast("Type the form name")
        AppStore.put(this, "formName", form); AppStore.put(this, "range", edRange.text.toString())
        val speed = when (rgSpeed.checkedRadioButtonId) { R.id.spFast -> "fast"; R.id.spSlow -> "slow"; else -> "normal" }
        AppStore.put(this, "speed", speed)
        val dateOrder = if (cbMdy.isChecked) "mdy" else "dmy"; AppStore.put(this, "dateOrder", dateOrder)
        val delay = mapOf("fast" to 150L, "normal" to 400L, "slow" to 900L)[speed]!!
        AlertDialog.Builder(this).setTitle("Start test run?")
            .setMessage("Fill ${ids.size} record(s) in '$form' with TEST answers and save each as a DRAFT.\n\nKeep the phone unlocked and don't touch the screen while it works. Use the bubble to pause or stop.")
            .setPositiveButton("Start") { _, _ -> svc.start(ids, delay, dateOrder)?.let { toast(it) } }
            .setNegativeButton("Cancel", null).show()
    }

    private fun shareReport() {
        val dir = File(cacheDir, "share").apply { mkdirs() }
        val zip = File(dir, "kobo_agent_report.zip")
        ZipOutputStream(zip.outputStream()).use { z ->
            val files = listOfNotNull(AppStore.logFile(this).takeIf { it.exists() }) + (AppStore.snapshotDir(this).listFiles()?.toList() ?: emptyList())
            if (files.isEmpty()) return toast("Nothing to share yet")
            for (f in files) { z.putNextEntry(ZipEntry(f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry() }
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.files", zip)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Share log + snapshots"))
    }

    private fun showText(title: String, text: String, scrollToEnd: Boolean = false) {
        val tv = TextView(this).apply { setText(text); setTextIsSelectable(true); textSize = 12f; setPadding(40, 20, 40, 20); typeface = android.graphics.Typeface.MONOSPACE }
        val sv = ScrollView(this).apply { addView(tv) }
        if (scrollToEnd) sv.post { sv.fullScroll(ScrollView.FOCUS_DOWN) }
        AlertDialog.Builder(this).setTitle(title).setView(sv).setPositiveButton("Close", null).show()
    }

    private fun toast(s: String) { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
}
