package com.surveytest.agent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.surveytest.agent.core.Control
import com.surveytest.agent.core.Device
import com.surveytest.agent.core.Engine
import com.surveytest.agent.core.Reporter
import com.surveytest.agent.core.UiNode
import java.io.File
import java.io.FileOutputStream

/**
 * The accessibility service: reads KoboCollect's screen and taps/types on it.
 * It only acts while a test run is going; the rest of the time it does nothing.
 */
class AgentService : AccessibilityService() {
    companion object {
        @Volatile var instance: AgentService? = null
        @Volatile var running = false
    }

    private val ui = Handler(Looper.getMainLooper())
    private var bubble: Bubble? = null
    private var control: Control? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        bubble = Bubble(this,
            onPauseToggle = { control?.let { it.paused = !it.paused; it.paused } ?: false },
            onStop = { control?.stopped = true; control?.paused = false },
            onClose = { bubble?.hide() })
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean { shutdown(); return super.onUnbind(intent) }
    override fun onDestroy() { shutdown(); super.onDestroy() }
    private fun shutdown() { control?.stopped = true; bubble?.hide(); instance = null }

    /** Starts a run. Returns an error message, or null when it started. */
    fun start(ids: List<Int>, delayMs: Long, dateOrder: String): String? {
        if (running) return "A run is already going"
        val data = AppStore.dataset(this) ?: return "No test data yet - generate or import it first"
        val rules = AppStore.rules(this)
        if (packageManager.getLaunchIntentForPackage(rules.packageName) == null) return "${rules.packageName} is not installed"
        val ctl = Control(); control = ctl; running = true
        AppStore.log(this, 0, "INFO", "", "", "run started: records ${ids.first()}..${ids.last()} (${ids.size}), form '${rules.formName}'")
        bubble?.show(ids.size)
        Thread {
            val rep = object : Reporter {
                override fun status(record: Int, done: Int, total: Int, text: String) { ui.post { bubble?.update(record, done, total, text, ctl.paused) } }
                override fun log(record: Int, kind: String, key: String, value: String, note: String) = AppStore.log(this@AgentService, record, kind, key, value, note)
            }
            var done = 0
            try {
                done = Engine(AndroidDevice(), rules, data, rep, ctl, delayMs = delayMs, dateOrder = dateOrder).run(ids)
            } catch (e: Throwable) {
                rep.log(0, "ERROR", "", "", "agent crashed: $e")
            } finally {
                running = false
                AppStore.log(this, 0, "INFO", "", "", "run ended: $done of ${ids.size} saved as drafts")
                ui.post { bubble?.finished("$done of ${ids.size} saved as drafts") }
            }
        }.apply { name = "agent-run" }.start()
        return null
    }

    // ---------------------------------------------------------------- the phone, as the engine sees it
    inner class AndroidDevice : Device {
        override fun root(): UiNode? {
            val r = rootInActiveWindow ?: return null
            return convert(r, 0)
        }

        private fun convert(n: AccessibilityNodeInfo, depth: Int): UiNode {
            val b = Rect(); n.getBoundsInScreen(b)
            val kids = ArrayList<UiNode>()
            if (depth < 60) for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                if (c.isVisibleToUser) kids.add(convert(c, depth + 1))
            }
            return UiNode(
                cls = n.className?.toString() ?: "", text = n.text?.toString() ?: "",
                desc = n.contentDescription?.toString() ?: "", id = n.viewIdResourceName ?: "",
                left = b.left, top = b.top, right = b.right, bottom = b.bottom,
                checked = n.isChecked, scrollable = n.isScrollable, children = kids, ref = n,
            )
        }

        override fun click(n: UiNode): Boolean {
            val node = n.ref as? AccessibilityNodeInfo ?: return tap(n.cx, n.cy)
            var c: AccessibilityNodeInfo? = node
            while (c != null && !c.isClickable) c = c.parent
            val ok = (c ?: node).performAction(AccessibilityNodeInfo.ACTION_CLICK)
            return ok || tap(n.cx, n.cy)
        }

        private fun tap(x: Int, y: Int): Boolean {
            if (x <= 0 && y <= 0) return false
            val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
            return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
        }

        override fun setText(n: UiNode, text: String): Boolean {
            val node = n.ref as? AccessibilityNodeInfo ?: return false
            val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
            if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS); Thread.sleep(200)
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }

        override fun scrollForward(root: UiNode): Boolean {
            val target = root.walk().filter { it.scrollable && it.ref is AccessibilityNodeInfo }
                .maxByOrNull { (it.right - it.left).toLong() * (it.bottom - it.top) } ?: return false
            return (target.ref as AccessibilityNodeInfo).performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        }

        override fun back() { performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) }

        override fun launch(pkg: String): Boolean {
            val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(i); return true
        }

        override fun sleep(ms: Long) = Thread.sleep(ms)

        override fun snapshot(name: String, root: UiNode?) {
            val dir = AppStore.snapshotDir(this@AgentService)
            File(dir, "$name.txt").writeText(root?.dump() ?: "(no screen)")
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                        val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        if (bmp != null) FileOutputStream(File(dir, "$name.png")).use { bmp.compress(Bitmap.CompressFormat.PNG, 90, it) }
                    } catch (_: Exception) {
                    } finally { result.hardwareBuffer.close() }
                }
                override fun onFailure(errorCode: Int) {}
            })
        }
    }
}
