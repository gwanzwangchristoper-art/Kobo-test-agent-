# Kobo Test Agent (Android)

Fills a **KoboCollect** form on the same phone with randomised **TEST** answers, by reading the screen and
tapping like a person (Android Accessibility). Built to test a form's skip logic and constraints before fieldwork.

- Saves every record as a **draft**. It never taps Finalize or Send, unticks "Mark form as finalized" on
  older versions, and refuses to save if a save screen only offers Finalize.
- The enumerator note (E3) is prefixed **[TEST]**.
- A floating bubble shows each step, with Pause/Resume and Stop. Drag it, or collapse it to a dot.
- Test data is generated in the app (count + seed), or imported from `.xlsx` (Responses + C1_Appliances sheets) or `.csv`.
- Question rules live in an editable `rules.json` (in-app editor with Check/Save/Reset/Help).

## Install on the phone (Android 11+, tested target Android 14)
1. Open the repo's **Releases** page on the phone, download `KoboTestAgent.apk`, open it and allow
   "Install unknown apps" for your browser/files app when asked.
2. Open **Kobo Test Agent** → *Turn on the agent* → find *Kobo Test Agent* → switch on.
   If the switch is greyed out ("Restricted setting"): in the app tap *Open app info* → **⋮** (top right)
   → **Allow restricted settings** → go back and switch it on.
3. Generate test records, type the form name exactly as KoboCollect shows it, choose records (start with `1`), tap **Start**.
4. After a run, check KoboCollect → **Drafts**. Share the log + snapshots from the app if anything stops.

## Build
Every push to `main` builds the APK with GitHub Actions and publishes it as a release (`.github/workflows/build.yml`).
Local build: Android Studio, or `gradle assembleDebug` with JDK 17 + Android SDK 34.

## Code
- `core/` plain Kotlin, no Android: screen parser, answer planner, run engine (draft-only), rules, generator, xlsx/csv import.
- `AgentService` accessibility service (reads/taps KoboCollect), `Bubble` overlay, `MainActivity`, `RulesActivity`.
- `core-tests/CoreTest.kt` runs the engine against a simulated KoboCollect on a normal JVM.
