import com.surveytest.agent.core.*
import java.io.File

/** A small KoboCollect form WITH skip logic, one question per screen, for testing "View form". */
class BranchFake : Device {
    class Q(val id: String, val sec: String, val label: String, val type: String, val opts: List<String> = emptyList(),
            val rel: (Map<String, String>) -> Boolean = { true }, val ok: (String) -> Boolean = { true }, val required: Boolean = true)
    val qs = listOf(
        Q("consent", "A. Consent", "A0. Do you agree to take part?", "radio", listOf("Yes", "No")),
        Q("sex", "A. Household profile", "A1. Sex of respondent", "radio", listOf("Female", "Male", "Prefer not to say"), rel = { it["consent"] == "Yes" }),
        Q("gen", "B. Energy", "B5. Does the household own a generator?", "radio", listOf("Yes", "No"), rel = { it["consent"] == "Yes" }),
        Q("genfuel", "B. Energy > B5a. Generator", "B5a. Litres of fuel bought last week", "num", rel = { it["gen"] == "Yes" }, ok = { (it.toIntOrNull() ?: 0) >= 2 }),
        Q("work", "A. Household profile", "A8. What do members do for income?", "check", listOf("Farming", "Trading", "Other", "None"), rel = { it["consent"] == "Yes" }),
        Q("workother", "A. Household profile", "A8a. Specify the other work", "edit", rel = { "Other" in (it["work"] ?: "").split(";") }),
        Q("lga", "A. Location", "A9. LGA", "spinner", listOf("Kwali", "Abaji", "Gwagwalada"), rel = { it["consent"] == "Yes" }),
        Q("e3", "E. Enumerator record", "E3. Enumerator observations and any difficulty encountered", "edit", required = false),
    )
    var onMenu = true; var idx = -1; val ans = LinkedHashMap<String, String>()
    var popup = false; var exitDialog = false; var saved = 0; var discarded = 0; var shots = 0; var launched = 0
    val seenQ = LinkedHashSet<String>()
    private fun cr(sec: String) = "Household Energy and Living Standards Survey > $sec"
    private fun n(cls: String, t: String, l: Int, tp: Int, r: Int, b: Int, id: String = "", checked: Boolean = false, ref: Any? = null, num: Boolean = false) =
        UiNode("android.widget.$cls", t, "", id, l, tp, r, b, checked, false, emptyList(), ref, num)
    private fun nextRelevant(from: Int): Int { var i = from + 1; while (i < qs.size && !qs[i].rel(ans)) i++; return i }
    override fun root(): UiNode {
        val out = ArrayList<UiNode>()
        when {
            onMenu -> out += n("Button", "Start new form", 50, 800, 1030, 950, ref = "start")
            exitDialog -> {
                out += n("TextView", "Save changes before leaving?", 100, 900, 980, 1000, id = "android:id/message")
                out += n("Button", "Save changes", 100, 1100, 500, 1200, id = "android:id/button1", ref = "savechanges")
                out += n("Button", "Ignore changes", 580, 1100, 980, 1200, id = "android:id/button2", ref = "ignore")
            }
            idx >= qs.size -> { out += n("Button", "Save as draft", 50, 1500, 500, 1650, ref = "draft"); out += n("Button", "Finalize", 550, 1500, 1030, 1650, ref = "final") }
            popup -> qs[idx].opts.forEachIndexed { j, o -> out += n("CheckedTextView", o, 100, 600 + j * 120, 980, 700 + j * 120, ref = "opt|$o") }
            else -> {
                val q = qs[idx]; seenQ += q.id
                out += n("TextView", cr(q.sec), 50, 330, 1030, 440)
                out += n("TextView", q.label, 50, 500, 1030, 590)
                var y = 620
                val cur = ans[q.id] ?: ""
                when (q.type) {
                    "radio", "check" -> for (o in q.opts) { out += n(if (q.type == "radio") "RadioButton" else "CheckBox", o, 50, y, 1030, y + 130, checked = o in cur.split(";"), ref = "pick|$o"); y += 150 }
                    "edit", "num" -> out += n("EditText", cur, 50, y, 1030, y + 130, ref = "box", num = q.type == "num")
                    "spinner" -> out += n("Spinner", cur.ifEmpty { "Select One Answer" }, 50, y, 1030, y + 130, ref = "spin")
                }
                out += n("Button", "Back", 50, 2250, 500, 2380); out += n("Button", "Next", 560, 2250, 1030, 2380, ref = "next")
            }
        }
        return UiNode("android.widget.FrameLayout", "", "", "", 0, 0, 1080, 2400, false, false, out)
    }
    override fun click(n: UiNode): Boolean {
        val r = n.ref as? String ?: return true
        when {
            r == "start" -> { onMenu = false; ans.clear(); idx = nextRelevant(-1) }
            r == "next" -> {
                val q = qs[idx]; val v = ans[q.id] ?: ""
                if ((q.required && v.isBlank()) || (v.isNotBlank() && !q.ok(v))) return true
                idx = nextRelevant(idx)
            }
            r == "draft" || r == "final" || r == "savechanges" -> { saved++; onMenu = true; exitDialog = false }
            r == "ignore" -> { discarded++; onMenu = true; exitDialog = false }
            r == "spin" -> popup = true
            r.startsWith("opt|") -> { ans[qs[idx].id] = r.removePrefix("opt|"); popup = false }
            r.startsWith("pick|") -> {
                val o = r.removePrefix("pick|"); val q = qs[idx]
                if (q.type == "radio") ans[q.id] = o
                else { val set = (ans[q.id] ?: "").split(";").filter { it.isNotEmpty() }.toMutableList(); if (o in set) set.remove(o) else set.add(o); ans[q.id] = set.joinToString(";") }
            }
        }
        return true
    }
    override fun setText(n: UiNode, text: String): Boolean { ans[qs[idx].id] = text; return true }
    override fun scrollForward(root: UiNode) = false
    override fun back() { if (popup) popup = false else if (!onMenu && !exitDialog) exitDialog = true }
    override fun launch(pkg: String): Boolean { launched++; return true }
    override fun sleep(ms: Long) {}
    override fun snapshot(name: String, root: UiNode?) {}
    override fun capture(folder: String, name: String, root: UiNode?, text: String) { shots++; check(text.contains("How the agent reads")) { "capture text" } }
    override fun currentPackage() = "org.koboc.collect.android"
}

fun exploreTests(rules: Rules) {
    val f = BranchFake(); val rep = Rep(); val map = FormMap("Test form")
    Engine(f, rules, Dataset(listOf(mapOf("Record" to "1")), emptyList(), "t"), rep, Control(), delayMs = 0, t = Timing.ULTRA).explore(10, map)
    val log = rep.logs.joinToString("\n")
    check(f.saved == 0) { "View form must never save: saved=${f.saved}\n$log" }
    check(f.discarded == map.routes.size) { "every pass discarded: ${f.discarded} vs ${map.routes.size}" }
    check(f.seenQ == f.qs.map { it.id }.toSet()) { "every question reached: ${f.seenQ}\n$log\n${map.routesText()}" }
    check(map.screens.size == f.qs.size + 1) { "screens ${map.screens.keys}" }
    val all = map.screens.values.flatMap { it.fields }
    for (fld in all.filter { it.isChoice }) check(fld.untried().isEmpty()) { "untried options in ${fld.label}: ${fld.untried()}" }
    check(all.first { it.label.startsWith("A9") }.options == listOf("Kwali", "Abaji", "Gwagwalada")) { "dropdown options recorded" }
    check(map.screens.values.first { it.isEnd }.passes.isNotEmpty()) { "end reached" }
    check(f.shots == map.screens.values.sumOf { it.shots.size } && f.shots >= map.screens.size) { "shots ${f.shots}" }
    // consent No must lead straight to E3
    val consent = map.screens.values.first { s -> s.fields.any { it.label.startsWith("A0") } }
    val e3 = map.screens.values.first { s -> s.fields.any { it.label.startsWith("E3") } }
    check(map.edges.any { it.from == consent.no && it.answers.contains("= No") && it.to == e3.no }) { "consent No -> E3 edge\n" + map.formMapText() }
    val txt = map.formMapText(); val csv = map.questionsCsv(); val js = map.toJson(); val routes = map.routesText()
    check("** NO RULE **" in txt || "data column:" in txt) { "map text" }
    check(csv.lines().size >= f.qs.size + 1 && csv.startsWith("screen,section,question")) { "csv" }
    check((Json.parse(js) as Map<*, *>)["screens"] is List<*>) { "json" }
    check(routes.contains("Pass 1")) { "routes" }
    println("view form: ${map.routes.size} passes, ${map.screens.size} screens, ${map.questionCount()} questions, every option tried, nothing saved (${map.finishedReason}) OK")
    if (System.getenv("SHOWMAP") != null) println(txt + "\n" + routes + "\n" + csv)
}

/** E3 last screen: the first typing is lost by the phone; the agent must notice, type again, then save. */
fun lastScreenTests(rules: Rules) {
    class Lossy : Device {
        var screen = 0; var text = ""; var lost = 2; var saved = false
        override fun root(): UiNode {
            val out = ArrayList<UiNode>()
            if (screen == 2) out += UiNode("android.widget.Button", "Start new form", "", "", 50, 800, 1030, 950, false, false, emptyList())
            else if (screen == 1) out += UiNode("android.widget.Button", "Save as draft", "", "", 50, 1500, 500, 1650, false, false, emptyList(), "draft")
            else {
                out += UiNode("android.widget.TextView", "Household Energy and Living Standards Survey > E. Enumerator record", "", "", 50, 330, 1030, 440, false, false, emptyList())
                out += UiNode("android.widget.TextView", "E3. Enumerator observations and any difficulty encountered", "", "", 50, 500, 1030, 650, false, false, emptyList())
                out += UiNode("android.widget.EditText", text, "", "", 50, 700, 1030, 880, false, false, emptyList(), "box")
                out += UiNode("android.widget.Button", "Next", "", "", 560, 1300, 1030, 1430, false, false, emptyList(), "next")
            }
            return UiNode("android.widget.FrameLayout", "", "", "", 0, 0, 1080, 2400, false, false, out)
        }
        override fun click(n: UiNode): Boolean { when (n.ref) { "next" -> if (text.isNotBlank()) screen = 1; "draft" -> { saved = true; screen = 2 } }; return true }
        override fun setText(n: UiNode, text: String): Boolean { if (lost > 0) { lost--; return true }; this.text = text; return true }
        override fun scrollForward(root: UiNode) = false
        override fun back() {}
        override fun launch(pkg: String) = true
        override fun sleep(ms: Long) {}
        override fun snapshot(name: String, root: UiNode?) {}
    }
    val d = Lossy(); val rep = Rep()
    val data = Dataset(listOf(mapOf("Record" to "1", "E3_Enumerator_observations" to "Fine")), emptyList(), "t")
    val n = Engine(d, rules, data, rep, Control(), delayMs = 0, t = Timing.ULTRA).run(listOf(1), formAlreadyOpen = true)
    check(n == 1 && d.saved && d.text == "[TEST] Fine") { "E3 lost typing: saved=${d.saved} text='${d.text}'\n" + rep.logs.joinToString("\n") }
    println("E3 last screen: typing lost twice by the phone, read back, typed again, saved as draft OK")
    check(rules.isLastQuestion(listOf("E3. Enumerator observations")) && !rules.isLastQuestion(listOf("E2. Photo"))) { "lastQuestion" }
    check(sameValue("5,000", "5000") && sameValue("8.0", "8") && !sameValue("", "[TEST] x")) { "sameValue" }
    check(Timing.ULTRA.ms(700) * 7 <= Timing.SUPER.ms(700) + 7 && Timing.ULTRA.poll * 7 <= Timing.SUPER.poll + 7) { "ultra = super / 7" }
    println("ultra speed: every wait 7 x shorter than super OK")
}

fun importTests() {
    val (a, m1) = Dataset.import("semi.csv", "record ; A1_Sex;A3_Household_size\n1;Male;5\n2;Female;7\n".toByteArray(), null)
    check(a.ids() == listOf(1, 2) && a.record(2)!!["A1_Sex"] == "Female" && a.record(1)!!["A3_Household_size"] == "5") { "semicolon csv: ${a.records} $m1" }
    val (b, m2) = Dataset.import("norecord.csv", "A1_Sex,A3_Household_size\nMale,5\nFemale,7\nMale,3\n".toByteArray(), null)
    check(b.ids() == listOf(1, 2, 3) && "numbered" in m2) { "auto-numbered: ${b.records} $m2" }
    val bad = try { Dataset.import("old.xls", byteArrayOf(0xD0.toByte(), 0xCF.toByte(), 1, 2), null); "" } catch (e: IllegalArgumentException) { e.message ?: "" }
    check(".xlsx" in bad) { "xls message: $bad" }
    println("import: ';' separated CSV, file without Record column, old .xls message OK")
}

/** E3 that never accepts Next: the form must still be saved as a draft (via the question list > Go to end), not thrown away. */
fun lastScreenStuckTest(rules: Rules) {
    class Stuck : Device {
        var state = "e3"; var text = ""; var saved = false; var discarded = false; var otherApp = 0
        fun n(cls: String, t: String, top: Int, ref: Any?, desc: String = "") = UiNode("android.widget.$cls", t, desc, "", 50, top, 1030, top + 120, false, false, emptyList(), ref)
        override fun root(): UiNode {
            val out = when (state) {
                "menu" -> listOf(n("Button", "Start new form", 800, "start"))
                "list" -> listOf(n("Button", "Go to end", 400, "goend"), n("TextView", "E3. Enumerator observations", 600, null))
                "end" -> listOf(n("Button", "Save as draft", 1500, "draft"), n("Button", "Finalize", 1700, "final"))
                else -> listOf(n("ImageButton", "", 150, "list", desc = "Go to question list"),
                    n("TextView", "Household Energy and Living Standards Survey > E. Enumerator record", 330, null),
                    n("TextView", "E3. Enumerator observations and any difficulty encountered", 500, null),
                    n("EditText", text, 700, "box"), n("Button", "Next", 1300, "next"))
            }
            return UiNode("android.widget.FrameLayout", "", "", "", 0, 0, 1080, 2400, false, false, out)
        }
        override fun click(n: UiNode): Boolean { when (n.ref) { "list" -> state = "list"; "goend" -> state = "end"; "draft" -> { saved = true; state = "menu" }; "final" -> throw AssertionError("Finalize tapped") }; return true }
        override fun setText(n: UiNode, text: String): Boolean { this.text = text; return true }
        override fun scrollForward(root: UiNode) = false
        override fun back() { if (state == "list") state = "e3" else discarded = true }
        override fun launch(pkg: String) = true
        override fun sleep(ms: Long) {}
        override fun snapshot(name: String, root: UiNode?) {}
        override fun currentPackage(): String = if (otherApp-- > 0) "com.whatsapp" else "org.koboc.collect.android"
    }
    val d = Stuck(); d.otherApp = 5; val rep = Rep()
    val data = Dataset(listOf(mapOf("Record" to "1", "E3_Enumerator_observations" to "Fine")), emptyList(), "t")
    val n = Engine(d, rules, data, rep, Control(), delayMs = 0, t = Timing.ULTRA).run(listOf(1), formAlreadyOpen = true)
    check(n == 1 && d.saved && !d.discarded) { "stuck E3: saved=${d.saved} discarded=${d.discarded}\n" + rep.logs.joinToString("\n") }
    check(rep.logs.any { "last question would not accept Next" in it }) { "warning logged" }
    println("E3 that refuses Next: waited while another app was in front, then went to the save screen and saved the DRAFT (not thrown away) OK")
}

/**
 * The "blank drafts" bug: KoboCollect slides pages in. For a moment after Next the phone still shows the old page
 * (moving), then a half-drawn page, then the new one. The agent must not tap Next again in between - that skipped
 * the real next page and left it blank. Also: a month-year date with spinning wheels that ignore typing.
 */
class SlidingKobo : Device {
    class Q(val label: String, val type: String, val opts: List<String> = emptyList(), val sec: String = "B. Energy access, reliability and cost")
    val qs = listOf(
        Q("Month and year connected", "date", sec = "B. Energy access, reliability and cost > B1a. When did the household connect, and what did it pay to connect?"),
        Q("B13. If electricity were available, would the household use it for cooking?", "radio", listOf("Yes", "No", "Not sure")),
        Q("B13b. Has the respondent heard of cooking with electricity, for example a hotplate, rice cooker or electric pressure cooker?", "radio", listOf("Yes", "No", "Not sure")),
        Q("C6. Which appliance or activity would the household use most with reliable electricity?", "check", listOf("Refrigerator or freezer", "Television", "Fan", "Phone charging", "Lighting", "Sewing or tailoring", "Hairdressing or barbing"), "C. Appliances, demand and affordability"),
        Q("C8. Would the household connect, or increase its use of, a reliable mini-grid supply? [WP5.2 only]", "radio", listOf("Yes", "Maybe, depending on tariff or connection cost", "No", "Already adequately served", "Not sure"), "C. Appliances, demand and affordability"),
        Q("D5. Overall, has the household's quality of life changed as a result of the mini-grid?", "radio", listOf("Very much improved", "Slightly improved", "No change", "Slightly worse", "Significantly worse"), "D. Service experience and change since connection [WP5.2, connected households]"),
        Q("D6. How likely is the household to recommend the mini-grid service to friends or family? (0 to 10)", "num", sec = "D. Service experience and change since connection [WP5.2, connected households]"),
    )
    /** Time on the fake phone: reading the screen costs 40 ms; the page slide after Next takes 400 ms. */
    var clock = 0L; var nextAt = -100000L
    val sliding get() = clock - nextAt < 700
    var idx = 0; val ans = HashMap<Int, String>(); var prev = 0; var saved = false; var nextTaps = 0; var tapsDuringSlide = 0
    var picker = false; var pm = 10; var py = 2026   // picker opens on today (Nov 2026)
    private val months = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    private fun n(cls: String, t: String, l: Int, tp: Int, r: Int, b: Int, id: String = "", checked: Boolean = false, ref: Any? = null, num: Boolean = false, kids: List<UiNode> = emptyList()) =
        UiNode("android.widget.$cls", t, "", id, l, tp, r, b, checked, false, kids, ref, num)
    private fun page(i: Int, shift: Int): List<UiNode> {
        if (saved) return listOf(n("Button", "Start new form", 50, 800, 1030, 950))
        if (i >= qs.size) return listOf(n("Button", "Save as draft", 50, 1500, 500, 1650, ref = "draft"))
        val q = qs[i]; val cur = ans[i] ?: ""; val out = ArrayList<UiNode>()
        out += n("TextView", "Household Energy and Living Standards Survey > ${q.sec}", 48 + shift, 324, 1032 + shift, 500)
        out += n("TextView", q.label, 48 + shift, 560, 1032 + shift, 850)
        var y = 900
        when (q.type) {
            "radio", "check" -> for (o in q.opts) { out += n(if (q.type == "radio") "RadioButton" else "CheckBox", o, 48 + shift, y, 984 + shift, y + 140, checked = o in cur.split(";"), ref = "pick|$i|$o"); y += 147 }
            "num" -> out += n("EditText", cur, 48 + shift, y, 1032 + shift, y + 170, ref = "box|$i", num = true)
            "date" -> { out += n("Button", "Select date", 48 + shift, y, 1032 + shift, y + 140, ref = "date"); out += n("TextView", if (cur.isEmpty()) "No date selected" else cur, 300 + shift, y + 180, 780 + shift, y + 260) }
        }
        return out
    }
    override fun root(): UiNode {
        clock += 40
        val out = ArrayList<UiNode>()
        if (picker) {
            fun wheel(v: String, l: Int, tag: String) = n("NumberPicker", "", l, 900, l + 300, 1400, kids = listOf(
                n("Button", "", l, 900, l + 300, 1050, ref = "$tag-"), n("EditText", v, l, 1080, l + 300, 1220, id = "android:id/numberpicker_input", ref = "in"),
                n("Button", "", l, 1250, l + 300, 1400, ref = "$tag+")))
            out += wheel(months[pm], 100, "m"); out += wheel(py.toString(), 600, "y")
            out += n("Button", "OK", 700, 1600, 950, 1700, id = "android:id/button1", ref = "ok"); out += n("Button", "Cancel", 300, 1600, 600, 1700, id = "android:id/button2", ref = "cancel")
        } else if (sliding) {
            val e = clock - nextAt
            if (e < 420) out += page(prev, -(e.toInt() * 3))       // the old page sliding out (already answered: nothing to do)
            else out += n("TextView", "Household Energy and Living Standards Survey", 48, 324, 1032, 400)   // new page half drawn
            out += n("Button", "Next", 564, 2232, 1032, 2400, id = "x:id/form_forward_button", ref = "next")
        } else {
            out += page(idx, 0)
            if (idx < qs.size) out += n("Button", "Next", 564, 2232, 1032, 2400, id = "x:id/form_forward_button", ref = "next")
        }
        return UiNode("android.widget.FrameLayout", "", "", "", 0, 0, 1080, 2400, false, false, out)
    }
    override fun click(n: UiNode): Boolean {
        val r = n.ref as? String ?: return true
        when {
            r == "next" -> { nextTaps++; if (sliding) tapsDuringSlide++; prev = idx; idx++; nextAt = clock }   // KoboCollect moves on at once; the screen catches up
            r == "draft" -> saved = true
            r == "date" -> picker = true
            r == "m+" -> pm = (pm + 1) % 12; r == "m-" -> pm = (pm + 11) % 12
            r == "y+" -> py++; r == "y-" -> py--
            r == "ok" -> { ans[idx] = "${months[pm]} $py"; picker = false }
            r == "cancel" -> picker = false
            r.startsWith("pick|") -> {
                val (_, i, o) = r.split("|"); val q = qs[i.toInt()]
                if (q.type == "radio") ans[i.toInt()] = o
                else { val set = (ans[i.toInt()] ?: "").split(";").filter { it.isNotEmpty() }.toMutableList(); if (o in set) set.remove(o) else set.add(o); ans[i.toInt()] = set.joinToString(";") }
            }
        }
        return true
    }
    override fun setText(n: UiNode, text: String): Boolean {
        val r = n.ref as? String ?: return true
        if (r == "in") return true           // like Android: typing into a date wheel is not kept
        if (r.startsWith("box|")) ans[r.removePrefix("box|").toInt()] = text
        return true
    }
    override fun scrollForward(root: UiNode) = false
    override fun back() { picker = false }
    override fun launch(pkg: String) = true
    override fun sleep(ms: Long) { clock += ms }
    override fun snapshot(name: String, root: UiNode?) {}
}

fun slidingPagesTest(rules: Rules) {
    val rec = mapOf("Record" to "1", "B1a_Month_year_connected" to "2023-02", "B13_Would_cook_with_electricity" to "Yes",
        "B13b_Heard_of_electric_cooking" to "Yes", "C6_Most_wanted_use" to "Refrigerator or freezer; Sewing or tailoring",
        "C8_Would_connect_or_increase_use" to "Yes", "D5_Quality_of_life_change" to "Very much improved", "D6_Likelihood_to_recommend_0_10" to "7")
    for (speed in listOf(Timing.NORMAL, Timing.SUPER, Timing.ULTRA)) {
        val d = SlidingKobo(); val rep = Rep()
        val n = Engine(d, rules, Dataset(listOf(rec), emptyList(), "t"), rep, Control(), delayMs = 0, autoAnswer = false, t = speed).run(listOf(1), formAlreadyOpen = true)
        val log = rep.logs.joinToString("\n")
        val want = listOf("Feb 2023", "Yes", "Yes", "Refrigerator or freezer;Sewing or tailoring", "Yes", "Very much improved", "7")
        val got = d.qs.indices.map { d.ans[it] ?: "" }
        check(n == 1 && d.saved) { "${speed.name}: not saved\n$log" }
        check(got == want) { "${speed.name}: blank or wrong answers in the draft:\n got  $got\n want $want\n$log" }
        check(d.tapsDuringSlide == 0 && d.nextTaps == d.qs.size) { "${speed.name}: Next tapped while the page was sliding (${d.tapsDuringSlide}) - pages skipped\n$log" }
    }
    println("sliding pages: no Next while a page slides in, no page skipped, every answer in the draft (normal, super, ultra) OK")
    println("date wheels: typing ignored by the wheel -> turned Nov 2026 to Feb 2023 step by step and read it back OK")
    check(dateShows("Feb 2023", "2023-02") && !dateShows("Nov 2026", "2023-02") && !dateShows("No date selected", "2023-02") && dateShows("15/02/2023", "2023-02")) { "dateShows" }
}

/**
 * A whole run like on the phone: main menu -> form list -> pages sliding in -> date picker that opens slowly ->
 * save screen whose buttons appear late -> "Saving form…" for 2 s -> back to the menu -> next record.
 * Checks every record is saved as a draft with every answer, and the run does not end early.
 */
class PhoneKobo(val formName: String) : Device {
    val pagesQ = SlidingKobo().qs
    var clock = 0L; var at = 0L                      // time of the last screen change
    var state = "menu"; var idx = 0; var ans = HashMap<Int, String>()
    val drafts = ArrayList<Map<Int, String>>(); var discards = 0; var strayBacks = 0
    var pm = 10; var py = 2026; var backFrom = "page"; var expectBack = false
    /** Press Back by surprise on page `strayAt` of record `strayRec` (like a mis-read keyboard) - the run must survive it. */
    var strayRec = -1; var strayAt = -1; var formsOpened = 0; var strayDone = false
    private val months = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    private fun go(s: String) {
        state = s; at = clock
        if (s == "page" && formsOpened == strayRec && idx == strayAt && !strayDone) { strayDone = true; expectBack = true; back(); expectBack = false }
    }
    private val age get() = clock - at
    private fun n(cls: String, t: String, l: Int, tp: Int, r: Int, b: Int, id: String = "", checked: Boolean = false, ref: Any? = null, num: Boolean = false, kids: List<UiNode> = emptyList()) =
        UiNode("android.widget.$cls", t, "", id, l, tp, r, b, checked, false, kids, ref, num)
    override fun root(): UiNode {
        clock += 40
        val out = ArrayList<UiNode>()
        when (state) {
            "menu" -> { out += n("Button", "Start new form", 50, 800, 1030, 950, ref = "start"); out += n("Button", "Drafts", 50, 1000, 1030, 1150) }
            "list" -> if (age > 300) out += n("TextView", formName, 50, 500, 1030, 600, ref = "form")
            "page" -> {
                if (age < 350) out += n("TextView", "Household Energy and Living Standards Survey", 48, 324, 1032, 400)   // half drawn
                else {
                    val q = pagesQ[idx]; val cur = ans[idx] ?: ""
                    out += n("TextView", "Household Energy and Living Standards Survey > ${q.sec}", 48, 324, 1032, 500)
                    out += n("TextView", q.label, 48, 560, 1032, 850)
                    var y = 900
                    when (q.type) {
                        "radio", "check" -> for (o in q.opts) { out += n(if (q.type == "radio") "RadioButton" else "CheckBox", o, 48, y, 984, y + 140, checked = o in cur.split(";"), ref = "pick|$o"); y += 147 }
                        "num" -> out += n("EditText", cur, 48, y, 1032, y + 170, ref = "box", num = true)
                        "date" -> { out += n("Button", "Select date", 48, y, 1032, y + 140, ref = "date"); out += n("TextView", if (cur.isEmpty()) "No date selected" else cur, 300, y + 180, 780, y + 260) }
                    }
                    out += n("Button", "Back", 48, 2232, 500, 2400); out += n("Button", "Next", 564, 2232, 1032, 2400, ref = "next")
                }
            }
            "picker" -> if (age > 400) {
                fun wheel(v: String, l: Int, tag: String) = n("NumberPicker", "", l, 900, l + 300, 1400, kids = listOf(
                    n("Button", "x", l, 900, l + 300, 1050, ref = "$tag-"), n("EditText", v, l, 1080, l + 300, 1220, id = "android:id/numberpicker_input", ref = "in"),
                    n("Button", "x", l, 1250, l + 300, 1400, ref = "$tag+")))
                out += wheel(months[pm], 100, "m"); out += wheel(py.toString(), 600, "y")
                out += n("Button", "OK", 700, 1600, 950, 1700, id = "android:id/button1", ref = "ok")
            } else out += n("FrameLayout", "", 100, 800, 980, 1800)
            "end" -> {
                // like the real KoboCollect end screen (Jetpack Compose): words in a TextView, an EMPTY Button beside it;
                // the toolbar's Save icon also says "Save as draft" (must be ignored)
                out += n("Button", "", 672, 132, 816, 276, id = "org.koboc.collect.android:id/menu_save", ref = "toolbarsave").let { UiNode(it.cls, "", "Save as draft", it.id, it.left, it.top, it.right, it.bottom, false, false, emptyList(), it.ref) }
                out += n("TextView", "You are at the end of $formName.", 48, 691, 1032, 928)
                if (age > 500) {
                    out += n("View", "", 48, 1628, 516, 1818, kids = listOf(n("TextView", "Save as draft", 216, 1652, 444, 1794), n("Button", "", 48, 1628, 516, 1818, ref = "draft")))
                    out += n("View", "", 564, 1628, 1032, 1772, kids = listOf(n("TextView", "Finalize", 761, 1665, 932, 1736), n("Button", "", 564, 1640, 1032, 1760, ref = "final")))
                }
            }
            "saving" -> { out += n("TextView", "Saving form…", 300, 1100, 780, 1200); if (age > 2000) { drafts.add(HashMap(ans)); go("menu") } }
            "quit" -> { // KoboCollect's "Save form?" pop-up (as on the phone)
                out += n("TextView", "Save form?", 170, 780, 900, 860)
                out += n("TextView", "This form was last saved on Sun, Nov 15, 2026 at 05:48. Save as draft to keep changes.", 170, 940, 900, 1130)
                out += n("Button", "Discard Changes", 170, 1196, 908, 1334, ref = "ignore")
                out += n("Button", "Keep editing", 170, 1382, 908, 1520, ref = "keep")
                out += n("Button", "Save as draft", 170, 1568, 908, 1712, ref = "savechanges") }
        }
        return UiNode("android.widget.FrameLayout", "", "", "", 0, 0, 1080, 2400, false, false, out)
    }
    override fun click(n: UiNode): Boolean {
        val r = n.ref as? String ?: return true
        when {
            r == "start" -> go("list")
            r == "form" -> { ans = HashMap(); idx = 0; formsOpened++; go("page") }
            r == "next" && state == "page" -> { if (age < 350) return true; if (idx + 1 < pagesQ.size) { idx++; go("page") } else go("end") }
            r == "draft" && state == "end" -> go("saving")
            r == "final" -> throw AssertionError("Finalize tapped")
            r == "savechanges" -> throw AssertionError("'Save as draft' tapped in the 'Save form?' pop-up (saves a half-empty draft)")
            r == "toolbarsave" -> throw AssertionError("toolbar Save icon tapped")
            r == "keep" -> go(backFrom)
            r == "ignore" -> { discards++; go("menu") }
            r == "date" -> go("picker")
            r == "m+" -> pm = (pm + 1) % 12; r == "m-" -> pm = (pm + 11) % 12
            r == "y+" -> py++; r == "y-" -> py--
            r == "ok" -> { ans[idx] = "${months[pm]} $py"; pm = 10; py = 2026; go("page") }
            r.startsWith("pick|") && state == "page" -> {
                val o = r.removePrefix("pick|"); val q = pagesQ[idx]
                if (q.type == "radio") ans[idx] = o
                else { val set = (ans[idx] ?: "").split(";").filter { it.isNotEmpty() }.toMutableList(); if (o in set) set.remove(o) else set.add(o); ans[idx] = set.joinToString(";") }
            }
        }
        return true
    }
    override fun setText(n: UiNode, text: String): Boolean { if (n.ref == "box" && state == "page") ans[idx] = text; return true }
    override fun scrollForward(root: UiNode) = false
    override fun back() {
        when (state) { "picker" -> go("page"); "page", "end" -> { if (!expectBack) strayBacks++; backFrom = state; go("quit") }; "quit" -> go(backFrom); "list" -> go("menu") }
    }
    override fun launch(pkg: String) = true
    override fun sleep(ms: Long) { clock += ms }
    override fun snapshot(name: String, root: UiNode?) {}
    override fun currentPackage() = "org.koboc.collect.android"
}

fun fullRunTest(rules: Rules) {
    val form = "Full Scale Data Collection"
    val r2 = Rules.parse(Json.write(LinkedHashMap(Json.parse(File("app/src/main/assets/rules.json").readText()) as Map<String, Any?>).apply { put("formName", form) }))
    val recs = (1..12).map { i -> mapOf("Record" to "$i", "B1a_Month_year_connected" to "2023-0${1 + i % 9}", "B13_Would_cook_with_electricity" to listOf("Yes", "No", "Not sure")[i % 3],
        "B13b_Heard_of_electric_cooking" to "Yes", "C6_Most_wanted_use" to "Television; Fan", "C8_Would_connect_or_increase_use" to "No",
        "D5_Quality_of_life_change" to "Slightly improved", "D6_Likelihood_to_recommend_0_10" to "${i % 11}") }
    for (speed in listOf(Timing.NORMAL, Timing.ULTRA)) {
        val d = PhoneKobo(form); d.strayRec = 5; d.strayAt = 3; val rep = Rep()
        val n = Engine(d, r2, Dataset(recs, emptyList(), "t"), rep, Control(), delayMs = 0, autoAnswer = true, keepGoing = true, t = speed).run((1..12).toList())
        val log = rep.logs.joinToString("\n")
        check(n == 12 && d.drafts.size == 12 && d.discards == 0) { "${speed.name}: saved $n, drafts ${d.drafts.size}, discarded ${d.discards}, stray Backs ${d.strayBacks}\n$log" }
        for ((i, dr) in d.drafts.withIndex()) {
            val rec = recs[i]
            val want = listOf("${listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep")[(i + 1) % 9]} 2023", rec["B13_Would_cook_with_electricity"], "Yes", "Television;Fan", "No", "Slightly improved", rec["D6_Likelihood_to_recommend_0_10"])
            check((0 until 7).map { dr[it] } == want) { "${speed.name}: draft ${i + 1} has blanks / wrong answers: ${(0 until 7).map { dr[it] }} want $want\n$log" }
        }
        check(d.strayBacks == 0) { "${speed.name}: Back pressed on a form page ${d.strayBacks} times" }
    }
    println("full run: 12 records -> 12 drafts with every answer, Compose save screen, a surprise 'Save form?' pop-up closed with Keep editing, 0 discarded (normal, ultra) OK")
}

/** The real KoboCollect end screen (recorded on the phone): it must be read as the save screen, draft button = the empty Button. */
fun realEndScreenTest(rules: Rules) {
    val scr = parseScreen(loadScreen(File("core-tests/real/end_screen.txt")), rules)
    check(scr.isEnd && !scr.quit) { "real end screen not recognised (isEnd=${scr.isEnd})" }
    val d = scr.saveDraft ?: throw AssertionError("no draft button found on the real end screen")
    check(d.node!!.cls.endsWith("Button") && d.node!!.top == 1628 && d.node!!.id.isEmpty()) { "draft button is the toolbar icon or a label: ${d.node!!.dump()}" }
    println("real end screen: read as the save screen; 'Save as draft' = the button in the page (not the toolbar icon) OK")
}

/** The real "Save form?" pop-up (recorded): never taken for the end screen; Keep editing found. */
fun realSaveFormPopupTest(rules: Rules) {
    val scr = parseScreen(loadScreen(File("core-tests/real/save_form_popup.txt")), rules)
    check(scr.quit && !scr.isEnd && scr.saveDraft == null) { "the 'Save form?' pop-up was read as the end screen (quit=${scr.quit} end=${scr.isEnd})" }
    check(scr.keepEditing?.text == "Keep editing" && scr.discard?.text == "Discard Form") { "pop-up buttons: ${scr.keepEditing?.text} / ${scr.discard?.text}" }
    println("real 'Save form?' pop-up: never saved from (it saved half-empty drafts before); Keep editing / Discard found OK")
}
