package com.surveytest.agent.core

/** What the engine needs from the phone. The Android app implements this with the accessibility service. */
interface Device {
    fun root(): UiNode?
    fun click(n: UiNode): Boolean
    fun setText(n: UiNode, text: String): Boolean
    fun scrollForward(root: UiNode): Boolean
    fun back()
    fun launch(pkg: String): Boolean
    fun sleep(ms: Long)
    fun snapshot(name: String, root: UiNode?)
}

interface Reporter {
    fun status(record: Int, done: Int, total: Int, text: String)
    fun log(record: Int, kind: String, key: String, value: String, note: String)
}

class Control { @Volatile var paused = false; @Volatile var stopped = false }
class StopRequested : RuntimeException("stopped")

class Action(val kind: String, val item: Item, val key: String, val text: String, val auto: Boolean = false)

/** Options a test answer should avoid when choosing on its own. */
private val AVOID = Regex("(?i)\\bother\\b|don.?t know|do not know|not sure|refus|prefer not|not applicable|\\bn/?a\\b|none of|no answer|specify")
private val NUMERIC_LABEL = Regex("(?i)how many|number|\\bngn\\b|amount|\\bage\\b|hours|kwh|cost|price|quantity|total|tariff|fee|\\(w\\)|watts?|years?|months?|days?|0-10|0 to 10")

/** Picks sensible answers for questions that have no rule (or whose data is blank but the form insists). */
class Auto(seed: Long) {
    private val rnd = java.util.Random(seed)
    fun pick(items: List<Item>): Item? {
        if (items.isEmpty()) return null
        val good = items.filter { !AVOID.containsMatchIn(it.text) && norm(it.text) != "none" && norm(it.text) != "no" }
        val pool = good.ifEmpty { items.filter { !AVOID.containsMatchIn(it.text) } }.ifEmpty { items }
        return pool[rnd.nextInt(pool.size)]
    }
    /** Numbers tried in turn when the form rejects one (constraints). */
    fun number(level: Int) = listOf("1", "2", "0", "5", "10", "3", "20")[level % 7]
    fun numericField(it: Item, label: String) = it.numeric || NUMERIC_LABEL.containsMatchIn(label)
}

/**
 * Decide the next tap/typing on the visible screen, or null when everything visible is answered.
 * level = how many times Next has failed on this screen; from 1 up, blank required answers are filled automatically.
 */
fun plan(scr: Screen, rules: Rules, rec: Rec, apps: List<Rec>, counts: MutableMap<String, Int>, atEnd: Boolean,
         log: (String, String, String, String) -> Unit, auto: Auto? = null, level: Int = 0,
         memory: MutableMap<String, String> = HashMap(), scrolled: Boolean = false): Action? {
    for ((fi, f) in scr.fields.withIndex()) {
        var lab = f.lab
        // After scrolling, the top question's title may be off-screen: recognise it by the options seen earlier.
        if ((f.t == "radio" || f.t == "check") && fi == 0 && scrolled && rules.resolve(scr.sub, lab) == null)
            f.items.firstNotNullOfOrNull { memory["opt|" + it.text] }?.let { lab = it }
        if (f.t == "radio" || f.t == "check") f.items.forEach { memory.putIfAbsent("opt|" + it.text, lab) }
        var key = rules.resolve(scr.sub, lab)
        if (key == "@auto") key = null
        if (key == null && auto == null) {
            if (counts.put("unmatched|" + lab, 1) == null) log("UNMATCHED", lab.take(80), "", "no rule - left blank")
            continue
        }
        if (key == null && lab.isBlank()) continue   // a question whose title is off-screen: never guess it
        val want = if (key != null) rules.valueFor(key, scr.sub, rec, apps) else ""
        val useAuto = auto != null && (key == null || (want.isEmpty() && level >= 1))
        val name = key ?: ("AUTO: " + lab.take(60))
        if (useAuto) {
            val tag = "auto|${f.t}|$lab|$level"
            if (counts.containsKey(tag)) continue
            when (f.t) {
                "edit" -> {
                    val it = f.items[0]
                    val num = auto!!.numericField(it, lab)
                    val retry = level >= 2 && num && counts.containsKey("autofilled|$lab")
                    if (it.text.isBlank() || retry) {
                        counts[tag] = 1; counts["autofilled|$lab"] = 1
                        return Action("type", it, name, if (num) auto.number(level) else "[TEST] auto answer", auto = true)
                    }
                }
                "date" -> { counts[tag] = 1; return Action("date", f.items[0], name, "2025-06", auto = true) }
                "radio" -> if (f.items.none { it.checked }) { counts[tag] = 1; auto!!.pick(f.items)?.let { return Action("click", it, name, it.text, auto = true) } }
                "check" -> if (f.items.none { it.checked }) { counts[tag] = 1; auto!!.pick(f.items)?.let { return Action("click", it, name, it.text, auto = true) } }
                "spinner" -> if (f.items[0].text.isBlank() || DROPDOWN_TXT.containsMatchIn(f.items[0].text)) {
                    counts[tag] = 1; return Action("dropdown", f.items[0], name, "", auto = true)
                }
            }
            continue
        }
        if (key == null) continue
        when (f.t) {
            "edit" -> {
                val it = f.items[0]; val tag = "$key|edit"
                if (want.isNotEmpty() && norm(it.text.replace(",", "")) != norm(want) && (counts[tag] ?: 0) < 1) {
                    counts[tag] = (counts[tag] ?: 0) + 1; return Action("type", it, key, want)
                }
            }
            "date" -> {
                val tag = "$key|date"
                if (want.isNotEmpty() && (counts[tag] ?: 0) < 1) { counts[tag] = 1; return Action("date", f.items[0], key, want) }
            }
            "spinner" -> {
                val tag = "$key|dropdown"
                if (want.isNotEmpty() && norm(f.items[0].text) != norm(want) && (counts[tag] ?: 0) < 1) {
                    counts[tag] = 1; return Action("dropdown", f.items[0], key, want)
                }
            }
            "radio" -> {
                if (want.isEmpty()) continue
                val hit = matchOption(f.items, want)
                if (hit == null) {
                    if (atEnd && counts.put("$key|warn", 1) == null) log("WARN", key, want, "option not on screen")
                    // the test data value isn't an option here: choose a sensible one instead of leaving it empty
                    if (auto != null && (atEnd || level >= 1) && f.items.none { it.checked } && counts.put("$key|autofix", 1) == null)
                        auto.pick(f.items)?.let { return Action("click", it, key, it.text, auto = true) }
                    continue
                }
                val tag = "$key|${hit.text}"
                if (!hit.checked && (counts[tag] ?: 0) < 2) { counts[tag] = (counts[tag] ?: 0) + 1; return Action("click", hit, key, want) }
            }
            "check" -> {
                val wants = want.split(";").map { it.trim() }.filter { it.isNotEmpty() }
                val targets = HashSet<String>()
                for (w in wants) {
                    val hit = matchOption(f.items, w)
                    if (hit == null) { if (atEnd && counts.put("$key|$w|warn", 1) == null) log("WARN", key, w, "option not on screen") }
                    else targets.add(hit.text)
                }
                if (wants.isEmpty()) f.items.firstOrNull { norm(it.text) == "none" }?.let { targets.add(it.text) }
                for (it in f.items) {
                    val should = it.text in targets; val tag = "$key|${it.text}"
                    if (it.checked != should && (counts[tag] ?: 0) < 2) { counts[tag] = (counts[tag] ?: 0) + 1; return Action("click", it, key, it.text) }
                }
            }
        }
    }
    return null
}

private val MONTHS = listOf("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")

class Engine(
    private val dev: Device, private val rules: Rules, private val data: Dataset,
    private val rep: Reporter, private val ctl: Control,
    private val delayMs: Long = 300, private val maxSteps: Int = 900, private val dateOrder: String = "dmy",
    autoAnswer: Boolean = true, seed: Long = 7,
) {
    private val auto: Auto? = if (autoAnswer) Auto(seed) else null
    private var recNo = 0; private var done = 0; private var total = 0

    private fun check() {
        while (ctl.paused && !ctl.stopped) dev.sleep(200)
        if (ctl.stopped) throw StopRequested()
    }
    private fun log(kind: String, key: String, value: String, note: String) = rep.log(recNo, kind, key, value, note)
    private fun say(text: String) = rep.status(recNo, done, total, text)

    private fun read(): Pair<UiNode?, String> { val r = dev.root(); return r to (r?.signature() ?: "") }

    /** Wait until the screen differs from `before` (real phones lag), then let it settle. */
    private fun waitChange(before: String, timeoutMs: Long = 4000, settleMs: Long = 300): UiNode? {
        var waited = 0L; var r: UiNode? = null
        while (waited < timeoutMs) {
            dev.sleep(200); waited += 200; check()
            r = dev.root(); if (r != null && r.signature() != before) break
        }
        dev.sleep(settleMs); return dev.root() ?: r
    }

    /** Runs the given record numbers. Returns how many were saved as drafts. */
    fun run(ids: List<Int>, formAlreadyOpen: Boolean = false): Int {
        total = ids.size
        try {
            for ((n, id) in ids.withIndex()) {
                recNo = id
                val rec = data.record(id) ?: run { log("ERROR", "", "", "record $id is not in the test data"); return done }
                val apps = data.appliancesFor(id)
                say("Opening a new form…")
                if (!(formAlreadyOpen && n == 0) && !openNewForm()) {
                    log("ERROR", "", "", "could not open the form '${rules.formName}' - check the form name"); say("Could not open the form"); return done
                }
                val t0 = System.currentTimeMillis()
                if (runRecord(rec, apps)) {
                    done++; log("INFO", "", "", "record saved as DRAFT in ${(System.currentTimeMillis() - t0) / 1000}s"); say("Saved as draft")
                } else { say("Stopped with a problem - see log"); return done }
            }
            say("Finished: $done saved as drafts")
        } catch (e: StopRequested) {
            log("INFO", "", "", "stopped by user"); say("Stopped. Form left open: press Back > Ignore changes")
        }
        return done
    }

    private fun handleDialog(scr: Screen): Boolean {
        if (scr.dialog.isEmpty()) return false
        val names = scr.dialog.associateBy { norm(it.text) }
        for (k in listOf("do not add", "don t add", "dont add")) names[k]?.let {
            log("WARN", "repeat dialog", scr.dialogMsg.take(60), "declined 'add another'"); say("Pop-up: declined 'add another'"); dev.click(it.node!!); return true
        }
        for (k in listOf("ok", "close", "dismiss", "continue")) names[k]?.let {
            log("WARN", "dialog", scr.dialogMsg.take(80), "closed with ${it.text}"); say("Pop-up closed: ${scr.dialogMsg.take(40)}"); dev.click(it.node!!); return true
        }
        return false
    }

    private fun saveAsDraft(start: Screen): Boolean {
        var scr = start
        for (i in 0 until 3) {
            val m = scr.markFinal
            if (m != null && m.checked) {
                dev.click(m.node!!); log("INFO", "", "", "unticked 'Mark form as finalized'")
                scr = parseScreen(waitChange(dev.root()?.signature() ?: "", 2000) ?: return false, rules); continue
            }
            break
        }
        if (scr.markFinal?.checked == true) { log("ERROR", "", "", "could not untick 'Mark form as finalized' - NOT saving"); return false }
        val d = scr.saveDraft ?: run { log("ERROR", "", "", "save screen has no draft button (only Finalize) - NOT saving"); return false }
        say("Saving as DRAFT…")
        val before = dev.root()?.signature() ?: ""
        dev.click(d.node!!)
        val after = waitChange(before, 8000)
        if (after != null && parseScreen(after, rules).isEnd) { log("ERROR", "", "", "still on the save screen after tapping draft"); return false }
        log("SAVED", "", d.text, "draft"); return true
    }

    private fun runRecord(rec: Rec, apps: List<Rec>): Boolean {
        var counts = HashMap<String, Int>(); var atEnd = false; var level = 0
        var memory = HashMap<String, String>(); var scrolled = false; var curSub = ""
        fun newScreen() { counts = HashMap(); atEnd = false; level = 0; memory = HashMap(); scrolled = false; curSub = "" }
        for (step in 0 until maxSteps) {
            check()
            val (root, sig) = read()
            if (root == null) { dev.sleep(300); continue }
            val scr = parseScreen(root, rules)
            if (handleDialog(scr)) { waitChange(sig, 2000); continue }
            // the section title scrolls away on long screens: keep using the one seen at the top
            if (scr.sub.isEmpty() && curSub.isNotEmpty()) scr.sub = curSub else if (scr.sub.isNotEmpty()) curSub = scr.sub
            if (scr.isEnd) return saveAsDraft(scr)
            val act = plan(scr, rules, rec, apps, counts, atEnd, ::log, auto, level, memory, scrolled)
            if (act != null) {
                say((if (act.auto) "Auto: " else "") + "${act.key} → ${act.text}".take(120))
                var ok = true
                when (act.kind) {
                    "click" -> { dev.click(act.item.node!!); waitChange(sig, 1500, 150) }
                    "type" -> { dev.setText(act.item.node!!, act.text); dev.sleep(250) }
                    "date" -> { ok = enterDate(act); if (!ok) log("WARN", act.key, act.text, "date entry failed - check the picker") }
                    "dropdown" -> { ok = enterDropdown(act); if (!ok) log("WARN", act.key, act.text, "dropdown option not found") }
                }
                if (ok) log(if (act.auto) "AUTO" else "ANSWER", act.key, act.text, if (act.auto) "no rule/data - chosen by question type" else "")
                dev.sleep(delayMs); continue
            }
            if (scr.scrollable && !atEnd) {
                val moved = dev.scrollForward(root)
                if (moved) scrolled = true
                val after = if (moved) waitChange(sig, 1000, 200) else root
                if (!moved || after == null || parseScreen(after, rules).layoutSig == scr.layoutSig) atEnd = true
                continue
            }
            val nx = scr.next ?: run {
                dev.snapshot("r${recNo}_nonext", root); log("ERROR", scr.sid.take(60), "", "no Next button and not a save screen"); return false
            }
            say("Next ›  ${scr.sub.ifEmpty { scr.texts.firstOrNull() ?: "" }}".take(120))
            dev.click(nx.node!!)
            val afterRoot = waitChange(sig, 4000); dev.sleep(delayMs)
            val after = afterRoot?.let { parseScreen(it, rules) }
            if (after != null && after.sid == scr.sid && !after.isEnd && after.dialog.isEmpty()) {
                // The form would not move on: a required answer is missing or a value broke a rule. Try again, filling more.
                level++
                if (level == 1) dev.snapshot("r${recNo}_retry", afterRoot)
                if (auto == null || level > 5) {
                    dev.snapshot("r${recNo}_stuck", afterRoot)
                    log("ERROR", scr.sid.take(60), "", "stuck (required question not answered?) - snapshot saved"); return false
                }
                log("WARN", scr.sid.take(60), "", "form did not move on - retry $level, filling blanks / other values")
                say("Retrying this screen ($level)…")
                counts = HashMap(counts.filterKeys { it.startsWith("autofilled|") }); atEnd = false
            } else newScreen()
        }
        log("ERROR", "", "", "too many steps"); return false
    }

    /** Dropdown (spinner / "minimal" select): open it, pick the wanted option (or a sensible one), close it. */
    private fun enterDropdown(act: Action): Boolean {
        val before = dev.root()?.signature() ?: ""
        dev.click(act.item.node!!)
        var root = waitChange(before, 3000) ?: return false
        for (page in 0 until 8) {
            val opts = root.walk().filter {
                it.text.isNotBlank() && it.text.trim() != act.item.text.trim() && !it.id.endsWith("alertTitle") && !it.id.endsWith("title") &&
                    (it.cls.endsWith("CheckedTextView") || it.cls.endsWith("TextView") || it.cls.endsWith("RadioButton") || it.cls.endsWith("CheckBox")) &&
                    it.text.length < 120
            }.map { Item("opt", it.text.trim(), it) }.toList()
            val target = if (act.text.isEmpty()) auto?.pick(opts) else matchOption(opts, act.text)
            if (target != null) {
                dev.click(target.node!!); dev.sleep(500)
                dev.root()?.walk()?.firstOrNull { it.cls.endsWith("Button") && it.text.trim().uppercase() in setOf("OK", "DONE") }?.let { dev.click(it); dev.sleep(400) }
                return true
            }
            if (!dev.scrollForward(root)) break
            root = waitChange(root.signature(), 1200) ?: break
        }
        dev.back(); dev.sleep(400); return false
    }

    private fun clickText(root: UiNode, texts: List<String>): Boolean {
        for (t in texts) for (n in root.walk()) if (n.text.isNotEmpty() && n.text.contains(t, ignoreCase = true)) { dev.click(n); return true }
        return false
    }

    private fun openNewForm(): Boolean {
        dev.launch(rules.packageName); dev.sleep(2500)
        for (i in 0 until 8) {
            check()
            val (root, sig) = read()
            if (root == null) { dev.sleep(500); continue }
            val scr = parseScreen(root, rules)
            if (scr.next != null || scr.isEnd) return true
            if (!clickText(root, listOf(rules.formName)) && !clickText(root, listOf("Start new form", "Fill Blank Form", "Fill blank form"))) dev.back()
            waitChange(sig, 4000, 800)
        }
        return false
    }

    /** Calendar pickers (switch to typing) and scroll-wheel pickers. */
    private fun enterDate(act: Action): Boolean {
        val m0 = Regex("(\\d{4})-(\\d{2})").find(act.text) ?: return false
        val (y, m) = m0.destructured
        val before = dev.root()?.signature() ?: ""
        dev.click(act.item.node!!)
        var root = waitChange(before, 3000) ?: return false
        fun okButton(r: UiNode) = r.walk().firstOrNull { it.text.trim().uppercase() in setOf("OK", "SET", "DONE") }
        val wheels = root.walk().filter { it.id.endsWith("numberpicker_input") }.toList()
        if (wheels.isNotEmpty()) {
            val texts = wheels.map { it.text.trim().lowercase() }
            val want = HashMap<Int, String>()
            val nums = texts.indices.filter { Regex("\\d{1,2}").matches(texts[it]) }
            texts.forEachIndexed { k, t ->
                if (Regex("\\d{4}").matches(t)) want[k] = y
                else if (t.take(3) in MONTHS) want[k] = MONTHS[m.toInt() - 1].replaceFirstChar { it.uppercase() }
            }
            val hasName = texts.any { it.take(3) in MONTHS }
            if (hasName) nums.forEach { want[it] = "15" }
            else if (nums.size == 1) want[nums[0]] = m.toInt().toString()
            else if (nums.size == 2) {
                val (day, mon) = if (dateOrder == "dmy") nums[0] to nums[1] else nums[1] to nums[0]
                want[day] = "15"; want[mon] = m.toInt().toString()
            }
            for ((k, v) in want) if (texts[k] != v.lowercase()) { dev.setText(wheels[k], v); dev.sleep(300) }
            root = dev.root() ?: return false
            okButton(root)?.let { dev.click(it); dev.sleep(600); return true }
            dev.back(); return false
        }
        root.walk().firstOrNull { it.desc.contains("text input", ignoreCase = true) }?.let {
            dev.click(it); root = waitChange(root.signature(), 2000) ?: root
        }
        val ed = root.walk().firstOrNull { it.cls.endsWith("EditText") } ?: run { dev.back(); return false }
        val hint = ed.text.lowercase()
        val s = if (hint.startsWith("dd") || (!hint.startsWith("mm") && dateOrder == "dmy")) "15/$m/$y" else "$m/15/$y"
        dev.setText(ed, s); dev.sleep(300)
        root = dev.root() ?: return false
        okButton(root)?.let { dev.click(it); dev.sleep(600); return true }
        dev.back(); return false
    }
}

/** "1", "1-44", "2,5,7-9" -> record numbers that exist in the data. Throws with a readable message. */
fun parseRange(text: String, available: List<Int>): List<Int> {
    val out = ArrayList<Int>()
    for (part in text.split(",").map { it.trim() }.filter { it.isNotEmpty() }) {
        val ab = part.split("-").map { it.trim() }
        val a = ab[0].toIntOrNull() ?: throw IllegalArgumentException("'$part' is not a number")
        val b = if (ab.size > 1) ab[1].toIntOrNull() ?: throw IllegalArgumentException("'$part' is not a range like 2-44") else a
        if (b < a) throw IllegalArgumentException("'$part': the second number must be bigger")
        out.addAll(a..b)
    }
    if (out.isEmpty()) throw IllegalArgumentException("Type which records to run, e.g. 1 or 1-44")
    val missing = out.filter { it !in available }
    if (missing.isNotEmpty()) throw IllegalArgumentException("Not in the test data: ${missing.take(5).joinToString()}" + if (missing.size > 5) "…" else "")
    return out.distinct()
}
