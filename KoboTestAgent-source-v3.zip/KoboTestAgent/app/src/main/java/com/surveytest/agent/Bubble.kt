package com.surveytest.agent

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * The small floating panel shown over KoboCollect during a run.
 * Shows the current action; Pause/Resume, Stop; drag it anywhere; collapse it to a dot.
 * It is an accessibility overlay, so no "draw over other apps" permission is needed.
 */
class Bubble(
    private val svc: AccessibilityService,
    private val onPauseToggle: () -> Boolean,
    private val onStop: () -> Unit,
    private val onClose: () -> Unit,
) {
    private val wm = svc.getSystemService(WindowManager::class.java)
    private var root: FrameLayout? = null
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var dot: TextView
    private lateinit var title: TextView
    private lateinit var status: TextView
    private lateinit var pauseBtn: Button
    private lateinit var stopBtn: Button
    private var finished = false
    private var total = 0

    private fun dp(v: Int) = (v * svc.resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    fun show(totalRecords: Int) {
        total = totalRecords; finished = false
        if (root != null) { reset(); return }
        val ctx = svc
        panel = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; background = bg(Color.argb(235, 28, 32, 38), 14)
            setPadding(dp(12), dp(8), dp(12), dp(10))
            layoutParams = FrameLayout.LayoutParams(dp(260), FrameLayout.LayoutParams.WRAP_CONTENT)
        }
        val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        title = TextView(ctx).apply {
            setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val collapse = TextView(ctx).apply {
            text = "–"; setTextColor(Color.WHITE); textSize = 20f; setPadding(dp(12), 0, dp(4), 0)
            contentDescription = "Collapse"; setOnClickListener { setCollapsed(true) }
        }
        header.addView(title); header.addView(collapse)
        val tag = TextView(ctx).apply { text = "TEST DATA · DRAFTS ONLY"; setTextColor(Color.rgb(255, 196, 0)); textSize = 10f; typeface = Typeface.DEFAULT_BOLD }
        status = TextView(ctx).apply { setTextColor(Color.rgb(220, 226, 232)); textSize = 13f; maxLines = 3; setPadding(0, dp(6), 0, dp(8)) }
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(label: String, color: Int) = Button(ctx).apply {
            text = label; isAllCaps = false; textSize = 13f; setTextColor(Color.WHITE); background = bg(color, 8)
            minHeight = dp(36); minimumHeight = dp(36)
            layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(6) }
        }
        pauseBtn = btn("Pause", Color.rgb(60, 110, 190)).apply {
            setOnClickListener { if (!finished) { val p = onPauseToggle(); text = if (p) "Resume" else "Pause"; if (p) status.text = "Paused. You can fix the screen by hand, then tap Resume." } }
        }
        stopBtn = btn("Stop", Color.rgb(190, 60, 60)).apply {
            setOnClickListener { if (finished) onClose() else { onStop(); status.text = "Stopping…"; isEnabled = false } }
        }
        row.addView(pauseBtn); row.addView(stopBtn)
        panel.addView(header); panel.addView(tag); panel.addView(status); panel.addView(row)

        dot = TextView(ctx).apply {
            gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 11f; typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(235, 40, 120, 80)) }
            layoutParams = FrameLayout.LayoutParams(dp(54), dp(54)); visibility = View.GONE
        }
        root = FrameLayout(ctx).apply { addView(panel); addView(dot) }
        draggable(header) { }
        draggable(title) { }
        draggable(dot) { setCollapsed(false) }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(90) }
        wm.addView(root, params)
        reset()
    }

    /** Same bubble, used while you fill a form by hand and the app saves each screen. */
    fun showRecording() {
        show(0)
        title.text = "Recording screens"; status.text = "Fill the form by hand. Each new screen is saved."
        pauseBtn.visibility = View.GONE; stopBtn.text = "Stop recording"; dot.text = "REC"
    }

    private fun reset() {
        pauseBtn.visibility = View.VISIBLE
        title.text = "Kobo Test Agent"; status.text = "Starting…"; pauseBtn.text = "Pause"; pauseBtn.isEnabled = true
        stopBtn.text = "Stop"; stopBtn.isEnabled = true; dot.text = "0/$total"; setCollapsed(false)
    }

    fun update(record: Int, done: Int, total: Int, text: String, paused: Boolean) {
        if (root == null) return
        title.text = if (record > 0) "Record $record  ·  $done/$total saved" else if (total == 0) "Recording screens · $done saved" else "Kobo Test Agent"
        if (!paused) status.text = text
        dot.text = if (total == 0) "$done" else "$done/$total"
    }

    fun finished(msg: String) {
        if (root == null) return
        finished = true; title.text = "Run finished"; status.text = msg
        pauseBtn.isEnabled = false; stopBtn.text = "Close"; stopBtn.isEnabled = true; dot.text = "✓"
    }

    fun hide() { root?.let { try { wm.removeView(it) } catch (_: Exception) {} }; root = null }

    private fun setCollapsed(c: Boolean) {
        panel.visibility = if (c) View.GONE else View.VISIBLE
        dot.visibility = if (c) View.VISIBLE else View.GONE
    }

    /** Drag the bubble by this view; a short tap runs onTap. */
    @SuppressLint("ClickableViewAccessibility")
    private fun draggable(v: View, onTap: () -> Unit) {
        val slop = ViewConfiguration.get(svc).scaledTouchSlop
        var sx = 0f; var sy = 0f; var px = 0; var py = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; px = params.x; py = params.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) { params.x = px + dx.toInt(); params.y = py + dy.toInt(); root?.let { wm.updateViewLayout(it, params) } }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) onTap(); true }
                else -> false
            }
        }
    }
}
