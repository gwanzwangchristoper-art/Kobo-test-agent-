package com.surveytest.agent

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import com.surveytest.agent.core.Dataset
import com.surveytest.agent.core.FormMap
import com.surveytest.agent.core.Json
import com.surveytest.agent.core.Rules
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Where the app keeps its rules, test data, settings and log. */
object AppStore {
    private fun prefs(c: Context) = c.getSharedPreferences("agent", Context.MODE_PRIVATE)

    fun defaultRulesText(c: Context): String = c.assets.open("rules.json").bufferedReader().use { it.readText() }

    /*
     * Rules = rules learned from you (answers given when the agent asked) + the app's built-in rules.
     * Before v11 a learned answer saved a frozen copy of ALL rules, so later app updates (new / fixed rules) were
     * ignored on your phone. Now only the learned rules are kept apart; the built-in rules always come from the app.
     * Rules you edit by hand on the Rules screen are kept exactly as you saved them (Reset goes back to built-in).
     */
    private fun extraFile(c: Context) = File(c.filesDir, "learned_rules.json")
    private fun editedFile(c: Context) = File(c.filesDir, "rules.json")

    private fun extraRules(c: Context): MutableList<Map<String, Any?>> = try {
        @Suppress("UNCHECKED_CAST")
        ((Json.parse(extraFile(c).takeIf { it.exists() }?.readText() ?: "[]") as? List<*>)?.mapNotNull { it as? Map<String, Any?> } ?: emptyList()).toMutableList()
    } catch (_: Exception) { ArrayList() }

    /** One-time move: an old frozen rules.json (not edited by hand) gives up its learned / extra rules and is removed. */
    @Synchronized private fun migrateRules(c: Context) {
        val f = editedFile(c)
        if (!f.exists() || get(c, "rulesEdited", "") == "1") return
        try {
            @Suppress("UNCHECKED_CAST")
            val saved = ((Json.parse(f.readText()) as Map<String, Any?>)["rules"] as? List<*>)?.mapNotNull { it as? Map<String, Any?> } ?: emptyList()
            @Suppress("UNCHECKED_CAST")
            val builtin = ((Json.parse(defaultRulesText(c)) as Map<String, Any?>)["rules"] as? List<*>)?.mapNotNull { it as? Map<String, Any?> } ?: emptyList()
            fun key(r: Map<String, Any?>) = "${r["section"]}|${r["question"]}"
            val builtinKeys = builtin.map { key(it) }.toSet()
            // keep what you taught it; drop old copies of built-in rules (the app's current ones are used instead)
            val keep = saved.filter { it["learned"] == true || (key(it) !in builtinKeys && (it["column"] as? String)?.startsWith("=") == true) }
            val extra = extraRules(c); keep.forEach { k -> if (extra.none { key(it) == key(k) }) extra.add(k) }
            extraFile(c).writeText(Json.write(extra))
        } catch (_: Exception) {}
        f.delete()
    }

    /** The full rules text: edited by hand, or learned + built-in. */
    fun rulesText(c: Context): String {
        migrateRules(c)
        editedFile(c).takeIf { it.exists() && get(c, "rulesEdited", "") == "1" }?.let { return it.readText() }
        val base = defaultRulesText(c)
        val extra = extraRules(c)
        if (extra.isEmpty()) return base
        return try {
            @Suppress("UNCHECKED_CAST")
            val root = LinkedHashMap(Json.parse(base) as Map<String, Any?>)
            root["rules"] = extra + ((root["rules"] as? List<*>) ?: emptyList<Any?>())
            Json.write(root)
        } catch (_: Exception) { base }
    }
    fun saveRulesText(c: Context, text: String) { Rules.parse(text); editedFile(c).writeText(text); put(c, "rulesEdited", "1") }
    fun resetRules(c: Context) { editedFile(c).delete(); extraFile(c).delete(); put(c, "rulesEdited", "") }

    /** Store a rule learned from an answer given by hand (top of the list, so it wins). */
    @Synchronized fun saveLearned(c: Context, pattern: String, value: String) {
        try {
            val rule = linkedMapOf<String, Any?>("section" to null, "question" to pattern, "column" to "=$value", "learned" to true)
            if (editedFile(c).exists() && get(c, "rulesEdited", "") == "1") {
                @Suppress("UNCHECKED_CAST")
                val root = LinkedHashMap(Json.parse(editedFile(c).readText()) as Map<String, Any?>)
                val rules = ArrayList((root["rules"] as? List<*>) ?: emptyList<Any?>())
                rules.removeAll { (it as? Map<*, *>)?.get("question") == pattern }
                rules.add(0, rule); root["rules"] = rules
                editedFile(c).writeText(Json.write(root))
            } else {
                val extra = extraRules(c); extra.removeAll { it["question"] == pattern }; extra.add(0, rule)
                extraFile(c).writeText(Json.write(extra))
            }
        } catch (_: Exception) {}
    }

    /** Rules with the form name / app chosen on the main screen applied on top. */
    fun rules(c: Context): Rules {
        val r = try { Rules.parse(rulesText(c)) } catch (e: Exception) { Rules.parse(defaultRulesText(c)) }
        prefs(c).getString("formName", null)?.takeIf { it.isNotBlank() }?.let { r.formName = it }
        return r
    }

    fun dataset(c: Context): Dataset? = File(c.filesDir, "dataset.json").takeIf { it.exists() }?.let {
        try { Dataset.fromJson(it.readText()) } catch (e: Exception) { null }
    }
    fun saveDataset(c: Context, d: Dataset) = File(c.filesDir, "dataset.json").writeText(d.toJson())

    fun get(c: Context, k: String, def: String) = prefs(c).getString(k, def) ?: def
    fun put(c: Context, k: String, v: String) = prefs(c).edit().putString(k, v).apply()

    // ---------------- log
    fun logFile(c: Context) = File(c.getExternalFilesDir(null) ?: c.filesDir, "agent_log.csv")
    fun snapshotDir(c: Context) = File(c.getExternalFilesDir(null) ?: c.filesDir, "snapshots").apply { mkdirs() }
    private val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    @Synchronized fun log(c: Context, record: Int, kind: String, key: String, value: String, note: String) {
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val f = logFile(c)
        if (!f.exists()) f.writeText("time,record,kind,question,value,note\n")
        f.appendText(listOf(ts.format(Date()), record.toString(), kind, key, value, note).joinToString(",") { q(it) } + "\n")
    }
    fun logTail(c: Context, lines: Int = 300): String = logFile(c).takeIf { it.exists() }?.readLines()?.takeLast(lines)?.joinToString("\n") ?: "(log is empty)"
    fun clearLog(c: Context) { logFile(c).delete(); snapshotDir(c).listFiles()?.forEach { it.delete() } }

    // ---------------- files imported (shown under the Import button)
    /** Remember an imported file: newest first, one line per file name, at most 15. */
    fun addImported(c: Context, name: String, summary: String) {
        val now = SimpleDateFormat("d MMM HH:mm", Locale.US).format(Date())
        val list = imported(c).filter { it["name"] != name }.toMutableList()
        list.add(0, mapOf("name" to name, "summary" to summary, "time" to now))
        put(c, "imported", Json.write(list.take(15), pretty = false))
    }
    fun imported(c: Context): List<Map<String, String>> = try {
        (Json.parse(get(c, "imported", "[]")) as? List<*>)?.mapNotNull { e -> (e as? Map<*, *>)?.entries?.associate { it.key.toString() to (it.value?.toString() ?: "") } } ?: emptyList()
    } catch (_: Exception) { emptyList() }
    fun clearImported(c: Context) = put(c, "imported", "[]")

    // ---------------- "View form" output
    fun exploreWorkDir(c: Context) = File(c.getExternalFilesDir(null) ?: c.filesDir, "view_form").apply { mkdirs() }
    fun clearExploreWork(c: Context) { exploreWorkDir(c).deleteRecursively(); exploreWorkDir(c) }
    fun lastExploreZip(c: Context): File? = get(c, "lastExploreZip", "").takeIf { it.isNotEmpty() }?.let { File(it) }?.takeIf { it.exists() }

    /**
     * Write the View form zip (form map, routes, questions list, screenshots), keep it in the app and copy it to
     * Downloads/KoboTestAgent. Returns the zip and a plain description of where it is.
     */
    fun writeExploreZip(c: Context, map: FormMap, stamp: String): Pair<File, String> {
        val safe = map.formName.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').take(40).ifEmpty { "form" }
        val name = "view_form_${safe}_$stamp.zip"
        val outDir = File(c.getExternalFilesDir(null) ?: c.filesDir, "exports").apply { mkdirs() }
        val zip = File(outDir, name)
        ZipOutputStream(zip.outputStream().buffered()).use { z ->
            fun text(entry: String, body: String) { z.putNextEntry(ZipEntry(entry)); z.write(body.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            text("README.txt", "View form - ${map.formName}\n\nform_map.txt   every screen, question, option, data column and where each answer leads\n" +
                "routes.txt     each pass through the form with the answers used\nquestions.csv  one row per question (open in Excel) - use it to build accurate test data\n" +
                "form_map.json  the same for other tools\nscreens/       screenshot (.jpg) and text reading (.txt) of every screen, named S001, S002 ... as in form_map.txt\n\n" +
                "Nothing was saved in KoboCollect: every pass was left with 'Ignore changes'.\n")
            text("form_map.txt", map.formMapText())
            text("routes.txt", map.routesText())
            text("questions.csv", "\uFEFF" + map.questionsCsv())
            text("form_map.json", map.toJson())
            val shots = File(exploreWorkDir(c), "screens").listFiles()?.sortedBy { it.name } ?: emptyList()
            for (f in shots) { z.putNextEntry(ZipEntry("screens/" + f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry() }
        }
        put(c, "lastExploreZip", zip.absolutePath)
        var where = "the app (tap 'Share View form zip')"
        try {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/KoboTestAgent")
            }
            val uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                c.contentResolver.openOutputStream(uri)?.use { out -> zip.inputStream().use { it.copyTo(out) } }
                where = "Downloads/KoboTestAgent"
            }
        } catch (_: Exception) {}
        return zip to where
    }
}
