import com.surveytest.agent.core.*
import java.io.File

fun check(c: Boolean, msg: () -> String) { if (!c) throw AssertionError(msg()) }
val W = 1080; val H = 2400
const val CR = "Household Energy and Living Standards Survey > "

// ---------------- simulated KoboCollect
class Fake(val screens: List<Pair<String, List<Pair<String, String>>>>, val end: String = "new", val dialogAt: Int? = null) : Device {
    var i = 0; val sel = HashMap<Pair<Int, Int>, String>(); val txt = LinkedHashMap<Pair<Int, Int>, String>()
    var saved: String? = null; var mark = true; var dialogOpen = false; var declined = false; var launched = 0
    var onMenu = false; var popup: Int? = null; var toolbarSaves = 0
    private var nodes = listOf<UiNode>()
    init { build() }
    private fun n(cls: String, t: String, l: Int, tp: Int, r: Int, b: Int, id: String = "", checked: Boolean = false, ref: Any? = null) =
        UiNode("android.widget.$cls", t, "", id, l, tp, r, b, checked, false, emptyList(), ref)
    fun build() {
        val out = ArrayList<UiNode>()
        if (onMenu) { out += n("Button", "Start new form", 50, 800, 1030, 950, ref = "start"); nodes = out; return }
        if (dialogOpen) {
            out += n("TextView", "Add another 'appliance' group?", 100, 900, 980, 1000, id = "android:id/message")
            out += n("Button", "Do not add", 100, 1100, 500, 1200, id = "android:id/button2", ref = "dna")
            out += n("Button", "Add", 580, 1100, 980, 1200, id = "android:id/button1", ref = "add"); nodes = out; return
        }
        if (i >= screens.size) {
            when (end) {
                "new" -> { out += n("Button", "Save as draft", 50, 1500, 500, 1650, ref = "draft"); out += n("Button", "Finalize", 550, 1500, 1030, 1650, ref = "final") }
                "old" -> { out += n("CheckBox", "Mark form as finalized", 50, 1300, 1030, 1420, checked = mark, ref = "mark"); out += n("Button", "Save Form and Exit", 50, 1500, 1030, 1650, ref = "saveexit") }
                else -> out += n("Button", "Finalize", 550, 1500, 1030, 1650, ref = "final")
            }
            nodes = out; return
        }
        var y = 500
        out += n("TextView", "Full Scale Data Col…", 50, 150, 700, 260)
        out += UiNode("android.widget.Button", "", "Save Form", "org.koboc.collect.android:id/menu_save", 800, 150, 900, 260, false, false, emptyList(), "toolbarsave")
        out += n("TextView", screens[i].first, 50, 330, 1030, 440)
        for ((k, c) in screens[i].second.withIndex()) {
            val (t, v) = c
            if (t == "label") { out += n("TextView", v, 50, y, 1030, y + 90); y += 100 }
            else {
                if (t == "req" || t == "min2") continue
                if (popup == k) {   // dropdown list open
                    nodes = v.split("|").mapIndexed { j, o -> n("CheckedTextView", o, 100, 600 + j * 120, 980, 700 + j * 120, ref = "opt$k|$o") }; return
                }
                val cls = mapOf("radio" to "RadioButton", "check" to "CheckBox", "edit" to "EditText", "num" to "EditText", "spinner" to "Spinner")[t]!!
                val text = if (t == "edit" || t == "num") txt[i to k] ?: "" else if (t == "spinner") sel[i to k] ?: "Select One Answer" else v
                out += UiNode("android.widget.$cls", text, "", "", 50, y, 1030, y + 130, (i to k) in sel && t != "spinner", false, emptyList(), k, numeric = t == "num"); y += 150
            }
        }
        out += n("Button", "Back", 50, 2250, 500, 2380); out += n("Button", "Next", 560, 2250, 1030, 2380, ref = "next")
        nodes = out
    }
    override fun root() = UiNode("android.widget.FrameLayout", "", "", "", 0, 0, W, H, false, false, nodes)
    override fun click(n: UiNode): Boolean {
        when (val r = n.ref) {
            "next" -> if (screenOk()) { i++; if (i == dialogAt) dialogOpen = true }
            "toolbarsave" -> toolbarSaves++
            "dna" -> { dialogOpen = false; declined = true }
            "add" -> throw AssertionError("pressed Add on repeat dialog")
            "draft" -> { saved = "draft"; onMenu = true }
            "saveexit" -> { saved = if (mark) "final" else "draft"; onMenu = true }
            "final" -> saved = "final"
            "mark" -> mark = !mark
            "start" -> { onMenu = false; i = 0 }
            is String -> if (r.startsWith("opt")) { val k = r.removePrefix("opt").substringBefore('|').toInt(); sel[i to k] = r.substringAfter('|'); popup = null }
            is Int -> {
                val (t, v) = screens[i].second[r]
                if (t == "spinner") { popup = r; build(); return true }
                if (t == "radio") { screens[i].second.indices.forEach { sel.remove(i to it) }; sel[i to r] = v }
                else if (t == "check") { if ((i to r) in sel) sel.remove(i to r) else sel[i to r] = v }
            }
        }
        build(); return true
    }
    /** 'req' on a screen = every answer needed; 'min2' = numbers must be 2 or more. */
    fun screenOk(): Boolean {
        val sc = screens.getOrNull(i)?.second ?: return true
        val req = sc.any { it.first == "req" }; val min2 = sc.any { it.first == "min2" }
        for ((k, c) in sc.withIndex()) {
            val t = c.first
            if (req && (t == "edit" || t == "num") && (txt[i to k] ?: "").isBlank()) return false
            if (req && t == "spinner" && (i to k) !in sel) return false
            if (min2 && t == "num" && ((txt[i to k] ?: "0").toIntOrNull() ?: 0) < 2) return false
        }
        if (req) { val radios = sc.indices.filter { sc[it].first == "radio" }; if (radios.isNotEmpty() && radios.none { (i to it) in sel }) return false }
        return true
    }
    override fun setText(n: UiNode, text: String): Boolean { txt[i to (n.ref as Int)] = text; build(); return true }
    override fun scrollForward(root: UiNode) = false
    override fun back() {}
    override fun launch(pkg: String): Boolean { launched++; return true }
    override fun sleep(ms: Long) {}
    override fun snapshot(name: String, root: UiNode?) {}
}

fun L(t: String) = "label" to t
val SCREENS = listOf(
    CR + "A. Household profile" to listOf(L("A1. Sex of respondent"), "radio" to "Female", "radio" to "Male", "radio" to "Prefer not to say"),
    CR + "A. Household profile" to listOf(L("A3. Total number of people usually living and eating in this household"), "edit" to ""),
    CR + "A. Household profile" to listOf(L("A8. What do working-age members of this household currently do for income?"), L("Select all that apply."),
        "check" to "Farming", "check" to "Trading or shop", "check" to "Casual or daily labour", "check" to "Other"),
    CR + "B. Energy access > B1a. When did the household connect, and what did it pay to connect?" to listOf(L("Connection fee paid (NGN)"), "edit" to "",
        L("House wiring cost (NGN)"), "edit" to "", L("Connection subsidised or free?"), "radio" to "Subsidised", "radio" to "Free", "radio" to "Not subsidised"),
    CR + "B. Energy access > B9. Mini-grid payment" to listOf(L("Primary or backup source?"), "radio" to "Primary", "radio" to "Backup",
        L("Amount spent in the last 30 days (NGN)"), "edit" to "", L("Units or quantity where known (e.g. litres, pieces)"), "edit" to ""),
    CR + "C. Appliances > C1. Television or radio" to listOf(L("Number owned"), "edit" to "", L("Acquired after mini-grid connection? [WP5.2 only]"),
        "radio" to "Yes", "radio" to "No", L("C1a. Number working (W)"), "edit" to "", L("C1a. Number partly working (PW)"), "edit" to ""),
    CR + "E. Enumerator record" to listOf(L("E3. Enumerator observations and any difficulty encountered"), "edit" to ""),
)

class Rep : Reporter {
    val logs = ArrayList<String>()
    override fun status(record: Int, done: Int, total: Int, text: String) {}
    override fun log(record: Int, kind: String, key: String, value: String, note: String) { logs += "$record $kind $key $value $note" }
}

fun main(args: Array<String>) {
    val root = args[0]
    val rules = Rules.parse(File("$root/app/src/main/assets/rules.json").readText())
    // 1. resolver cases from the Python test
    val cases = Json.parse(File(args[1]).readText()) as List<*>
    val bad = cases.map { it as List<*> }.filter { rules.resolve(it[0] as String, it[1] as String) != it[2] }
    check(bad.isEmpty()) { "resolver mismatches: " + bad.joinToString("\n") { "${it[1]} -> ${rules.resolve(it[0] as String, it[1] as String)} (want ${it[2]})" } }
    println("resolver: ${cases.size} screens OK")

    // 2. generator invariants
    val ds = DataGen(1).generate(44)
    check(ds.records.size == 44) { "count" }
    for (r in ds.records) {
        val sum = listOf("A4_Children_under_18", "A4_Young_women_18_35", "A4_Young_men_18_35", "A4_Women_36plus", "A4_Men_36plus").sumOf { r[it]!!.toInt() }
        check(sum == r["A3_Household_size"]!!.toInt()) { "composition sum, record ${r["Record"]}" }
        if (r["D5_Quality_of_life_change"]!!.isNotEmpty()) check(r["B1_Connected_to_minigrid"] == "Yes - currently connected") { "D only for connected" }
        r["D6_Likelihood_to_recommend_0_10"]!!.toIntOrNull()?.let { check(it in 0..10) { "D6 range" } }
        if (r["Site_type"] != "WP5.2") check(r["B1_Connected_to_minigrid"] == "") { "WP only" }
    }
    val cols = ds.records[0].keys
    val missing = rules.plainColumns().filter { it !in cols }
    check(missing.isEmpty()) { "rules point at columns the generator does not make: $missing" }
    check(ds.appliances.isNotEmpty() && ds.appliances.all { it["Appliance"]!!.isNotEmpty() }) { "appliances" }
    // determinism + JSON round trip
    check(DataGen(1).generate(44).toJson() == ds.toJson()) { "same seed should give same data" }
    check(Dataset.fromJson(ds.toJson()).toJson() == ds.toJson()) { "json round trip" }
    println("generator: 44 records, ${ds.appliances.size} appliance rows, all checks OK. Sample: " + ds.records[0].entries.take(8).joinToString { "${it.key}=${it.value}" })

    // 3. xlsx + csv import
    val (imp, msg) = Dataset.import("sample_test_data_44.xlsx", File(args[2]).readBytes(), null)
    check(imp.records.size == 44 && imp.appliances.isNotEmpty()) { "xlsx import" }
    check(imp.record(1)!!["A3_Household_size"]!!.matches(Regex("\\d+"))) { "xlsx numbers: ${imp.record(1)!!["A3_Household_size"]}" }
    println("xlsx: $msg; record 1 sex=${imp.record(1)!!["A1_Sex"]} size=${imp.record(1)!!["A3_Household_size"]}")
    val csv = "Record,A1_Sex,E3_Enumerator_observations\n1,Male,\"Said \"\"hello\"\", left\"\n2,Female,\n"
    val (c, _) = Dataset.import("t.csv", csv.toByteArray(), null)
    check(c.record(1)!!["E3_Enumerator_observations"] == "Said \"hello\", left" && c.ids() == listOf(1, 2)) { "csv: ${c.records}" }
    println("csv import OK")

    // 4. engine on simulated phone
    val rec = mapOf("Record" to "1", "A1_Sex" to "Male", "A3_Household_size" to "8", "A8_Household_work" to "Farming; Casual or daily labour",
        "B1a_Connection_fee_NGN" to "20000", "B1a_Wiring_cost_NGN" to "5000", "B1a_Subsidised_or_free" to "Not subsidised",
        "B9_Primary_source" to "Mini-grid payment", "B9_Minigrid_NGN" to "12000", "E3_Enumerator_observations" to "No observations")
    val apps = listOf(mapOf("Record" to "1", "Appliance" to "Television/radio", "Number_owned" to "2", "Acquired_after_minigrid" to "No",
        "Number_working_W" to "1", "Number_partly_working_PW" to "1"))
    val data = Dataset(listOf(rec, mapOf("Record" to "2", "A1_Sex" to "Female")), apps, "t")
    run {
        val f = Fake(SCREENS); val rep = Rep()
        val done = Engine(f, rules, data, rep, Control(), delayMs = 0).run(listOf(1), formAlreadyOpen = true)
        check(done == 1 && f.saved == "draft") { "fill: done=$done saved=${f.saved}\n" + rep.logs.joinToString("\n") }
        check(setOf("Male", "Farming", "Casual or daily labour", "Not subsidised", "Primary", "No").all { it in f.sel.values }) { "selected ${f.sel.values}" }
        check("Trading or shop" !in f.sel.values && "Other" !in f.sel.values) { "extra ticks ${f.sel.values}" }
        check(f.txt.values.toList() == listOf("8", "20000", "5000", "12000", "2", "1", "1", "[TEST] No observations")) { "typed ${f.txt.values}" }
        println("engine fill OK: ${f.txt.values} ${f.sel.values.sorted()}")
    }
    run {
        val f = Fake(SCREENS, end = "old"); val rep = Rep()
        check(Engine(f, rules, data, rep, Control(), delayMs = 0).run(listOf(1), true) == 1 && f.saved == "draft" && !f.mark) { "old odk: ${f.saved} ${f.mark}" }
        println("old save screen: unticked finalized, saved draft OK")
    }
    run {
        val f = Fake(SCREENS, end = "finalonly"); val rep = Rep()
        check(Engine(f, rules, data, rep, Control(), delayMs = 0).run(listOf(1), true) == 0 && f.saved == null) { "finalize-only should refuse" }
        println("finalize-only screen: refused OK")
    }
    run {
        val f = Fake(SCREENS, dialogAt = 3); val rep = Rep()
        check(Engine(f, rules, data, rep, Control(), delayMs = 0).run(listOf(1), true) == 1 && f.declined && f.saved == "draft") { "dialog" }
        println("repeat pop-up: declined OK")
    }
    run {   // two records back to back, opening the form from the menu
        val f = Fake(SCREENS); f.onMenu = true; f.build(); val rep = Rep()
        val done = Engine(f, rules, data, rep, Control(), delayMs = 0).run(listOf(1, 2))
        check(done == 2 && f.launched == 2) { "two records: done=$done launched=${f.launched}\n" + rep.logs.takeLast(10).joinToString("\n") }
        println("two records from the app menu OK")
    }
    check(true) {""}
    run {   // never-seen questions, dropdowns, required blanks and number limits
        val sc = listOf(
            CR + "A. Household profile" to listOf(L("A1. Sex of respondent"), "spinner" to "Female|Male|Prefer not to say", "req" to ""),
            CR + "Z. New section" to listOf(L("Z9. Is there a borehole in this compound?"), "radio" to "Other", "radio" to "Do not know", "radio" to "Yes", "radio" to "No", "req" to ""),
            CR + "Z. New section" to listOf(L("Z10. How many goats does the household keep?"), "num" to "", "req" to "", "min2" to ""),
            CR + "Z. New section" to listOf(L("Z11. Describe the roof material"), "edit" to "", "req" to ""),
            CR + "Z. New section" to listOf(L("Z12. Favourite crop"), "spinner" to "Other|Maize|Cassava", "req" to ""),
            CR + "B. Energy access > B1a. When did the household connect, and what did it pay to connect?" to listOf(L("House wiring cost (NGN)"), "num" to "", "req" to ""),
        )
        val f = Fake(sc); val rep = Rep()
        val done = Engine(f, rules, data, rep, Control(), delayMs = 0).run(listOf(1), true)
        check(done == 1 && f.saved == "draft" && f.toolbarSaves == 0) { "auto run: done=$done saved=${f.saved} toolbar=${f.toolbarSaves}\n" + rep.logs.joinToString("\n") }
        check(f.sel[0 to 1] == "Male") { "dropdown with rule: ${f.sel}" }
        check(f.sel[1 to 3] == "Yes") { "auto radio should avoid Other/Do not know/No: ${f.sel}" }
        check((f.txt[2 to 1] ?: "0").toInt() >= 2) { "number limit retry: ${f.txt}" }
        check(f.txt[3 to 1] == "[TEST] auto answer") { "auto text: ${f.txt}" }
        check(f.sel[4 to 1] in setOf("Maize", "Cassava")) { "auto dropdown: ${f.sel}" }
        check(!f.txt[5 to 1].isNullOrBlank()) { "required blank filled: ${f.txt}" }
        println("never-seen questions OK: " + rep.logs.filter { " AUTO " in it || " WARN " in it }.joinToString(" | ") { it.substringAfter(" ").take(70) })
    }
    run {   // the toolbar Save icon must never count as the end of the form
        val f = Fake(SCREENS); val rep = Rep()
        check(Engine(f, rules, data, rep, Control(), delayMs = 0).run(listOf(1), true) == 1 && f.toolbarSaves == 0 && f.saved == "draft") { "toolbar save" }
        println("toolbar Save icon ignored OK")
    }
    run {   // stop request
        val f = Fake(SCREENS); val ctl = Control(); ctl.stopped = true; val rep = Rep()
        check(Engine(f, rules, data, rep, ctl, delayMs = 0).run(listOf(1), true) == 0 && f.saved == null) { "stop" }
        println("stop button OK")
    }
    // 5. rules editor errors are readable
    try { Rules.parse("{\n \"formName\": \"x\",\n \"rules\": [ {\"question\": \"(\", \"column\": \"A\"} ]\n"); throw AssertionError("should fail") }
    catch (e: Json.JsonError) { println("rules error message: ${e.message}") }
    rangeTest(); explainTest(rules); println("ALL CORE TESTS PASSED")
}
fun rangeTest() {
    check(parseRange("1-3, 7", (1..44).toList()) == listOf(1, 2, 3, 7)) { "range" }
    try { parseRange("40-50", (1..44).toList()); throw AssertionError("x") } catch (e: IllegalArgumentException) { println("range error: ${e.message}") }
}
fun explainTest(rules: Rules) {
    val f = Fake(SCREENS); val txt = explain(f.root(), rules)
    check("A1_Sex" in txt && "[radio]" in txt) { txt }
    println("explain OK:\n" + txt.lines().take(6).joinToString("\n"))
}
