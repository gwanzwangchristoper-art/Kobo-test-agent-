package com.surveytest.agent

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.surveytest.agent.core.DataGen
import com.surveytest.agent.core.Dataset
import com.surveytest.agent.core.parseRange
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var txtService: TextView
    private lateinit var txtKobo: TextView
    private lateinit var txtData: TextView
    private lateinit var edForm: EditText
    private lateinit var edRange: EditText
    private lateinit var rgSpeed: RadioGroup
    private lateinit var cbMdy: CheckBox
    private lateinit var cbAuto: CheckBox
    private lateinit var cbKeepGoing: CheckBox

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { importFile(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        txtService = findViewById(R.id.txtService); txtKobo = findViewById(R.id.txtKobo); txtData = findViewById(R.id.txtData)
        edForm = findViewById(R.id.edForm); edRange = findViewById(R.id.edRange); rgSpeed = findViewById(R.id.rgSpeed); cbMdy = findViewById(R.id.cbMdy)

        edRange.setText(AppStore.get(this, "range", "1"))
        rgSpeed.check(when (AppStore.get(this, "speed", "fast")) { "normal" -> R.id.spNormal; "slow" -> R.id.spSlow; "super" -> R.id.spSuper; else -> R.id.spFast })
        findViewById<CheckBox>(R.id.cbStrict).isChecked = AppStore.get(this, "strict", "1") == "1"
        cbMdy.isChecked = AppStore.get(this, "dateOrder", "dmy") == "mdy"
        cbAuto = findViewById(R.id.cbAuto); cbAuto.isChecked = AppStore.get(this, "auto", "1") == "1"
        cbKeepGoing = findViewById(R.id.cbKeepGoing); cbKeepGoing.isChecked = AppStore.get(this, "keepGoing", "1") == "1"
        findViewById<CheckBox>(R.id.cbAsk).isChecked = AppStore.get(this, "ask", "1") == "1"
        findViewById<Button>(R.id.btnRecord).setOnClickListener { record() }

        findViewById<Button>(R.id.btnA11y).setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        findViewById<Button>(R.id.btnAppInfo).setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
        }
        findViewById<Button>(R.id.btnGenerate).setOnClickListener { generate() }
        findViewById<Button>(R.id.btnImport).setOnClickListener { pickFile.launch(arrayOf("*/*")) }
        findViewById<Button>(R.id.btnPreview).setOnClickListener { preview() }
        findViewById<Button>(R.id.btnViewData).setOnClickListener { AppStore.dataset(this)?.let { showDataTable(it, null) } ?: toast("No test data yet") }
        findViewById<Button>(R.id.btnStart).setOnClickListener { startRun() }
        findViewById<Button>(R.id.btnLog).setOnClickListener { showText("Log (latest at the bottom)", AppStore.logTail(this), scrollToEnd = true) }
        findViewById<Button>(R.id.btnShare).setOnClickListener { shareReport() }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            AlertDialog.Builder(this).setMessage("Clear the log and snapshots?").setPositiveButton("Clear") { _, _ -> AppStore.clearLog(this); toast("Log cleared") }
                .setNegativeButton("Cancel", null).show()
        }
        findViewById<Button>(R.id.btnRules).setOnClickListener { startActivity(Intent(this, RulesActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        if (!edForm.hasFocus()) edForm.setText(AppStore.rules(this).formName)
        refresh()
    }

    private fun refresh() {
        val on = AgentService.instance != null
        txtService.text = if (on) "✅ Agent is ON (Accessibility)" else "❌ Agent is OFF — tap the button below, find Kobo Test Agent, switch it on"
        val rules = AppStore.rules(this)
        val kobo = packageManager.getLaunchIntentForPackage(rules.packageName) != null
        txtKobo.text = if (kobo) "✅ KoboCollect found (${rules.packageName})" else "❌ ${rules.packageName} is not installed"
        val d = AppStore.dataset(this)
        txtData.text = if (d == null) "No test data yet. Generate or import." else "✅ ${d.records.size} records, ${d.appliances.size} appliance rows (${d.source})"
    }

    private fun generate() {
        val n = findViewById<EditText>(R.id.edCount).text.toString().toIntOrNull()?.coerceIn(1, 1000) ?: return toast("Type how many records")
        val seed = findViewById<EditText>(R.id.edSeed).text.toString().toLongOrNull() ?: 1L
        val preset = findViewById<CheckBox>(R.id.cbPreset).isChecked
        val d = DataGen(seed, preset).generate(n)
        AppStore.saveDataset(this, d); setRangeToAll(d); refresh(); toast("Generated ${d.records.size} test records")
    }

    private fun importFile(uri: Uri) {
        try {
            var name = "file"
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: name }
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return toast("Could not read the file")
            val (d, msg) = Dataset.import(name, bytes, AppStore.dataset(this))
            AppStore.saveDataset(this, d); setRangeToAll(d); refresh()
            // your own file: fill any gaps with realistic answers, and don't pause on every blank
            cbAuto.isChecked = true; AppStore.put(this, "auto", "1")
            findViewById<CheckBox>(R.id.cbAsk).isChecked = false; AppStore.put(this, "ask", "0")
            showDataTable(d, msg)
        } catch (e: Exception) {
            AlertDialog.Builder(this).setTitle("Import failed").setMessage(e.message ?: e.toString()).setPositiveButton("OK", null).show()
        }
    }

    /** Show the loaded file as a scrollable table: every record, every column (appliances below). */
    private fun showDataTable(d: Dataset, message: String?) {
        val pad = (6 * resources.displayMetrics.density).toInt()
        fun cell(t: String, head: Boolean) = TextView(this).apply {
            text = t; textSize = 12f; setPadding(pad, pad / 2, pad, pad / 2); maxWidth = (220 * resources.displayMetrics.density).toInt()
            if (head) { setTypeface(typeface, android.graphics.Typeface.BOLD); setBackgroundColor(0x221E6B4E) }
        }
        fun table(rows: List<Map<String, String>>): TableLayout {
            val cols = LinkedHashSet<String>(); rows.forEach { cols.addAll(it.keys) }
            return TableLayout(this).apply {
                addView(TableRow(this@MainActivity).apply { cols.forEach { addView(cell(it, true)) } })
                rows.forEachIndexed { i, r ->
                    addView(TableRow(this@MainActivity).apply {
                        if (i % 2 == 1) setBackgroundColor(0x0F000000)
                        cols.forEach { addView(cell(r[it] ?: "", false)) }
                    })
                }
            }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad * 2, pad, pad * 2, pad)
            addView(TextView(this@MainActivity).apply {
                text = (message?.let { "$it\n" } ?: "") + "${d.records.size} records · ${d.records.firstOrNull()?.size ?: 0} columns · ${d.appliances.size} appliance rows · ${d.source}\nScroll sideways to see all columns."
                textSize = 13f; setPadding(0, 0, 0, pad)
            })
            addView(TextView(this@MainActivity).apply { text = "Responses"; setTypeface(typeface, android.graphics.Typeface.BOLD) })
            addView(HorizontalScrollView(this@MainActivity).apply { addView(table(d.records)) })
            if (d.appliances.isNotEmpty()) {
                addView(TextView(this@MainActivity).apply { text = "\nAppliances (C1)"; setTypeface(typeface, android.graphics.Typeface.BOLD) })
                addView(HorizontalScrollView(this@MainActivity).apply { addView(table(d.appliances)) })
            }
        }
        AlertDialog.Builder(this).setTitle(if (message != null) "File loaded" else "Test data")
            .setView(ScrollView(this).apply { addView(box) }).setPositiveButton("Close", null).show()
    }

    private fun setRangeToAll(d: Dataset) {
        val ids = d.ids(); if (ids.isEmpty()) return
        val r = if (ids.size == 1) "${ids[0]}" else "${ids.first()}-${ids.last()}"
        edRange.setText(r); AppStore.put(this, "range", r)
    }

    private fun preview() {
        val d = AppStore.dataset(this) ?: return toast("No test data yet")
        val id = try { parseRange(edRange.text.toString(), d.ids()).first() } catch (e: Exception) { d.ids().first() }
        val rec = d.record(id) ?: return
        val body = rec.filter { it.value.isNotEmpty() }.entries.joinToString("\n") { "${it.key}: ${it.value}" } +
            "\n\nAppliances:\n" + d.appliancesFor(id).joinToString("\n") { "• ${it["Appliance"]}: owned ${it["Number_owned"]}, working ${it["Number_working_W"]}, partly ${it["Number_partly_working_PW"]}" }
        showText("Record $id", body)
    }

    private fun startRun() {
        val svc = AgentService.instance ?: return AlertDialog.Builder(this).setTitle("Agent is off")
            .setMessage("Turn on Kobo Test Agent in Accessibility settings first (step 1).").setPositiveButton("OK", null).show().let { }
        val d = AppStore.dataset(this) ?: return toast("Generate or import test data first")
        val ids = try { parseRange(edRange.text.toString(), d.ids()) } catch (e: Exception) { return toast(e.message ?: "Bad record list") }
        val form = edForm.text.toString().trim()
        if (form.isEmpty()) return toast("Type the form name")
        AppStore.put(this, "formName", form); AppStore.put(this, "range", edRange.text.toString())
        val speed = when (rgSpeed.checkedRadioButtonId) { R.id.spFast -> "fast"; R.id.spSlow -> "slow"; R.id.spSuper -> "super"; else -> "normal" }
        AppStore.put(this, "speed", speed)
        val dateOrder = if (cbMdy.isChecked) "mdy" else "dmy"; AppStore.put(this, "dateOrder", dateOrder)
        val delay = mapOf("super" to 0L, "fast" to 0L, "normal" to 150L, "slow" to 500L)[speed]!!
        val strict = findViewById<CheckBox>(R.id.cbStrict).isChecked; AppStore.put(this, "strict", if (strict) "1" else "0")
        val ask = findViewById<CheckBox>(R.id.cbAsk).isChecked; AppStore.put(this, "ask", if (ask) "1" else "0")
        val keepGoing = cbKeepGoing.isChecked; AppStore.put(this, "keepGoing", if (keepGoing) "1" else "0")
        val autoAnswer = cbAuto.isChecked; AppStore.put(this, "auto", if (autoAnswer) "1" else "0")
        AlertDialog.Builder(this).setTitle("Start test run?")
            .setMessage("Fill ${ids.size} form(s) in '$form', one after another, with TEST answers. Each is saved as a DRAFT, then a new form is started.\n\nKeep the phone unlocked and don't touch the screen while it works. Use the bubble to pause or stop.")
            .setPositiveButton("Start") { _, _ -> svc.start(ids, delay, dateOrder, autoAnswer, keepGoing, speed == "super", strict, ask)?.let { toast(it) } }
            .setNegativeButton("Cancel", null).show()
    }

    private fun record() {
        val svc = AgentService.instance ?: return toast("Turn the agent on first (step 1)")
        AlertDialog.Builder(this).setTitle("Record screens")
            .setMessage("KoboCollect will open. Fill ONE form by hand from start to the end screen (use test answers). The app saves each new screen: a screenshot, its layout and how the agent reads it.\n\nWhen done, tap 'Stop recording' on the bubble, come back here and tap 'Share log + snapshots'. Tip: tap 'Clear log' first so only this recording is shared.")
            .setPositiveButton("Start recording") { _, _ ->
                svc.startRecording()?.let { return@setPositiveButton toast(it) }
                packageManager.getLaunchIntentForPackage(AppStore.rules(this).packageName)?.let { startActivity(it) }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun shareReport() {
        val dir = File(cacheDir, "share").apply { mkdirs() }
        val zip = File(dir, "kobo_agent_report.zip")
        ZipOutputStream(zip.outputStream()).use { z ->
            val files = listOfNotNull(AppStore.logFile(this).takeIf { it.exists() }) + (AppStore.snapshotDir(this).listFiles()?.toList() ?: emptyList())
            if (files.isEmpty()) return toast("Nothing to share yet")
            for (f in files) { z.putNextEntry(ZipEntry(f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry() }
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.files", zip)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Share log + snapshots"))
    }

    private fun showText(title: String, text: String, scrollToEnd: Boolean = false) {
        val tv = TextView(this).apply { setText(text); setTextIsSelectable(true); textSize = 12f; setPadding(40, 20, 40, 20); typeface = android.graphics.Typeface.MONOSPACE }
        val sv = ScrollView(this).apply { addView(tv) }
        if (scrollToEnd) sv.post { sv.fullScroll(ScrollView.FOCUS_DOWN) }
        AlertDialog.Builder(this).setTitle(title).setView(sv).setPositiveButton("Close", null).show()
    }

    private fun toast(s: String) { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
}
