package com.surveytest.agent

import android.content.Context
import com.surveytest.agent.core.Dataset
import com.surveytest.agent.core.Json
import com.surveytest.agent.core.Rules
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Where the app keeps its rules, test data, settings and log. */
object AppStore {
    private fun prefs(c: Context) = c.getSharedPreferences("agent", Context.MODE_PRIVATE)

    fun defaultRulesText(c: Context): String = c.assets.open("rules.json").bufferedReader().use { it.readText() }
    fun rulesText(c: Context): String = File(c.filesDir, "rules.json").takeIf { it.exists() }?.readText() ?: defaultRulesText(c)
    fun saveRulesText(c: Context, text: String) { Rules.parse(text); File(c.filesDir, "rules.json").writeText(text) }
    fun resetRules(c: Context) { File(c.filesDir, "rules.json").delete() }

    /** Store a rule learned from an answer given by hand (top of the list, so it wins). */
    @Synchronized fun saveLearned(c: Context, pattern: String, value: String) {
        try {
            @Suppress("UNCHECKED_CAST")
            val root = LinkedHashMap(Json.parse(rulesText(c)) as Map<String, Any?>)
            val rules = ArrayList((root["rules"] as? List<*>) ?: emptyList<Any?>())
            rules.removeAll { (it as? Map<*, *>)?.get("question") == pattern }
            rules.add(0, linkedMapOf("section" to null, "question" to pattern, "column" to "=$value", "learned" to true))
            root["rules"] = rules
            saveRulesText(c, Json.write(root))
        } catch (_: Exception) {}
    }

    /** Rules with the form name / app chosen on the main screen applied on top. */
    fun rules(c: Context): Rules {
        val r = try { Rules.parse(rulesText(c)) } catch (e: Exception) { Rules.parse(defaultRulesText(c)) }
        prefs(c).getString("formName", null)?.takeIf { it.isNotBlank() }?.let { r.formName = it }
        return r
    }

    fun dataset(c: Context): Dataset? = File(c.filesDir, "dataset.json").takeIf { it.exists() }?.let {
        try { Dataset.fromJson(it.readText()) } catch (e: Exception) { null }
    }
    fun saveDataset(c: Context, d: Dataset) = File(c.filesDir, "dataset.json").writeText(d.toJson())

    fun get(c: Context, k: String, def: String) = prefs(c).getString(k, def) ?: def
    fun put(c: Context, k: String, v: String) = prefs(c).edit().putString(k, v).apply()

    // ---------------- log
    fun logFile(c: Context) = File(c.getExternalFilesDir(null) ?: c.filesDir, "agent_log.csv")
    fun snapshotDir(c: Context) = File(c.getExternalFilesDir(null) ?: c.filesDir, "snapshots").apply { mkdirs() }
    private val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    @Synchronized fun log(c: Context, record: Int, kind: String, key: String, value: String, note: String) {
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val f = logFile(c)
        if (!f.exists()) f.writeText("time,record,kind,question,value,note\n")
        f.appendText(listOf(ts.format(Date()), record.toString(), kind, key, value, note).joinToString(",") { q(it) } + "\n")
    }
    fun logTail(c: Context, lines: Int = 300): String = logFile(c).takeIf { it.exists() }?.readLines()?.takeLast(lines)?.joinToString("\n") ?: "(log is empty)"
    fun clearLog(c: Context) { logFile(c).delete(); snapshotDir(c).listFiles()?.forEach { it.delete() } }
}
