package com.surveytest.agent.core

/** Text clean-up used for matching option labels (same as the Python version). */
fun norm(s: String?): String {
    var x = (s ?: "").lowercase().replace("–", "-").replace("—", "-").replace("/", " or ")
    x = Regex("[^a-z0-9()+\\- ]").replace(x, " ")
    return Regex("\\s+").replace(x, " ").trim()
}

/** Numbers like "8.0" become "8". */
fun fmt(v: Any?): String = when (v) {
    null -> ""
    is Double -> if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()
    is Float -> fmt(v.toDouble())
    else -> { val s = v.toString(); if (Regex("-?\\d+\\.0+").matches(s)) s.substringBefore('.') else s }
}

class Rule(val section: Regex?, val question: Regex, val column: String, val sectionText: String?, val questionText: String)

typealias Rec = Map<String, String>

/**
 * Everything form-specific: which app and form to open, and how each question maps to a data column.
 * Column values:  "Name" = that column;  "" = leave blank;  "@appliance:Field" = per-appliance repeat value;
 * "@source_role" / "@source_amount" = energy-source screens;  "@main_appliance:suffix" = C1b main appliance screens;
 * "=Some text" = always answer this exact text;  "@auto" = let the agent choose (no test data column);
 * "~Column" = use that column when the test data has a value, otherwise let the agent choose.
 */
class Rules(
    var formName: String, var packageName: String, val crumbStarts: List<String>,
    val prefixes: Map<String, String>, val rules: MutableList<Rule>,
    val srcSection: Regex, val srcPrimaryColumn: String, val primaryLabel: String, val backupLabel: String,
    val srcColumns: Map<String, String>,
    val appSection: Regex, val appNameField: String,
    val mainApp: Regex, val mainAppTemplate: String,
) {
    fun resolve(sub: String, lab: String): String? {
        val s = sub.lowercase(); val l = Regex("\\s+").replace(lab.lowercase(), " ").trim()
        for (r in rules) if ((r.section == null || r.section.containsMatchIn(s)) && r.question.containsMatchIn(l)) return r.column
        return null
    }

    /** The answer for this field as text ('' = leave blank). */
    fun valueFor(col: String, sub: String, rec: Rec, apps: List<Rec>): String {
        val s = sub.lowercase()
        if (col.isEmpty() || col == "@auto") return ""
        if (col.startsWith("=")) return col.substring(1)
        if (col.startsWith("@appliance:")) {
            val field = col.removePrefix("@appliance:")
            val name = norm(appSection.replaceFirst(s, ""))
            return fmt(apps.firstOrNull { norm(it[appNameField]) == name }?.get(field) ?: "")
        }
        if (col == "@source_role" || col == "@source_amount") {
            val src = norm(srcSection.replaceFirst(s, ""))
            if (col == "@source_role") return if (norm(rec[srcPrimaryColumn]) == src) primaryLabel else backupLabel
            return fmt(rec[srcColumns[src] ?: return ""] ?: "")
        }
        if (col.startsWith("@main_appliance:")) {
            val n = mainApp.find(s)?.groupValues?.get(1) ?: return ""
            return fmt(rec[mainAppTemplate.replace("{n}", n).replace("{suffix}", col.removePrefix("@main_appliance:"))] ?: "")
        }
        val v = fmt(rec[col] ?: "")
        return (prefixes[col] ?: "") + v
    }

    /** Every data column a rule points at (used to warn about typos). */
    /** A rule learned from an answer you gave by hand: this question always gets this answer. Returns its pattern. */
    fun learn(label: String, value: String): String {
        val q = "^" + Regex.escape(Regex("\\s+").replace(label.lowercase(), " ").trim().take(80))
        rules.removeAll { it.questionText == q }
        rules.add(0, Rule(null, Regex(q), "=$value", null, q))
        return q
    }

    fun plainColumns(): List<String> = rules.map { it.column }.filter { it.isNotEmpty() && !it.startsWith("@") && !it.startsWith("=") && !it.startsWith("~") }.distinct()

    companion object {
        fun parse(text: String): Rules {
            val root = Json.parse(text) as? Map<*, *> ?: throw Json.JsonError("The file must start with {")
            fun str(m: Map<*, *>, k: String, def: String? = null): String =
                (m[k] as? String) ?: def ?: throw Json.JsonError("Missing \"$k\"")
            fun map(m: Map<*, *>, k: String): Map<*, *> = m[k] as? Map<*, *> ?: throw Json.JsonError("Missing section \"$k\"")
            fun rx(p: String, where: String): Regex = try { Regex(p) } catch (e: Exception) { throw Json.JsonError("Bad pattern in $where: ${e.message}") }
            val rl = (root["rules"] as? List<*>) ?: throw Json.JsonError("Missing \"rules\" list")
            val rules = rl.mapIndexedTo(ArrayList()) { i, x ->
                val m = x as? Map<*, *> ?: throw Json.JsonError("Rule ${i + 1} must be { ... }")
                val sec = m["section"] as? String
                val q = m["question"] as? String ?: throw Json.JsonError("Rule ${i + 1} has no \"question\"")
                val col = m["column"] as? String ?: throw Json.JsonError("Rule ${i + 1} has no \"column\"")
                Rule(sec?.let { rx(it, "rule ${i + 1} section") }, rx(q, "rule ${i + 1} question"), col, sec, q)
            }
            val es = map(root, "energySources"); val ap = map(root, "appliances"); val ma = map(root, "mainAppliances")
            return Rules(
                formName = str(root, "formName"), packageName = str(root, "packageName"),
                crumbStarts = (root["breadcrumbStartsWith"] as? List<*>)?.map { it.toString() } ?: emptyList(),
                prefixes = (root["prefixes"] as? Map<*, *>)?.entries?.associate { it.key.toString() to it.value.toString() } ?: emptyMap(),
                rules = rules,
                srcSection = rx(str(es, "sectionPrefix"), "energySources.sectionPrefix"),
                srcPrimaryColumn = str(es, "primaryColumn"), primaryLabel = str(es, "primaryLabel", "Primary"),
                backupLabel = str(es, "backupLabel", "Backup"),
                srcColumns = map(es, "columns").entries.associate { norm(it.key.toString()) to it.value.toString() },
                appSection = rx(str(ap, "sectionPrefix"), "appliances.sectionPrefix"), appNameField = str(ap, "nameField"),
                mainApp = rx(str(ma, "sectionPattern"), "mainAppliances.sectionPattern"), mainAppTemplate = str(ma, "columnTemplate"),
            )
        }
    }
}
