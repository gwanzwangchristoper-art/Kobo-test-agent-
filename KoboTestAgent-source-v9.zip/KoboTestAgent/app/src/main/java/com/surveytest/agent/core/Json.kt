package com.surveytest.agent.core

/** Small JSON reader/writer (no external libraries), with line numbers in errors for the rules editor. */
object Json {
    class JsonError(msg: String) : IllegalArgumentException(msg)

    fun parse(s: String): Any? {
        val p = P(s); val v = p.value(); p.ws()
        if (p.i < s.length) p.err("unexpected text after the end")
        return v
    }

    private class P(val s: String) {
        var i = 0
        fun err(m: String): Nothing {
            val line = s.substring(0, minOf(i, s.length)).count { it == '\n' } + 1
            throw JsonError("Line $line: $m")
        }
        fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun value(): Any? {
            ws(); if (i >= s.length) err("unexpected end of text")
            return when (s[i]) {
                '{' -> obj(); '[' -> arr(); '"' -> str()
                't' -> lit("true", true); 'f' -> lit("false", false); 'n' -> lit("null", null)
                else -> num()
            }
        }
        fun lit(w: String, v: Any?): Any? { if (!s.startsWith(w, i)) err("unexpected word"); i += w.length; return v }
        fun num(): Any {
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] in "+-.eE")) i++
            val t = s.substring(st, i)
            if (t.isEmpty()) err("unexpected character '${s[i]}'")
            return try { if (t.any { it in ".eE" }) t.toDouble() else t.toLong() } catch (e: NumberFormatException) { err("bad number '$t'") }
        }
        fun str(): String {
            i++; val sb = StringBuilder()
            while (true) {
                if (i >= s.length) err("text in quotes is not closed")
                when (val c = s[i++]) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (i >= s.length) err("bad escape")
                        when (val e = s[i++]) {
                            'n' -> sb.append('\n'); 't' -> sb.append('\t'); 'r' -> sb.append('\r')
                            'b' -> sb.append('\b'); 'f' -> sb.append('\u000c')
                            'u' -> { if (i + 4 > s.length) err("bad \\u escape"); sb.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4 }
                            else -> sb.append(e)
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }
        fun arr(): List<Any?> {
            i++; val l = ArrayList<Any?>(); ws()
            if (s.getOrNull(i) == ']') { i++; return l }
            while (true) {
                l.add(value()); ws()
                when (s.getOrNull(i)) { ',' -> i++; ']' -> { i++; return l }; else -> err("expected , or ]") }
            }
        }
        fun obj(): Map<String, Any?> {
            i++; val m = LinkedHashMap<String, Any?>(); ws()
            if (s.getOrNull(i) == '}') { i++; return m }
            while (true) {
                ws(); if (s.getOrNull(i) != '"') err("expected a \"name\" in quotes")
                val k = str(); ws()
                if (s.getOrNull(i) != ':') err("expected : after \"$k\"")
                i++; m[k] = value(); ws()
                when (s.getOrNull(i)) { ',' -> i++; '}' -> { i++; return m }; else -> err("expected , or } after \"$k\"") }
            }
        }
    }

    fun write(v: Any?, pretty: Boolean = true): String { val sb = StringBuilder(); w(v, sb, 0, pretty); return sb.toString() }

    private fun w(v: Any?, sb: StringBuilder, ind: Int, pretty: Boolean) {
        val nl = if (pretty) "\n" + " ".repeat(ind + 1) else ""
        val end = if (pretty) "\n" + " ".repeat(ind) else ""
        when (v) {
            null -> sb.append("null")
            is String -> quote(v, sb)
            is Boolean, is Int, is Long -> sb.append(v.toString())
            is Double -> sb.append(if (v % 1.0 == 0.0) v.toLong().toString() else v.toString())
            is Map<*, *> -> {
                if (v.isEmpty()) { sb.append("{}"); return }
                sb.append('{'); var first = true
                for ((k, x) in v) { if (!first) sb.append(','); first = false; sb.append(nl); quote(k.toString(), sb); sb.append(if (pretty) ": " else ":"); w(x, sb, ind + 1, pretty) }
                sb.append(end).append('}')
            }
            is List<*> -> {
                if (v.isEmpty()) { sb.append("[]"); return }
                val flat = v.all { it !is Map<*, *> && it !is List<*> }
                sb.append('['); var first = true
                for (x in v) { if (!first) sb.append(if (flat && pretty) ", " else ","); first = false; if (!flat) sb.append(nl); w(x, sb, ind + 1, pretty) }
                if (!flat) sb.append(end); sb.append(']')
            }
            else -> quote(v.toString(), sb)
        }
    }

    private fun quote(s: String, sb: StringBuilder) {
        sb.append('"')
        for (c in s) when (c) {
            '"' -> sb.append("\\\""); '\\' -> sb.append("\\\\"); '\n' -> sb.append("\\n"); '\r' -> sb.append("\\r"); '\t' -> sb.append("\\t")
            else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c)
        }
        sb.append('"')
    }
}
