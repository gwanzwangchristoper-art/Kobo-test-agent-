package com.surveytest.agent.core

/** A plain copy of one on-screen element. `ref` holds the platform object used to act on it. */
class UiNode(
    val cls: String, val text: String, val desc: String, val id: String,
    val left: Int, val top: Int, val right: Int, val bottom: Int,
    val checked: Boolean, val scrollable: Boolean, val children: List<UiNode>, val ref: Any? = null,
    val numeric: Boolean = false,
) {
    val cx get() = (left + right) / 2
    val cy get() = (top + bottom) / 2
    fun walk(): Sequence<UiNode> = sequence { yield(this@UiNode); for (c in children) yieldAll(c.walk()) }
    fun firstText(): String { for (n in walk()) if (n.text.isNotBlank()) return n.text.trim(); return desc.trim() }
    /** Compact text used to tell whether the screen changed. */
    fun signature(): String = buildString { for (n in walk()) append(n.cls.substringAfterLast('.')).append('|').append(n.text).append('|').append(n.checked).append('|').append(n.top).append(';') }
    fun dump(ind: String = ""): String = buildString {
        append(ind).append(cls.substringAfterLast('.')).append(" text=\"").append(text).append("\" desc=\"").append(desc)
            .append("\" id=").append(id).append(" checked=").append(checked).append(" [").append(left).append(',').append(top)
            .append("][").append(right).append(',').append(bottom).append("]\n")
        for (c in children) append(c.dump("$ind  "))
    }
}

class Item(val t: String, val text: String, val node: UiNode?, val checked: Boolean = false, val numeric: Boolean = false)
class Field(val t: String, val lab: String, val items: MutableList<Item> = ArrayList())

private val SAVE_DRAFT = Regex("^(save as draft|save form and exit|save form|save draft)$", RegexOption.IGNORE_CASE)
private val SAVE_FINAL = Regex("^(finalize|finalise|save and finalize|send|submit)$", RegexOption.IGNORE_CASE)
private val MARK_FINAL = Regex("mark form as finali[sz]ed|finali[sz]e", RegexOption.IGNORE_CASE)
private val ID_NEXT = setOf("form_forward_button", "nextButton", "next_button")
private val ID_DRAFT = setOf("save_as_draft", "save_exit_button", "save_as_draft_button")
private val NEXT_TXT = Regex("(?i)next")
private val BACK_TXT = Regex("(?i)next|back")
/** Prompt text of KoboCollect "minimal" (dropdown) select questions. */
val DROPDOWN_TXT = Regex("(?i)^(select|choose) (one |an |your )?(answer|option|response)s?$|^select one$|^select multiple$")

class Screen {
    val items = ArrayList<Item>(); val buttons = ArrayList<Item>(); val dialog = ArrayList<Item>()
    var dialogMsg = ""; var scrollable = false; var crumb = ""; var sub = ""; var sid = ""
    var fields = ArrayList<Field>(); var layoutSig = 0; var next: Item? = null; var saveDraft: Item? = null
    var saveFinal: Item? = null; var markFinal: Item? = null; var isEnd = false; var pkg = ""
    val texts = ArrayList<String>()
}

fun parseScreen(root: UiNode, rules: Rules): Screen {
    val s = Screen(); val h = (root.bottom - root.top).coerceAtLeast(1)
    val top = root.top + h * 0.13; val bottom = root.top + h * 0.90
    var nextId: Item? = null; var draftId: Item? = null
    fun walk(n: UiNode) {
        val cls = n.cls; var txt = n.text.trim(); val rid = n.id.substringAfterLast('/')
        if (n.scrollable) s.scrollable = true
        if (rid.startsWith("button") && n.id.startsWith("android:id/") && txt.isNotEmpty()) { s.dialog.add(Item("btn", txt, n)); return }
        if (rid == "message" && txt.isNotEmpty()) s.dialogMsg = txt
        if (rid in ID_NEXT) { nextId = Item("btn", txt.ifEmpty { "Next" }, n); return }
        if (rid in ID_DRAFT) { draftId = Item("btn", txt.ifEmpty { "Save as draft" }, n); return }
        if (txt.isEmpty() && (cls.endsWith("Button") || cls.endsWith("ImageButton")) && n.desc.isNotBlank()) txt = n.desc.trim()
        if (cls.endsWith("RadioButton") || cls.endsWith("CheckBox")) {
            s.items.add(Item(if (cls.endsWith("RadioButton")) "radio" else "check", txt.ifEmpty { n.firstText() }, n, n.checked)); return
        }
        if (cls.endsWith("EditText")) {
            // KoboCollect dropdowns look like a text box (id "answer", text "Select Answer" until chosen)
            if (n.id.endsWith(":id/answer") || DROPDOWN_TXT.containsMatchIn(txt)) { s.items.add(Item("spinner", txt, n)); return }
            s.items.add(Item("edit", txt, n, numeric = n.numeric)); return
        }
        if (cls.endsWith("Spinner")) { s.items.add(Item("spinner", n.firstText(), n)); return }
        if (txt.isNotEmpty() && n.cy > top && n.top <= bottom && DROPDOWN_TXT.containsMatchIn(txt)) { s.items.add(Item("spinner", txt, n)); return }
        if (txt.isNotEmpty() && cls.endsWith("Button") && Regex("(?i)^select date").containsMatchIn(txt)) { s.items.add(Item("date", txt, n)); return }
        if (txt.isNotEmpty()) {
            if (BACK_TXT.matches(txt) || cls.endsWith("Button") || n.top > bottom) s.buttons.add(Item("btn", txt, n))
            else if (cls.endsWith("TextView") && n.cy > top) {
                if (">" in txt || rules.crumbStarts.any { txt.startsWith(it) }) s.crumb = txt
                else { s.items.add(Item("label", txt, n)); s.texts.add(txt) }
            }
        }
        for (c in n.children) walk(c)
    }
    walk(root)
    val parts = s.crumb.split(">").map { it.trim() }
    s.sub = if (parts.size > 2) parts.drop(2).joinToString(" > ") else ""
    var pending = ArrayList<String>(); var cur: Field? = null
    for (it in s.items) {
        if (it.t == "label") { cur?.let { s.fields.add(it) }; cur = null; pending.add(it.text); continue }
        if (it.t == "edit" || it.t == "date" || it.t == "spinner" || cur == null || cur!!.t != it.t) {
            cur?.let { s.fields.add(it) }
            cur = Field(it.t, pending.joinToString(" ")); pending = ArrayList()
        }
        cur!!.items.add(it)
    }
    cur?.let { s.fields.add(it) }
    s.sid = s.sub + "|" + (s.texts.firstOrNull() ?: "")
    s.layoutSig = s.items.map { Triple(it.text, it.node?.cy, it.checked) }.hashCode()
    s.next = nextId ?: s.buttons.firstOrNull { NEXT_TXT.matches(it.text) }
    // Save buttons count only in the page body: the toolbar's Save icon (top of screen) saves mid-form and is ignored.
    val body = s.buttons.filter { (it.node?.top ?: 0) >= top }
    s.saveDraft = draftId ?: body.firstOrNull { SAVE_DRAFT.matches(it.text) }
    s.saveFinal = body.firstOrNull { SAVE_FINAL.matches(it.text) }
    s.markFinal = s.items.firstOrNull { it.t == "check" && MARK_FINAL.containsMatchIn(it.text) }
    val strong = Regex("(?i)^(save as draft|finali[sz]e|save form and exit)$")
    s.isEnd = draftId != null || body.any { strong.matches(it.text) } || ((s.saveDraft != null || s.saveFinal != null) && s.next == null)
    if (s.isEnd) s.fields = ArrayList()   // never answer anything on the save screen
    return s
}

/** Similarity 0..1 (like Python difflib ratio, close enough for option labels). */
fun similarity(a: String, b: String): Double {
    if (a.isEmpty() && b.isEmpty()) return 1.0
    val d = Array(a.length + 1) { IntArray(b.length + 1) }
    for (i in 0..a.length) d[i][0] = i
    for (j in 0..b.length) d[0][j] = j
    for (i in 1..a.length) for (j in 1..b.length)
        d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
    return 1.0 - d[a.length][b.length].toDouble() / maxOf(a.length, b.length)
}

fun matchOption(items: List<Item>, wanted: String): Item? {
    val w = norm(wanted); val names = items.map { norm(it.text) }
    items.indices.firstOrNull { names[it] == w }?.let { return items[it] }
    // "Mini-grid" matches "Mini-grid (MG)", but "Kilankwa I" must NOT match "Kilankwa II"
    fun prefix(long: String, short: String) = short.isNotEmpty() && long.startsWith(short) && (long.length == short.length || long[short.length] == ' ')
    items.indices.firstOrNull { prefix(names[it], w) || prefix(w, names[it]) }?.let { return items[it] }
    val ok = items.indices.filter { !names[it].startsWith(w) && !w.startsWith(names[it]) }
    val best = ok.maxByOrNull { similarity(w, names[it]) } ?: return null
    return if (similarity(w, names[best]) >= 0.8) items[best] else null
}
/** Plain-language summary of how the agent reads a screen (saved with recorded screens, for fixing rules). */
fun explain(root: UiNode, rules: Rules): String = buildString {
    val s = parseScreen(root, rules)
    append("=== How the agent reads this screen ===\n")
    append("section: ").append(s.sub.ifEmpty { "(none)" }).append('\n')
    append("save screen: ").append(s.isEnd).append("   next button: ").append(s.next != null).append('\n')
    if (s.dialog.isNotEmpty()) append("pop-up: ").append(s.dialogMsg).append(" buttons=").append(s.dialog.joinToString { it.text }).append('\n')
    for (f in s.fields) {
        val key = rules.resolve(s.sub, f.lab)
        append("- [").append(f.t).append("] \"").append(f.lab.take(100)).append("\" -> ").append(key ?: "NO RULE (auto answer)").append('\n')
        for (it in f.items) append("     • ").append(it.text.take(80)).append(if (it.checked) "  (selected)" else "").append(if (it.numeric) "  (number)" else "").append('\n')
    }
    append("\n=== Raw screen ===\n").append(root.dump())
}
