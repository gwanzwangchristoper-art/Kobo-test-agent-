import com.surveytest.agent.core.*
import java.io.File

/** Rebuild a UiNode tree from a recorded screen file (the "Raw screen" part). */
fun loadScreen(f: File): UiNode {
    val lines = f.readLines().dropWhile { !it.startsWith("=== Raw screen") }.drop(1).filter { it.isNotBlank() }
    val rx = Regex("""^( *)(\S+) text="(.*)" desc="(.*)" id=(\S*) checked=(true|false) \[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]$""")
    class B(val ind: Int, val cls: String, val text: String, val desc: String, val id: String, val ch: Boolean, val b: List<Int>) { val kids = ArrayList<B>() }
    val stack = ArrayList<B>(); var root: B? = null
    for (l in lines) {
        val m = rx.find(l) ?: continue
        val g = m.groupValues
        val b = B(g[1].length, "android.widget." + g[2], g[3], g[4], g[5], g[6] == "true", g.subList(7, 11).map { it.toInt() })
        while (stack.isNotEmpty() && stack.last().ind >= b.ind) stack.removeAt(stack.size - 1)
        if (stack.isEmpty()) root = b else stack.last().kids.add(b)
        stack.add(b)
    }
    fun conv(b: B): UiNode = UiNode(b.cls, b.text, b.desc, b.id, b.b[0], b.b[1], b.b[2], b.b[3], b.ch, b.cls.endsWith("ScrollView"),
        b.kids.map { conv(it) }, ref = b.text.ifEmpty { b.id }, numeric = b.cls.endsWith("EditText") && b.id.isEmpty())
    return conv(root!!)
}

fun replayTests(rules: Rules, dir: String) {
    val files = File(dir).listFiles { f -> f.name.startsWith("screen_") && f.name.endsWith(".txt") }!!.sortedBy { it.name }
    // 1. no recorded question screen may look like the save screen (toolbar 'Save as draft' icon)
    val ends = files.filter { parseScreen(loadScreen(it), rules).isEnd }.map { it.name }
    check(ends.isEmpty()) { "recorded screens mistaken for the save screen: $ends" }
    println("replay: ${files.size} real screens parsed, none mistaken for the save screen")
    // 2. the stuck dropdown
    val s4 = parseScreen(loadScreen(File(dir, "screen_004.txt")), rules)
    check(s4.fields.size == 1 && s4.fields[0].t == "spinner") { "Instrument dropdown read as ${s4.fields.map { it.t }}" }
    // 3. replay: dropdown screen -> option list -> answered screen -> Next -> save screen
    val shots = mapOf("q" to loadScreen(File(dir, "screen_004.txt")), "list" to loadScreen(File(dir, "screen_005.txt")), "done" to loadScreen(File(dir, "screen_006.txt")))
    val end = UiNode("android.widget.FrameLayout", "", "", "", 0, 0, 1080, 2400, false, false, listOf(
        UiNode("android.widget.Button", "Save as draft", "", "org.koboc.collect.android:id/save_as_draft", 50, 1500, 500, 1650, false, false, emptyList(), "draft"),
        UiNode("android.widget.Button", "Finalize", "", "org.koboc.collect.android:id/finalize", 550, 1500, 1030, 1650, false, false, emptyList(), "final")))
    val dev = object : Device {
        var state = "q"; var picked = ""; var saved = ""
        val menu = UiNode("android.widget.FrameLayout", "", "", "", 0, 0, 1080, 2400, false, false, listOf(
            UiNode("android.widget.TextView", "Start new form", "", "", 50, 800, 1030, 950, false, false, emptyList())))
        override fun root() = when (state) { "end" -> end; "menu" -> menu; else -> shots[state] }
        override fun click(n: UiNode): Boolean {
            when {
                state == "q" && n.id.endsWith(":id/answer") -> state = "list"
                state == "list" && n.cls.endsWith("RadioButton") -> { picked = n.text; state = if (n.text.startsWith("Household Energy")) "done" else "q" }
                (state == "done") && n.text == "Next" -> state = "end"
                state == "q" && n.text == "Next" -> {}
                state == "end" -> { saved = n.text; if (n.text == "Save as draft") state = "menu" }
                n.desc == "Save as draft" -> saved = "TOOLBAR"
            }
            return true
        }
        override fun setText(n: UiNode, text: String) = true
        override fun scrollForward(root: UiNode) = false
        override fun back() {}
        override fun launch(pkg: String) = true
        override fun sleep(ms: Long) {}
        override fun snapshot(name: String, root: UiNode?) {}
    }
    val rep = Rep()
    val data = Dataset(listOf(mapOf("Record" to "1")), emptyList(), "t")
    val done = Engine(dev, rules, data, rep, Control(), delayMs = 0).run(listOf(1), true)
    check(done == 1 && dev.picked == "Household Energy and Living Standards Survey" && dev.saved == "Save as draft") {
        "replay dropdown: done=$done picked=${dev.picked} saved=${dev.saved}\n" + rep.logs.joinToString("\n") }
    println("replay: 'Select Instrument Section' dropdown opened, picked '${dev.picked}', saved as draft OK")
    // 4. how many recorded questions now have a rule
    val seen = LinkedHashMap<String, String?>()
    for (f in files) { val sc = parseScreen(loadScreen(f), rules); for (fl in sc.fields) if (fl.lab.isNotBlank()) seen.putIfAbsent(fl.lab.take(70), rules.resolve(sc.sub, fl.lab)) }
    val none = seen.filter { it.value == null }
    println("replay: ${seen.size} distinct questions; ${seen.size - none.size} matched by rules, ${none.size} answered automatically:")
    none.keys.forEach { println("   auto: $it") }
}
fun carryCheck(rules: Rules, dir: String) {
    val files = File(dir).listFiles { f -> f.name.startsWith("screen_") && f.name.endsWith(".txt") }!!.sortedBy { it.name }
    var cur = ""; val left = LinkedHashSet<String>()
    for (f in files) {
        val sc = parseScreen(loadScreen(f), rules)
        if (sc.sub.isEmpty() && cur.isNotEmpty() && sc.fields.none { Regex("^[a-e]\\d").containsMatchIn(it.lab.lowercase()) }) sc.sub = cur else cur = sc.sub
        for (fl in sc.fields) if (fl.lab.isNotBlank() && rules.resolve(sc.sub, fl.lab) == null) left.add(fl.lab.take(70))
    }
    println("with section memory, still answered automatically: " + left.joinToString(" | "))
}
