package com.surveytest.agent.core

import java.util.Random

/**
 * Generates randomised, internally consistent TEST answers for the Household Energy survey
 * (port of the Python datagen stages 1-4: skip logic, household sums, costs, appliances).
 */
class DataGen(seed: Long, private val preset: Boolean = false) {
    companion object {
        /** Kwali (FCT) mini-grid communities and their NEP project names as listed in the form. */
        val SITES = linkedMapOf(
            "Kilankwa I" to "6. Kilankwa 1 NEP Project (Pilot site, Commissioned, Nayo Tropical Technology)",
            "Kilankwa II" to "7. Kilankwa II NEP Project (Pilot site, Commissioned, Nayo Tropical Technology)",
            "Petti" to "5. Petti NEP Project (Pilot site, Commissioned, Nayo Tropical Technology)",
        )
    }
    private val rnd = Random(2026L * 1_000_003L + seed)
    private fun rf() = rnd.nextDouble()
    private fun ri(a: Int, b: Int) = a + rnd.nextInt(b - a + 1)
    private fun step(a: Int, b: Int, s: Int = 500) = a + s * rnd.nextInt((b - a) / s + 1)
    private fun <T> choice(l: List<T>): T = l[rnd.nextInt(l.size)]
    private fun <T> w(vararg o: Pair<T, Int>): T = wl(o.toList())
    private fun <T> wl(o: List<Pair<T, Int>>): T {
        var x = rnd.nextInt(o.sumOf { it.second }); for ((v, n) in o) { if (x < n) return v; x -= n }; return o.last().first
    }
    private fun <T> sample(l: List<T>, k: Int): List<T> = l.shuffled(rnd).take(k)

    fun generate(n: Int): Dataset {
        val recs = ArrayList<Rec>(); val apps = ArrayList<Rec>()
        for (i in 1..n) { val (r, a) = household(i, n); recs.add(r); apps.addAll(a) }
        return Dataset(recs, apps, "generated: $n records" + if (preset) " (FCT / Kwali preset)" else "")
    }

    private fun household(i: Int, n: Int): Pair<Rec, List<Rec>> {
        val r = LinkedHashMap<String, String>()
        fun put(k: String, v: Any) { r[k] = fmt(v) }
        // ---------------- stage 1: profile + connection
        val site = if (preset || i <= Math.round(n * 0.55)) "WP5.2" else "WP5.3"
        val sex = if (preset) "Male" else w("Male" to 58, "Female" to 40, "Prefer not to say" to 2)
        val age = w("18–24" to 12, "25–35" to 30, "36–49" to 35, "50 and above" to 23)
        val size = wl((3..12).zip(listOf(6, 10, 14, 16, 16, 14, 10, 6, 4, 4)))
        var kids: Int; var yw: Int; var ym: Int; var ow: Int; var om: Int
        while (true) {
            kids = ri(1, maxOf(1, size - 2)); val rest = size - kids
            yw = 0; ym = 0; ow = 0; om = 0
            if (rest < 1) continue
            repeat(rest) { when (w("yw" to 22, "ym" to 18, "ow" to 30, "om" to 30)) { "yw" -> yw++; "ym" -> ym++; "ow" -> ow++; else -> om++ } }
            val young = age == "18–24" || age == "25–35"
            val need = when { sex == "Female" && young -> yw; sex == "Male" && young -> ym; sex == "Female" -> ow; else -> om }
            if (sex == "Prefer not to say" || need >= 1) break
        }
        var head = if (sex == "Male" && rf() < .85) "Man" else w("Man" to 55, "Woman" to 25, "Jointly" to 12, "Other or unclear" to 8)
        if (sex == "Female" && rf() < .4) head = "Woman"
        val liv = w("Crop farming" to 55, "Livestock or fishing" to 8, "Trading" to 12, "Agro-processing" to 6, "Artisan work" to 5,
            "Transport" to 3, "Services or salaried employment" to 5, "Remittances" to 3, "Other" to 3)
        val inc = w("Below NGN 600,000" to 22, "NGN 600,000 – 1,199,999" to 24, "NGN 1,200,000 – 2,399,999" to 20,
            "NGN 2,400,000 – 4,799,999" to 8, "NGN 4,800,000 and above" to 2, "Irregular or seasonal" to 16, "Do not know" to 5, "Prefer not to say" to 3)
        val emp = sortedSetOf<String>()
        if (liv == "Crop farming" || rf() < .6) emp.add("Farming")
        for ((o, p) in listOf("Trading or shop" to .3, "Artisan or trade work" to .15, "Casual or daily labour" to .25, "Salaried employment" to .07,
            "Own business or enterprise" to .15, "Schooling or training" to .3, "Not currently working" to .08, "Other" to .04)) if (rf() < p) emp.add(o)
        if (emp.isEmpty()) emp.add("Farming")
        put("Record", i)
        if (preset) {
            val community = SITES.keys.toList()[(i - 1) % SITES.size]
            put("Instrument_section", "Household Energy and Living Standards Survey"); put("State", "FCT"); put("LGA", "Kwali")
            put("Community", community); put("Enumerator_code", "FCT001"); put("Project_site", SITES[community]!!)
        }
        put("Site_type", site); put("Consent", "Yes"); put("A1_Sex", sex); put("A2_Age_group", age)
        put("A3_Household_size", size); put("A4_Children_under_18", kids); put("A4_Young_women_18_35", yw); put("A4_Young_men_18_35", ym)
        put("A4_Women_36plus", ow); put("A4_Men_36plus", om); put("A5_Household_head", head); put("A6_Main_livelihood", liv)
        put("A7_Annual_income", inc); put("A8_Household_work", emp.joinToString("; "))
        val wp = site == "WP5.2"
        val conn = if (wp) w("Yes - currently connected" to 72, "No - not connected" to 18, "Previously connected but disconnected" to 10) else ""
        val connected = conn == "Yes - currently connected"
        put("A9_Minigrid_job_effect", if (wp) w("Yes, a new job" to 12, "Yes, existing work improved" to 30, "No change" to 48, "Do not know" to 10) else "")
        put("B1_Connected_to_minigrid", conn)
        if (wp && conn != "No - not connected") {
            put("B1a_Month_year_connected", "%d-%02d".format(choice(listOf(2023, 2024, 2025)), ri(1, 12)))
            val sub = w("Subsidised" to 40, "Free" to 8, "Not subsidised" to 52)
            put("B1a_Connection_fee_NGN", if (sub == "Free") 0 else choice(listOf(5000, 10000, 15000, 20000, 25000, 30000)))
            put("B1a_Wiring_cost_NGN", choice(listOf(0, 3000, 5000, 8000, 10000, 15000, 20000))); put("B1a_Subsidised_or_free", sub)
        } else listOf("B1a_Month_year_connected", "B1a_Connection_fee_NGN", "B1a_Wiring_cost_NGN", "B1a_Subsidised_or_free").forEach { put(it, "") }
        val b2: String; val main: String
        if (wp) {
            put("B1b_Main_reason", when (conn) {
                "Yes - currently connected" -> w("Not applicable, connected when the mini-grid started" to 70, "Waiting for meter or connection by the operator" to 10, "Connection fee too high" to 10, "Cost of house wiring" to 10)
                "No - not connected" -> w("Connection fee too high" to 30, "Cost of house wiring" to 20, "Waiting for meter or connection by the operator" to 15, "House too far from the network" to 20, "Tariff too high" to 15)
                else -> w("Tariff too high" to 40, "Can no longer afford electricity (rising living costs)" to 45, "Waiting for meter or connection by the operator" to 15)
            })
            b2 = w("National grid" to 5, "Solar home system" to 12, "Generator" to 25, "Solar lantern" to 18, "Battery or charging service" to 20, "No electricity" to 18, "Other" to 2)
            main = if (connected) "Mini-grid" else w("Generator" to 30, "Solar home system" to 15, "Solar lantern" to 20, "Battery or charging service" to 20, "No electricity" to 15)
        } else {
            put("B1b_Main_reason", ""); b2 = ""
            main = w("National grid" to 12, "Generator" to 25, "Solar system" to 8, "Battery or charging service" to 15, "Solar home system" to 12, "Solar lantern" to 15, "No electricity" to 11, "Other" to 2)
        }
        put("B2_Source_before_minigrid", b2); put("B3_Source_now", main)
        // ---------------- stage 2: other sources, supply, payments, spending, cooking
        val key = if (main == "Solar system") "Solar home system" else main
        val pool = listOf("Generator", "Solar home system", "Solar lantern", "Battery or charging service", "National grid", "Other")
            .filter { it != key && !(it == "National grid" && rf() < .8) }
        val yes = rf() < (if (main == "No electricity") .35 else .6)
        val others = if (yes) sample(pool, minOf(pool.size, choice(listOf(1, 1, 2)))) else emptyList()
        put("Other_source_used", if (others.isNotEmpty()) "Yes" else "No"); put("B4_Other_sources", others.joinToString("; "))
        put("Generator_used_now", if (main == "Generator" || "Generator" in others) "Yes" else "No")
        put("B4a_Generator_before_minigrid", if (!wp) "" else if (b2 == "Generator") "Yes" else w("No" to 70, "Yes" to 15, "Do not know" to 15))
        val hrs: String; val outs: String
        if (main == "No electricity") { hrs = "None"; outs = "No service"; put("B7_Safety_issues", "Do not know or not applicable") }
        else {
            hrs = wl(when (main) {
                "Mini-grid" -> listOf("8–15" to 30, "16–22" to 30, "23–24" to 30, "Varies greatly" to 10)
                "National grid" -> listOf("4–7" to 30, "8–15" to 30, "Varies greatly" to 40)
                "Generator" -> listOf("Less than 4" to 50, "4–7" to 30, "Varies greatly" to 20)
                else -> listOf("Less than 4" to 35, "4–7" to 45, "Varies greatly" to 20)
            })
            outs = wl(when (main) {
                "Mini-grid" -> listOf("Never" to 45, "1–2 times" to 30, "3–5 times" to 15, "More than 5 times or daily" to 10)
                "National grid" -> listOf("1–2 times" to 15, "3–5 times" to 30, "More than 5 times or daily" to 55)
                else -> listOf("Never" to 45, "1–2 times" to 35, "3–5 times" to 15, "More than 5 times or daily" to 5)
            })
            put("B7_Safety_issues", w("No" to 65, "Sometimes" to 25, "Frequently" to 5, "Do not know or not applicable" to 5))
        }
        put("B5_Hours_per_day", hrs); put("B6_Outages_past_7_days", outs)
        var mgPay = 0
        if (wp && connected) {
            val pay = w("Pay-as-you-use or prepaid" to 75, "Fixed monthly payment" to 20, "Other" to 5)
            mgPay = step(3000, 18000)
            var tariff: Any = if (rf() < .85) choice(listOf(250, 280, 300, 320, 350, 380, 400, 450)) else ""
            var kwh: Any = if (tariff is Int && rf() < .85) Math.round(mgPay * 10.0 / tariff) / 10.0 else ""
            if (pay == "Fixed monthly payment") { tariff = ""; kwh = "" }
            put("B8_Payment_method", pay); put("B8_Minigrid_monthly_NGN", mgPay); put("B8a_Tariff_NGN_per_kWh", tariff)
            put("B8a_kWh_last_30_days", kwh); put("B8a_Tariff_change_12m", w("Increased" to 55, "No change" to 38, "Decreased" to 7))
        } else listOf("B8_Payment_method", "B8_Minigrid_monthly_NGN", "B8a_Tariff_NGN_per_kWh", "B8a_kWh_last_30_days", "B8a_Tariff_change_12m").forEach { put(it, "") }
        val amt = linkedMapOf<String, Int?>("Minigrid" to null, "NationalGrid" to null, "PetrolFuel" to null, "DieselFuel" to null,
            "GenMaintenance" to null, "Kerosene" to null, "Candles" to null, "BatteryCharging" to null)
        val used = listOf(main) + others
        if (mgPay > 0) amt["Minigrid"] = mgPay
        if ("National grid" in used) amt["NationalGrid"] = step(2000, 12000)
        if ("Generator" in used) {
            if (rf() < .8) amt["PetrolFuel"] = step(4000, 25000, 1000) else amt["DieselFuel"] = step(8000, 30000, 1000)
            if (rf() < .35) amt["GenMaintenance"] = step(1000, 5000)
        }
        if ("Battery or charging service" in used) amt["BatteryCharging"] = step(500, 4000)
        if (main in setOf("No electricity", "Solar lantern", "Generator") && rf() < .5) amt["Kerosene"] = step(500, 3000)
        if (main in setOf("No electricity", "Solar lantern") && rf() < .4) amt["Candles"] = step(200, 1000, 100)
        val names = mapOf("Minigrid" to "Mini-grid payment", "NationalGrid" to "National grid", "PetrolFuel" to "Petrol generator fuel",
            "DieselFuel" to "Diesel generator fuel", "GenMaintenance" to "Generator maintenance", "Kerosene" to "Kerosene", "Candles" to "Candles",
            "BatteryCharging" to "Battery or charging service")
        val sel = amt.filter { it.value != null }.keys.toList()
        put("B9_Sources_used", sel.joinToString("; ") { names[it]!! })
        var prim = ""
        if (sel.isNotEmpty()) {
            val pref = mapOf("Mini-grid" to "Minigrid", "National grid" to "NationalGrid", "Generator" to "PetrolFuel", "Battery or charging service" to "BatteryCharging")[main]
            prim = if (pref != null && pref in sel) names[pref]!! else names[sel[0]]!!
            if (main == "Generator" && "PetrolFuel" !in sel) prim = names["DieselFuel"]!!
        }
        put("B9_Primary_source", prim)
        for ((k, v) in amt) put("B9_${k}_NGN", v ?: "")
        val tot = amt.values.sumOf { it ?: 0 }
        put("B9_Total_NGN", tot)
        put("B9b_Overall_spend_stated_NGN", if (tot > 0) Math.round(tot * (0.8 + rf() * 0.45) / 1000.0) * 1000 else w(0 to 70, 500 to 15, 1000 to 15))
        val fuel = w("Firewood or biomass" to 62, "Charcoal" to 12, "Kerosene" to 5, "Liquefied petroleum gas (LPG)" to 17, "Electricity" to 1, "Other" to 3)
        val trad = "Traditional stove (locally made metal or clay)"; val ics = "Improved cookstove (ICS)"
        val stove = wl(when (fuel) {
            "Firewood or biomass" -> listOf("Three-stone or open fire" to 70, trad to 22, ics to 8)
            "Charcoal" -> listOf(trad to 80, ics to 20)
            "Kerosene" -> listOf(trad to 70, "Other" to 30)
            "Liquefied petroleum gas (LPG)" -> listOf(ics to 30, "Other" to 70)
            "Electricity" -> listOf("Other" to 100)
            else -> listOf(ics to 50, trad to 50)
        })
        val spend: Int; val collect: Int
        if (fuel == "Firewood or biomass") { if (rf() < .7) { spend = 0; collect = ri(3, 15) } else { spend = step(1000, 4000); collect = ri(0, 3) } }
        else {
            collect = 0
            spend = when (fuel) { "Charcoal" -> step(2500, 9000); "Kerosene" -> step(1500, 5000); "Liquefied petroleum gas (LPG)" -> step(4000, 10000); "Electricity" -> 0; else -> step(1000, 3000) }
        }
        put("B10_Main_cooking_fuel", fuel); put("B10a_Stove_type", stove); put("B11_Cooking_fuel_spend_NGN", spend); put("B12_Collection_hours_per_week", collect)
        val col = ArrayList<String>()
        if (collect > 0) {
            if (yw + ow > 0 && rf() < .9) col.add("Women (18 and above)")
            if (ym + om > 0 && rf() < .2) col.add("Men (18 and above)")
            if (kids > 0) { if (rf() < .6) col.add("Girls (under 18)"); if (rf() < .4) col.add("Boys (under 18)") }
            if (col.isEmpty()) col.add(if (yw + ow > 0) "Women (18 and above)" else if (ym + om > 0) "Men (18 and above)" else "Girls (under 18)")
        }
        put("B12a_Fuel_collectors", col.joinToString("; "))
        val b13 = if (fuel == "Electricity") "" else w("Yes" to 30, "Maybe, depending on cost" to 42, "No" to 20, "Do not know" to 8)
        put("B13_Would_cook_with_electricity", b13)
        // ---------------- stage 3: cooking attitudes, appliances, needs, mini-grid experience
        val elec = main != "No electricity"
        val reasons = ArrayList<String>(); var other = ""
        if (b13 in setOf("Maybe, depending on cost", "No", "Do not know")) {
            var rp = listOf("Cost of electricity" to 30, "Cost of an electric cooking appliance" to 28, "Supply not reliable enough" to 25, "Safety concerns" to 6,
                "Prefers the taste or method of current fuel" to 18, "Not familiar with electric cooking" to 12, "Other" to 8)
            if (b13 == "No") rp = rp.map { (a, b) -> a to (if (a in setOf("Prefers the taste or method of current fuel", "Not familiar with electric cooking", "Other")) b * 2 else b) }
            repeat(choice(listOf(1, 2, 2))) { val c = wl(rp); if (c !in reasons) reasons.add(c) }
            if ("Other" in reasons) other = choice(listOf("Speed of cooking", "Traditional dishes need open fire", "Fuel is free to collect", "Worried about appliance breakdown", "Cooking pots are not suitable"))
        }
        put("B13a_Main_reasons", reasons.joinToString("; ")); put("B13a_Other_specify", other)
        put("B13b_Heard_of_electric_cooking", when {
            fuel == "Electricity" -> "Yes"
            "Not familiar with electric cooking" in reasons -> w("No" to 70, "Not sure" to 30)
            else -> w("Yes" to 55, "No" to 30, "Not sure" to 15)
        })
        put("B13b_Smoke_harms_health", if (fuel in setOf("Firewood or biomass", "Charcoal", "Kerosene")) w("Yes" to 70, "No" to 15, "Not sure" to 15) else "")
        val mgGood = main == "Mini-grid" && hrs in setOf("16–22", "23–24")
        val owned = linkedMapOf("Lighting" to (if (elec) ri(2, 10) else ri(1, 4)), "Phone charging" to ri(1, 5))
        val pf = if (main == "Solar lantern") .15 else if (elec) .75 else .08
        if (rf() < pf) owned["Fan"] = ri(1, 4)
        if (rf() < (if (elec) .65 else .12)) owned["Television/radio"] = ri(1, 2)
        if (rf() < (if (mgGood || main == "National grid") .35 else .03)) owned["Refrigerator/freezer"] = 1
        if (rf() < (if (elec) .1 else .02)) owned["Water pump"] = 1
        if (rf() < (if (elec) .14 else .04) || (liv == "Artisan work" && rf() < .3)) owned["Sewing machine"] = 1
        if (rf() < (if (elec) .14 else .03)) owned["ICT equipment"] = ri(1, 2)
        val appRows = ArrayList<Rec>()
        for ((a, k) in owned) {
            var wk = if (a == "Lighting" || a == "Phone charging") ri(maxOf(0, k - 2), k) else choice(listOf(k, k, k, maxOf(0, k - 1)))
            if (!elec && a == "Phone charging") wk = k
            val pw = if (k - wk > 0 && rf() < .5) ri(0, k - wk) else 0
            val acq = if (!wp) "" else if (connected && rf() < (if (a == "Lighting" || a == "Phone charging") .25 else .4)) "Yes" else "No"
            appRows.add(linkedMapOf("Record" to "$i", "Site_type" to site, "Appliance" to a, "Number_owned" to "$k", "Acquired_after_minigrid" to acq,
                "Number_working_W" to "$wk", "Number_partly_working_PW" to "$pw", "Number_not_working_NW" to "${k - wk - pw}"))
        }
        put("C1_Appliances_owned", owned.keys.joinToString("; "))
        val power = mapOf("Fan" to (50 to 75), "Television/radio" to (25 to 100), "Refrigerator/freezer" to (100 to 200), "Water pump" to (370 to 750),
            "Sewing machine" to (70 to 120), "ICT equipment" to (20 to 65))
        val price = mapOf("Fan" to (15000 to 45000), "Television/radio" to (30000 to 150000), "Refrigerator/freezer" to (150000 to 450000),
            "Water pump" to (60000 to 200000), "Sewing machine" to (40000 to 120000), "ICT equipment" to (50000 to 300000))
        val big = listOf("Water pump", "Refrigerator/freezer", "Sewing machine", "Television/radio", "Fan", "ICT equipment").filter { it in owned }.take(2)
        for (k in 1..2) {
            if (big.size >= k) {
                val a = big[k - 1]; val (lo, hi) = power[a]!!
                put("C1b_App$k", a); put("C1b_App${k}_rated_W", if (rf() < .3) "" else ri(lo / 5, hi / 5) * 5)
                val cond = w("New" to 45, "Second-hand" to 55); put("C1b_App${k}_condition", cond)
                val (plo, phi) = price[a]!!
                val p = ri(plo / 1000, phi / 1000) * 1000
                put("C1b_App${k}_price_NGN", if (cond == "New") p else (p * 0.6 / 1000).toInt() * 1000)
            } else { put("C1b_App$k", ""); put("C1b_App${k}_rated_W", ""); put("C1b_App${k}_condition", ""); put("C1b_App${k}_price_NGN", "") }
        }
        val biz = liv in setOf("Trading", "Agro-processing", "Artisan work", "Services or salaried employment")
        val c2 = if (rf() < (if (biz) .6 else .2)) "Yes" else "No"; put("C2_Home_business", c2)
        put("C5_Unmet_need", when {
            !elec -> "Access to electricity at all"
            main == "Mini-grid" -> w("More hours of supply" to 15, "More reliable supply" to 20, "Lower cost" to 30, "Enough power for more appliances" to 30, "Safer supply" to 3, "Other" to 2)
            main == "Generator" -> w("Lower cost" to 40, "More hours of supply" to 20, "More reliable supply" to 20, "Enough power for more appliances" to 15, "Safer supply" to 5)
            else -> w("More hours of supply" to 30, "More reliable supply" to 20, "Lower cost" to 15, "Enough power for more appliances" to 30, "Other" to 5)
        })
        val farm = liv == "Crop farming"
        val c6p = listOf("Refrigerator or freezer" to .55, "Television" to .4, "Fan" to .35, "Phone charging" to .2, "Lighting" to .2, "Sewing or tailoring" to .12,
            "Hairdressing or barbing" to .08, "Welding" to .05, "Food processing" to (if (farm || liv == "Agro-processing") .4 else .15),
            "Water pumping or irrigation" to (if (farm) .3 else .08), "Other" to .03)
        put("C6_Most_wanted_use", c6p.filter { rf() < it.second }.map { it.first }.ifEmpty { listOf("Refrigerator or freezer") }.joinToString("; "))
        put("C6a_Barrier", when {
            main == "No electricity" -> w("No electricity supply" to 70, "Cannot afford the appliance" to 25, "Other" to 5)
            mgGood -> w("Cannot afford the appliance" to 40, "Running cost or tariff too high" to 35, "Not sold locally" to 5, "Supply too weak to run it" to 10, "Already uses it" to 8, "Other" to 2)
            else -> w("Cannot afford the appliance" to 30, "Supply too weak to run it" to 20, "Supply too unreliable" to 25, "Running cost or tariff too high" to 18, "Not sold locally" to 4, "Other" to 3)
        })
        put("C6b_Able_to_pay_3m", if (tot == 0) "No electricity cost" else w("Yes, every month" to 35, "Most months" to 45, "Rarely or never" to 20))
        put("C7_Affordable_monthly_bill", when (inc) {
            "Do not know", "Prefer not to say" -> "Not sure or cannot estimate"
            "Below NGN 600,000" -> w("Less than NGN 1,000" to 25, "NGN 1,000 – 2,500" to 50, "NGN 2,501 – 5,000" to 25)
            "NGN 600,000 – 1,199,999" -> w("NGN 1,000 – 2,500" to 30, "NGN 2,501 – 5,000" to 50, "NGN 5,001 – 10,000" to 20)
            "NGN 1,200,000 – 2,399,999" -> w("NGN 2,501 – 5,000" to 35, "NGN 5,001 – 10,000" to 50, "Above NGN 10,000" to 15)
            "NGN 2,400,000 – 4,799,999" -> w("NGN 5,001 – 10,000" to 50, "Above NGN 10,000" to 50)
            "NGN 4,800,000 and above" -> "Above NGN 10,000"
            else -> w("Less than NGN 1,000" to 20, "NGN 1,000 – 2,500" to 35, "NGN 2,501 – 5,000" to 30, "Not sure or cannot estimate" to 15)
        })
        var c8 = ""; var d1 = ""; var d1o = ""; var d2 = ""
        val maybe = "Maybe, depending on tariff or connection cost"
        if (wp) {
            if (connected) {
                var cp = listOf("High tariff or cost" to 30, "Insufficient hours of supply" to 15, "Frequent outages" to 20, "Recharge or payment difficulty" to 12,
                    "Payment platform or network problems" to 10, "Technical faults" to 10, "No major challenge" to 20, "Other" to 6)
                if (outs == "Never") cp = cp.filter { it.first != "Frequent outages" }
                if (hrs in setOf("16–22", "23–24")) cp = cp.filter { it.first != "Insufficient hours of supply" }
                val ch = arrayListOf(wl(cp))
                if (ch[0] != "No major challenge" && rf() < .4) ch.add(wl(cp.filter { it.first != ch[0] && it.first != "No major challenge" }))
                d1 = ch.joinToString("; ")
                if ("Other" in ch) d1o = choice(listOf("Income not aligned with payment dates", "Long distance to vending agent", "Meter faults after rain", "Slow customer service response"))
                val good = hrs in setOf("23–24", "16–22") && outs in setOf("Never", "1–2 times")
                d2 = if (good) w("Yes" to 60, "Partly" to 30, "No" to 5, "Not sure" to 5) else w("Yes" to 20, "Partly" to 50, "No" to 25, "Not sure" to 5)
                c8 = if (d2 == "Yes" && rf() < .55) "Already adequately served" else w("Yes" to 45, maybe to 40, "No" to 5, "Not sure" to 10)
            } else if (conn == "No - not connected") c8 = w("Yes" to 45, maybe to 40, "No" to 5, "Not sure" to 10)
            else c8 = w("Yes" to 20, maybe to 50, "No" to 20, "Not sure" to 10)
        }
        put("C8_Would_connect_or_increase_use", c8); put("D1_Main_challenges", d1); put("D1_Other_specify", d1o); put("D2_Minigrid_meets_needs", d2)
        // ---------------- stage 4: mini-grid impact + enumerator note
        listOf("D2b_Use_change_since_connecting", "D3_Most_improved", "D4_Night_safety_change", "D5_Quality_of_life_change", "D6_Likelihood_to_recommend_0_10").forEach { put(it, "") }
        if (connected && wp) {
            val good = d2 == "Yes"
            put("D2b_Use_change_since_connecting", if (good) w("Increased" to 60, "About the same" to 20, "High at first, then reduced" to 8, "Reduced" to 5, "Do not know" to 7)
                else w("Increased" to 30, "About the same" to 30, "High at first, then reduced" to 20, "Reduced" to 15, "Do not know" to 5))
            val d5 = when {
                good -> w("Very much improved" to 50, "Slightly improved" to 40, "No change" to 10)
                d2 == "Partly" -> w("Very much improved" to 10, "Slightly improved" to 40, "No change" to 35, "Slightly worse" to 12, "Significantly worse" to 3)
                else -> w("Slightly improved" to 20, "No change" to 45, "Slightly worse" to 25, "Significantly worse" to 10)
            }
            put("D5_Quality_of_life_change", d5)
            var d3: List<String>
            if (d5 in setOf("No change", "Slightly worse", "Significantly worse") && rf() < .7) d3 = listOf("No improvement")
            else {
                val p = listOf("More reliable supply", "Longer hours of electricity", "Lower electricity cost", "Ability to use more appliances",
                    "Improved business or income activity", "Better lighting at home", "Improved security at night", "Children study more")
                val wt = doubleArrayOf(.3, .35, .15, .3, if (c2 == "Yes") .25 else .08, .7, .5, if (kids > 0) .45 else .05)
                if (b2 in setOf("No electricity", "Solar lantern", "Battery or charging service")) wt[1] += .2
                d3 = p.filterIndexed { k, _ -> rf() < wt[k] }.ifEmpty { listOf("Better lighting at home") }
                if (outs in setOf("3–5 times", "More than 5 times or daily")) d3 = d3.filter { it != "More reliable supply" }.ifEmpty { listOf("Better lighting at home") }
            }
            put("D3_Most_improved", d3.joinToString("; "))
            put("D4_Night_safety_change", when {
                "Improved security at night" in d3 -> w("Much safer" to 60, "Somewhat safer" to 38, "No change" to 2)
                "No improvement" in d3 -> w("No change" to 70, "Somewhat less safe" to 20, "Somewhat safer" to 10)
                else -> w("Much safer" to 20, "Somewhat safer" to 45, "No change" to 30, "Somewhat less safe" to 5)
            })
            val (lo, hi) = mapOf("Very much improved" to (8 to 10), "Slightly improved" to (5 to 9), "No change" to (3 to 7), "Slightly worse" to (1 to 5), "Significantly worse" to (0 to 3))[d5]!!
            put("D6_Likelihood_to_recommend_0_10", ri(lo, hi))
        }
        val notes = arrayListOf("Respondent busy; interview completed over two visits", "Household members joined discussion; respondent answered final figures",
            "Rated power labels worn off appliances", "Interview conducted in Hausa with translation", "Poor network during GPS capture; waited for fix",
            "Generator noise during part of interview", "Respondent unsure of exact payment amounts; estimates recorded", "Meter box not accessible to check tariff")
        if (main == "No electricity") notes.add("Household not connected; solar lantern observed")
        put("E3_Enumerator_observations", if (rf() < .6) "No observations" else choice(notes))
        return r to appRows
    }
}
