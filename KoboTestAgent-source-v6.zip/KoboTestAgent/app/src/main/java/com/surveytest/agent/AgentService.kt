package com.surveytest.agent

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.text.InputType
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.surveytest.agent.core.Control
import com.surveytest.agent.core.Device
import com.surveytest.agent.core.Engine
import com.surveytest.agent.core.Reporter
import com.surveytest.agent.core.Timing
import com.surveytest.agent.core.UiNode
import com.surveytest.agent.core.explain
import java.io.File
import java.io.FileOutputStream

/**
 * The accessibility service: reads KoboCollect's screen and taps/types on it.
 * It only acts while a test run is going; the rest of the time it does nothing.
 */
class AgentService : AccessibilityService() {
    companion object {
        @Volatile var instance: AgentService? = null
        @Volatile var running = false
        @Volatile var recording = false
    }
    private var recCount = 0
    private var lastRecSig = ""
    private var recPending = false
    private var recPkg = ""

    private val ui = Handler(Looper.getMainLooper())
    private var bubble: Bubble? = null
    private var control: Control? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        bubble = Bubble(this,
            onPauseToggle = { control?.let { it.paused = !it.paused; it.paused } ?: false },
            onStop = { if (recording) stopRecording() else { control?.stopped = true; control?.paused = false } },
            onClose = { bubble?.hide() })
        // The green accessibility shortcut button: show Pause / Continue instead of switching the agent off
        try {
            accessibilityButtonController.registerAccessibilityButtonCallback(object : AccessibilityButtonController.AccessibilityButtonCallback() {
                override fun onClicked(controller: AccessibilityButtonController) { ui.post { onShortcutButton() } }
            })
        } catch (_: Exception) {}
    }

    private fun onShortcutButton() {
        if (running || recording) bubble?.expand()
        else startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Keep the screen on and bright for the whole run, like a video player. */
    @Suppress("DEPRECATION")
    private fun keepScreenOn(on: Boolean) {
        try {
            if (on) {
                if (wake?.isHeld == true) return
                val pm = getSystemService(PowerManager::class.java)
                wake = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE, "KoboTestAgent:run")
                    .apply { setReferenceCounted(false); acquire(8 * 60 * 60 * 1000L) }
            } else { wake?.let { if (it.isHeld) it.release() }; wake = null }
        } catch (_: Exception) {}
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!recording || event == null || event.packageName?.toString() != recPkg) return
        if (!recPending) { recPending = true; ui.postDelayed({ recPending = false; captureScreen() }, 900) }
    }

    // ---------------------------------------------------------------- "Record screens" mode
    /** You fill a form by hand; every new KoboCollect screen is saved (layout + screenshot + how the agent reads it). */
    fun startRecording(): String? {
        if (running) return "Stop the test run first"
        recPkg = AppStore.rules(this).packageName
        recording = true; recCount = 0; lastRecSig = ""
        AppStore.log(this, 0, "INFO", "", "", "recording screens started")
        bubble?.showRecording()
        return null
    }

    fun stopRecording() {
        if (!recording) return
        recording = false
        AppStore.log(this, 0, "INFO", "", "", "recording stopped: $recCount screens saved")
        bubble?.finished("Saved $recCount screens. In the app tap 'Share log + snapshots' and send the zip.")
    }

    private fun captureScreen() {
        if (!recording) return
        val r = rootInActiveWindow ?: return
        if (r.packageName?.toString() != recPkg) return
        val dev = AndroidDevice()
        val node = dev.root() ?: return
        val sig = node.signature()
        if (sig == lastRecSig) return
        lastRecSig = sig; recCount++
        val name = "screen_%03d".format(recCount)
        try { java.io.File(AppStore.snapshotDir(this), "$name.txt").writeText(explain(node, AppStore.rules(this))) } catch (_: Exception) {}
        dev.snapshot(name, null, textToo = false)
        bubble?.update(0, recCount, 0, "Saved screen $recCount. Keep filling the form by hand.", false)
    }
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean { shutdown(); return super.onUnbind(intent) }
    override fun onDestroy() { shutdown(); super.onDestroy() }
    private fun shutdown() { control?.stopped = true; keepScreenOn(false); bubble?.hide(); instance = null }

    /** Starts a run. Returns an error message, or null when it started. */
    fun start(ids: List<Int>, delayMs: Long, dateOrder: String, autoAnswer: Boolean, keepGoing: Boolean, superSpeed: Boolean, strict: Boolean): String? {
        if (running) return "A run is already going"
        if (recording) stopRecording()
        val data = AppStore.dataset(this) ?: return "No test data yet - generate or import it first"
        val rules = AppStore.rules(this)
        if (packageManager.getLaunchIntentForPackage(rules.packageName) == null) return "${rules.packageName} is not installed"
        val ctl = Control(); control = ctl; running = true
        AppStore.log(this, 0, "INFO", "", "", "run started: records ${ids.first()}..${ids.last()} (${ids.size}), form '${rules.formName}'")
        bubble?.show(ids.size)
        keepScreenOn(true)
        Thread {
            val rep = object : Reporter {
                override fun status(record: Int, done: Int, total: Int, text: String) { ui.post { bubble?.update(record, done, total, text, ctl.paused) } }
                override fun log(record: Int, kind: String, key: String, value: String, note: String) = AppStore.log(this@AgentService, record, kind, key, value, note)
            }
            var done = 0
            try {
                done = Engine(AndroidDevice(), rules, data, rep, ctl, delayMs = delayMs, dateOrder = dateOrder,
                    autoAnswer = autoAnswer, seed = System.currentTimeMillis(), keepGoing = keepGoing,
                    t = if (superSpeed) Timing.SUPER else Timing.NORMAL, strict = strict).run(ids)
            } catch (e: Throwable) {
                rep.log(0, "ERROR", "", "", "agent crashed: $e")
            } finally {
                running = false
                ui.post { keepScreenOn(false) }
                AppStore.log(this, 0, "INFO", "", "", "run ended: $done of ${ids.size} saved as drafts")
                ui.post { bubble?.finished("$done of ${ids.size} saved as drafts") }
            }
        }.apply { name = "agent-run" }.start()
        return null
    }

    // ---------------------------------------------------------------- the phone, as the engine sees it
    inner class AndroidDevice : Device {
        override fun root(): UiNode? {
            val r = rootInActiveWindow ?: return null
            return convert(r, 0)
        }

        private fun convert(n: AccessibilityNodeInfo, depth: Int): UiNode {
            val b = Rect(); n.getBoundsInScreen(b)
            val kids = ArrayList<UiNode>()
            if (depth < 60) for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                if (c.isVisibleToUser) kids.add(convert(c, depth + 1))
            }
            return UiNode(
                cls = n.className?.toString() ?: "", text = n.text?.toString() ?: "",
                desc = n.contentDescription?.toString() ?: "", id = n.viewIdResourceName ?: "",
                left = b.left, top = b.top, right = b.right, bottom = b.bottom,
                checked = n.isChecked, scrollable = n.isScrollable, children = kids, ref = n,
                numeric = (n.inputType and InputType.TYPE_MASK_CLASS).let { it == InputType.TYPE_CLASS_NUMBER || it == InputType.TYPE_CLASS_PHONE },
            )
        }

        override fun click(n: UiNode): Boolean {
            val node = n.ref as? AccessibilityNodeInfo ?: return tap(n.cx, n.cy)
            var c: AccessibilityNodeInfo? = node
            while (c != null && !c.isClickable) c = c.parent
            val ok = (c ?: node).performAction(AccessibilityNodeInfo.ACTION_CLICK)
            return ok || tap(n.cx, n.cy)
        }

        private fun tap(x: Int, y: Int): Boolean {
            if (x <= 0 && y <= 0) return false
            val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
            return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
        }

        override fun setText(n: UiNode, text: String): Boolean {
            val node = n.ref as? AccessibilityNodeInfo ?: return false
            val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
            if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS); Thread.sleep(200)
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }

        override fun scrollForward(root: UiNode): Boolean {
            val target = root.walk().filter { it.scrollable && it.ref is AccessibilityNodeInfo }
                .maxByOrNull { (it.right - it.left).toLong() * (it.bottom - it.top) } ?: return false
            return (target.ref as AccessibilityNodeInfo).performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        }

        override fun back() { performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) }

        override fun keyboardShown(): Boolean = try { windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD } } catch (_: Exception) { false }

        override fun swipeNext(): Boolean {
            val dm = resources.displayMetrics
            val y = dm.heightPixels * 0.5f
            val p = Path().apply { moveTo(dm.widthPixels * 0.85f, y); lineTo(dm.widthPixels * 0.12f, y) }
            return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 220)).build(), null, null)
        }

        override fun launch(pkg: String): Boolean {
            val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(i); return true
        }

        override fun sleep(ms: Long) = Thread.sleep(ms)

        override fun snapshot(name: String, root: UiNode?) = snapshot(name, root, true)

        fun snapshot(name: String, root: UiNode?, textToo: Boolean) {
            val dir = AppStore.snapshotDir(this@AgentService)
            if (textToo) File(dir, "$name.txt").writeText(root?.let { explain(it, AppStore.rules(this@AgentService)) } ?: "(no screen)")
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                        val full = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        // half size JPEG keeps the shared report small (a few MB instead of 70+)
                        val bmp = full?.let { Bitmap.createScaledBitmap(it, it.width / 2, it.height / 2, true) }
                        if (bmp != null) FileOutputStream(File(dir, "$name.jpg")).use { bmp.compress(Bitmap.CompressFormat.JPEG, 70, it) }
                    } catch (_: Exception) {
                    } finally { result.hardwareBuffer.close() }
                }
                override fun onFailure(errorCode: Int) {}
            })
        }
    }
}
