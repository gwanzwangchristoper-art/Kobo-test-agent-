import com.surveytest.agent.core.*

/** A small KoboCollect form WITH skip logic, one question per screen, for testing "View form". */
class BranchFake : Device {
    class Q(val id: String, val sec: String, val label: String, val type: String, val opts: List<String> = emptyList(),
            val rel: (Map<String, String>) -> Boolean = { true }, val ok: (String) -> Boolean = { true }, val required: Boolean = true)
    val qs = listOf(
        Q("consent", "A. Consent", "A0. Do you agree to take part?", "radio", listOf("Yes", "No")),
        Q("sex", "A. Household profile", "A1. Sex of respondent", "radio", listOf("Female", "Male", "Prefer not to say"), rel = { it["consent"] == "Yes" }),
        Q("gen", "B. Energy", "B5. Does the household own a generator?", "radio", listOf("Yes", "No"), rel = { it["consent"] == "Yes" }),
        Q("genfuel", "B. Energy > B5a. Generator", "B5a. Litres of fuel bought last week", "num", rel = { it["gen"] == "Yes" }, ok = { (it.toIntOrNull() ?: 0) >= 2 }),
        Q("work", "A. Household profile", "A8. What do members do for income?", "check", listOf("Farming", "Trading", "Other", "None"), rel = { it["consent"] == "Yes" }),
        Q("workother", "A. Household profile", "A8a. Specify the other work", "edit", rel = { "Other" in (it["work"] ?: "").split(";") }),
        Q("lga", "A. Location", "A9. LGA", "spinner", listOf("Kwali", "Abaji", "Gwagwalada"), rel = { it["consent"] == "Yes" }),
        Q("e3", "E. Enumerator record", "E3. Enumerator observations and any difficulty encountered", "edit", required = false),
    )
    var onMenu = true; var idx = -1; val ans = LinkedHashMap<String, String>()
    var popup = false; var exitDialog = false; var saved = 0; var discarded = 0; var shots = 0; var launched = 0
    val seenQ = LinkedHashSet<String>()
    private fun cr(sec: String) = "Household Energy and Living Standards Survey > $sec"
    private fun n(cls: String, t: String, l: Int, tp: Int, r: Int, b: Int, id: String = "", checked: Boolean = false, ref: Any? = null, num: Boolean = false) =
        UiNode("android.widget.$cls", t, "", id, l, tp, r, b, checked, false, emptyList(), ref, num)
    private fun nextRelevant(from: Int): Int { var i = from + 1; while (i < qs.size && !qs[i].rel(ans)) i++; return i }
    override fun root(): UiNode {
        val out = ArrayList<UiNode>()
        when {
            onMenu -> out += n("Button", "Start new form", 50, 800, 1030, 950, ref = "start")
            exitDialog -> {
                out += n("TextView", "Save changes before leaving?", 100, 900, 980, 1000, id = "android:id/message")
                out += n("Button", "Save changes", 100, 1100, 500, 1200, id = "android:id/button1", ref = "savechanges")
                out += n("Button", "Ignore changes", 580, 1100, 980, 1200, id = "android:id/button2", ref = "ignore")
            }
            idx >= qs.size -> { out += n("Button", "Save as draft", 50, 1500, 500, 1650, ref = "draft"); out += n("Button", "Finalize", 550, 1500, 1030, 1650, ref = "final") }
            popup -> qs[idx].opts.forEachIndexed { j, o -> out += n("CheckedTextView", o, 100, 600 + j * 120, 980, 700 + j * 120, ref = "opt|$o") }
            else -> {
                val q = qs[idx]; seenQ += q.id
                out += n("TextView", cr(q.sec), 50, 330, 1030, 440)
                out += n("TextView", q.label, 50, 500, 1030, 590)
                var y = 620
                val cur = ans[q.id] ?: ""
                when (q.type) {
                    "radio", "check" -> for (o in q.opts) { out += n(if (q.type == "radio") "RadioButton" else "CheckBox", o, 50, y, 1030, y + 130, checked = o in cur.split(";"), ref = "pick|$o"); y += 150 }
                    "edit", "num" -> out += n("EditText", cur, 50, y, 1030, y + 130, ref = "box", num = q.type == "num")
                    "spinner" -> out += n("Spinner", cur.ifEmpty { "Select One Answer" }, 50, y, 1030, y + 130, ref = "spin")
                }
                out += n("Button", "Back", 50, 2250, 500, 2380); out += n("Button", "Next", 560, 2250, 1030, 2380, ref = "next")
            }
        }
        return UiNode("android.widget.FrameLayout", "", "", "", 0, 0, 1080, 2400, false, false, out)
    }
    override fun click(n: UiNode): Boolean {
        val r = n.ref as? String ?: return true
        when {
            r == "start" -> { onMenu = false; ans.clear(); idx = nextRelevant(-1) }
            r == "next" -> {
                val q = qs[idx]; val v = ans[q.id] ?: ""
                if ((q.required && v.isBlank()) || (v.isNotBlank() && !q.ok(v))) return true
                idx = nextRelevant(idx)
            }
            r == "draft" || r == "final" || r == "savechanges" -> { saved++; onMenu = true; exitDialog = false }
            r == "ignore" -> { discarded++; onMenu = true; exitDialog = false }
            r == "spin" -> popup = true
            r.startsWith("opt|") -> { ans[qs[idx].id] = r.removePrefix("opt|"); popup = false }
            r.startsWith("pick|") -> {
                val o = r.removePrefix("pick|"); val q = qs[idx]
                if (q.type == "radio") ans[q.id] = o
                else { val set = (ans[q.id] ?: "").split(";").filter { it.isNotEmpty() }.toMutableList(); if (o in set) set.remove(o) else set.add(o); ans[q.id] = set.joinToString(";") }
            }
        }
        return true
    }
    override fun setText(n: UiNode, text: String): Boolean { ans[qs[idx].id] = text; return true }
    override fun scrollForward(root: UiNode) = false
    override fun back() { if (popup) popup = false else if (!onMenu && !exitDialog) exitDialog = true }
    override fun launch(pkg: String): Boolean { launched++; return true }
    override fun sleep(ms: Long) {}
    override fun snapshot(name: String, root: UiNode?) {}
    override fun capture(folder: String, name: String, root: UiNode?, text: String) { shots++; check(text.contains("How the agent reads")) { "capture text" } }
    override fun currentPackage() = "org.koboc.collect.android"
}

fun exploreTests(rules: Rules) {
    val f = BranchFake(); val rep = Rep(); val map = FormMap("Test form")
    Engine(f, rules, Dataset(listOf(mapOf("Record" to "1")), emptyList(), "t"), rep, Control(), delayMs = 0, t = Timing.ULTRA).explore(10, map)
    val log = rep.logs.joinToString("\n")
    check(f.saved == 0) { "View form must never save: saved=${f.saved}\n$log" }
    check(f.discarded == map.routes.size) { "every pass discarded: ${f.discarded} vs ${map.routes.size}" }
    check(f.seenQ == f.qs.map { it.id }.toSet()) { "every question reached: ${f.seenQ}\n$log\n${map.routesText()}" }
    check(map.screens.size == f.qs.size + 1) { "screens ${map.screens.keys}" }
    val all = map.screens.values.flatMap { it.fields }
    for (fld in all.filter { it.isChoice }) check(fld.untried().isEmpty()) { "untried options in ${fld.label}: ${fld.untried()}" }
    check(all.first { it.label.startsWith("A9") }.options == listOf("Kwali", "Abaji", "Gwagwalada")) { "dropdown options recorded" }
    check(map.screens.values.first { it.isEnd }.passes.isNotEmpty()) { "end reached" }
    check(f.shots == map.screens.values.sumOf { it.shots.size } && f.shots >= map.screens.size) { "shots ${f.shots}" }
    // consent No must lead straight to E3
    val consent = map.screens.values.first { s -> s.fields.any { it.label.startsWith("A0") } }
    val e3 = map.screens.values.first { s -> s.fields.any { it.label.startsWith("E3") } }
    check(map.edges.any { it.from == consent.no && it.answers.contains("= No") && it.to == e3.no }) { "consent No -> E3 edge\n" + map.formMapText() }
    val txt = map.formMapText(); val csv = map.questionsCsv(); val js = map.toJson(); val routes = map.routesText()
    check("** NO RULE **" in txt || "data column:" in txt) { "map text" }
    check(csv.lines().size >= f.qs.size + 1 && csv.startsWith("screen,section,question")) { "csv" }
    check((Json.parse(js) as Map<*, *>)["screens"] is List<*>) { "json" }
    check(routes.contains("Pass 1")) { "routes" }
    println("view form: ${map.routes.size} passes, ${map.screens.size} screens, ${map.questionCount()} questions, every option tried, nothing saved (${map.finishedReason}) OK")
    if (System.getenv("SHOWMAP") != null) println(txt + "\n" + routes + "\n" + csv)
}

/** E3 last screen: the first typing is lost by the phone; the agent must notice, type again, then save. */
fun lastScreenTests(rules: Rules) {
    class Lossy : Device {
        var screen = 0; var text = ""; var lost = 2; var saved = false
        override fun root(): UiNode {
            val out = ArrayList<UiNode>()
            if (screen == 2) out += UiNode("android.widget.Button", "Start new form", "", "", 50, 800, 1030, 950, false, false, emptyList())
            else if (screen == 1) out += UiNode("android.widget.Button", "Save as draft", "", "", 50, 1500, 500, 1650, false, false, emptyList(), "draft")
            else {
                out += UiNode("android.widget.TextView", "Household Energy and Living Standards Survey > E. Enumerator record", "", "", 50, 330, 1030, 440, false, false, emptyList())
                out += UiNode("android.widget.TextView", "E3. Enumerator observations and any difficulty encountered", "", "", 50, 500, 1030, 650, false, false, emptyList())
                out += UiNode("android.widget.EditText", text, "", "", 50, 700, 1030, 880, false, false, emptyList(), "box")
                out += UiNode("android.widget.Button", "Next", "", "", 560, 1300, 1030, 1430, false, false, emptyList(), "next")
            }
            return UiNode("android.widget.FrameLayout", "", "", "", 0, 0, 1080, 2400, false, false, out)
        }
        override fun click(n: UiNode): Boolean { when (n.ref) { "next" -> if (text.isNotBlank()) screen = 1; "draft" -> { saved = true; screen = 2 } }; return true }
        override fun setText(n: UiNode, text: String): Boolean { if (lost > 0) { lost--; return true }; this.text = text; return true }
        override fun scrollForward(root: UiNode) = false
        override fun back() {}
        override fun launch(pkg: String) = true
        override fun sleep(ms: Long) {}
        override fun snapshot(name: String, root: UiNode?) {}
    }
    val d = Lossy(); val rep = Rep()
    val data = Dataset(listOf(mapOf("Record" to "1", "E3_Enumerator_observations" to "Fine")), emptyList(), "t")
    val n = Engine(d, rules, data, rep, Control(), delayMs = 0, t = Timing.ULTRA).run(listOf(1), formAlreadyOpen = true)
    check(n == 1 && d.saved && d.text == "[TEST] Fine") { "E3 lost typing: saved=${d.saved} text='${d.text}'\n" + rep.logs.joinToString("\n") }
    println("E3 last screen: typing lost twice by the phone, read back, typed again, saved as draft OK")
    check(rules.isLastQuestion(listOf("E3. Enumerator observations")) && !rules.isLastQuestion(listOf("E2. Photo"))) { "lastQuestion" }
    check(sameValue("5,000", "5000") && sameValue("8.0", "8") && !sameValue("", "[TEST] x")) { "sameValue" }
    check(Timing.ULTRA.ms(700) * 7 <= Timing.SUPER.ms(700) + 7 && Timing.ULTRA.poll * 7 <= Timing.SUPER.poll + 7) { "ultra = super / 7" }
    println("ultra speed: every wait 7 x shorter than super OK")
}

fun importTests() {
    val (a, m1) = Dataset.import("semi.csv", "record ; A1_Sex;A3_Household_size\n1;Male;5\n2;Female;7\n".toByteArray(), null)
    check(a.ids() == listOf(1, 2) && a.record(2)!!["A1_Sex"] == "Female" && a.record(1)!!["A3_Household_size"] == "5") { "semicolon csv: ${a.records} $m1" }
    val (b, m2) = Dataset.import("norecord.csv", "A1_Sex,A3_Household_size\nMale,5\nFemale,7\nMale,3\n".toByteArray(), null)
    check(b.ids() == listOf(1, 2, 3) && "numbered" in m2) { "auto-numbered: ${b.records} $m2" }
    val bad = try { Dataset.import("old.xls", byteArrayOf(0xD0.toByte(), 0xCF.toByte(), 1, 2), null); "" } catch (e: IllegalArgumentException) { e.message ?: "" }
    check(".xlsx" in bad) { "xls message: $bad" }
    println("import: ';' separated CSV, file without Record column, old .xls message OK")
}

/** E3 that never accepts Next: the form must still be saved as a draft (via the question list > Go to end), not thrown away. */
fun lastScreenStuckTest(rules: Rules) {
    class Stuck : Device {
        var state = "e3"; var text = ""; var saved = false; var discarded = false; var otherApp = 0
        fun n(cls: String, t: String, top: Int, ref: Any?, desc: String = "") = UiNode("android.widget.$cls", t, desc, "", 50, top, 1030, top + 120, false, false, emptyList(), ref)
        override fun root(): UiNode {
            val out = when (state) {
                "menu" -> listOf(n("Button", "Start new form", 800, "start"))
                "list" -> listOf(n("Button", "Go to end", 400, "goend"), n("TextView", "E3. Enumerator observations", 600, null))
                "end" -> listOf(n("Button", "Save as draft", 1500, "draft"), n("Button", "Finalize", 1700, "final"))
                else -> listOf(n("ImageButton", "", 150, "list", desc = "Go to question list"),
                    n("TextView", "Household Energy and Living Standards Survey > E. Enumerator record", 330, null),
                    n("TextView", "E3. Enumerator observations and any difficulty encountered", 500, null),
                    n("EditText", text, 700, "box"), n("Button", "Next", 1300, "next"))
            }
            return UiNode("android.widget.FrameLayout", "", "", "", 0, 0, 1080, 2400, false, false, out)
        }
        override fun click(n: UiNode): Boolean { when (n.ref) { "list" -> state = "list"; "goend" -> state = "end"; "draft" -> { saved = true; state = "menu" }; "final" -> throw AssertionError("Finalize tapped") }; return true }
        override fun setText(n: UiNode, text: String): Boolean { this.text = text; return true }
        override fun scrollForward(root: UiNode) = false
        override fun back() { if (state == "list") state = "e3" else discarded = true }
        override fun launch(pkg: String) = true
        override fun sleep(ms: Long) {}
        override fun snapshot(name: String, root: UiNode?) {}
        override fun currentPackage(): String = if (otherApp-- > 0) "com.whatsapp" else "org.koboc.collect.android"
    }
    val d = Stuck(); d.otherApp = 5; val rep = Rep()
    val data = Dataset(listOf(mapOf("Record" to "1", "E3_Enumerator_observations" to "Fine")), emptyList(), "t")
    val n = Engine(d, rules, data, rep, Control(), delayMs = 0, t = Timing.ULTRA).run(listOf(1), formAlreadyOpen = true)
    check(n == 1 && d.saved && !d.discarded) { "stuck E3: saved=${d.saved} discarded=${d.discarded}\n" + rep.logs.joinToString("\n") }
    check(rep.logs.any { "last question would not accept Next" in it }) { "warning logged" }
    println("E3 that refuses Next: waited while another app was in front, then went to the save screen and saved the DRAFT (not thrown away) OK")
}
