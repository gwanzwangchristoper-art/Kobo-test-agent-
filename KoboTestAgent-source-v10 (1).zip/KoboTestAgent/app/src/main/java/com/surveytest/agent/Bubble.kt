package com.surveytest.agent

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * The small floating panel shown over KoboCollect during a run.
 * Shows the current action; Pause/Continue, Stop; drag it anywhere; collapse it to a dot.
 * It is an accessibility overlay, so no "draw over other apps" permission is needed.
 */
class Bubble(
    private val svc: AccessibilityService,
    private val onPauseToggle: () -> Boolean,
    private val onStop: () -> Unit,
    private val onClose: () -> Unit,
) {
    private val wm = svc.getSystemService(WindowManager::class.java)
    private var root: FrameLayout? = null
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var dot: TextView
    private lateinit var title: TextView
    private lateinit var status: TextView
    private lateinit var pauseBtn: Button
    private lateinit var stopBtn: Button
    private var finished = false
    private var total = 0
    /** "run", "record" or "explore" (View form) - changes the title line. */
    private var mode = "run"
    private val dotRun = Color.argb(235, 40, 120, 80)
    private val dotPaused = Color.argb(240, 200, 130, 0)

    private fun dp(v: Int) = (v * svc.resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    fun show(totalRecords: Int, explore: Boolean = false) {
        total = totalRecords; finished = false; mode = if (explore) "explore" else "run"
        if (root != null) { reset(); return }
        val ctx = svc
        panel = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; background = bg(Color.argb(235, 28, 32, 38), 14)
            setPadding(dp(12), dp(8), dp(12), dp(10))
            layoutParams = FrameLayout.LayoutParams(dp(260), FrameLayout.LayoutParams.WRAP_CONTENT)
        }
        val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        title = TextView(ctx).apply {
            setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val collapse = TextView(ctx).apply {
            text = "–"; setTextColor(Color.WHITE); textSize = 20f; setPadding(dp(12), 0, dp(4), 0)
            contentDescription = "Collapse"; setOnClickListener { setCollapsed(true) }
        }
        header.addView(title); header.addView(collapse)
        val tag = TextView(ctx).apply { text = "TEST DATA · DRAFTS ONLY"; setTextColor(Color.rgb(255, 196, 0)); textSize = 10f; typeface = Typeface.DEFAULT_BOLD }
        status = TextView(ctx).apply { setTextColor(Color.rgb(220, 226, 232)); textSize = 13f; maxLines = 3; setPadding(0, dp(6), 0, dp(8)) }
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(label: String, color: Int) = Button(ctx).apply {
            text = label; isAllCaps = false; textSize = 13f; setTextColor(Color.WHITE); background = bg(color, 8)
            minHeight = dp(36); minimumHeight = dp(36)
            layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(6) }
        }
        pauseBtn = btn("Pause", Color.rgb(60, 110, 190)).apply {
            setOnClickListener {
                if (finished) return@setOnClickListener
                val p = onPauseToggle()
                text = if (p) "Continue" else "Pause"
                background = bg(if (p) Color.rgb(40, 140, 80) else Color.rgb(60, 110, 190), 8)
                panel.background = bg(if (p) Color.argb(240, 120, 80, 0) else Color.argb(235, 28, 32, 38), 14)
                status.text = if (p) "PAUSED - the agent will not tap anything. Fix the screen by hand if needed, then tap Continue." else "Continuing…"
                dotColor(p)
            }
        }
        stopBtn = btn("Stop", Color.rgb(190, 60, 60)).apply {
            setOnClickListener { if (finished) onClose() else { onStop(); status.text = "Stopping…"; isEnabled = false } }
        }
        row.addView(pauseBtn); row.addView(stopBtn)
        panel.addView(header); panel.addView(tag); panel.addView(status); panel.addView(row)

        dot = TextView(ctx).apply {
            gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 11f; typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(dotRun) }
            layoutParams = FrameLayout.LayoutParams(dp(54), dp(54)); visibility = View.GONE
        }
        root = FrameLayout(ctx).apply { addView(panel); addView(dot) }
        draggable(header) { }
        draggable(title) { }
        draggable(dot) { setCollapsed(false) }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            // KEEP_SCREEN_ON: the phone must not lock in the middle of a long batch
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(90) }
        wm.addView(root, params)
        reset()
    }

    /** Same bubble, used while you fill a form by hand and the app saves each screen. */
    fun showRecording() {
        show(0); mode = "record"
        title.text = "Recording screens"; status.text = "Fill the form by hand. Each new screen is saved."
        pauseBtn.visibility = View.GONE; stopBtn.text = "Stop recording"; dot.text = "REC"
    }

    private fun reset() {
        status.maxLines = 3
        pauseBtn.visibility = View.VISIBLE; panel.background = bg(Color.argb(235, 28, 32, 38), 14)
        pauseBtn.background = bg(Color.rgb(60, 110, 190), 8)
        title.text = if (mode == "explore") "View form" else "Kobo Test Agent"; status.text = "Starting…"; pauseBtn.text = "Pause"; pauseBtn.isEnabled = true
        stopBtn.text = "Stop"; stopBtn.isEnabled = true; dot.text = if (mode == "explore") "0" else "0/$total"; dotColor(false); setCollapsed(false)
        root?.visibility = View.VISIBLE
    }

    fun update(record: Int, done: Int, total: Int, text: String, paused: Boolean) {
        if (root == null) return
        if (!paused && pauseBtn.text.toString() == "Continue") {   // back to running after Continue
            pauseBtn.text = "Pause"; pauseBtn.background = bg(Color.rgb(60, 110, 190), 8); panel.background = bg(Color.argb(235, 28, 32, 38), 14)
        }
        title.text = when {
            mode == "explore" -> "View form  ·  pass $record/$total  ·  $done screens"
            mode == "record" || total == 0 -> "Recording screens · $done saved"
            record > 0 -> "Record $record  ·  $done/$total saved"
            else -> "Kobo Test Agent"
        }
        if (!paused) status.text = text
        dot.text = if (mode == "explore") "P$record" else if (total == 0) "$done" else "$done/$total"
        dotColor(paused)
    }

    fun finished(msg: String) {
        if (root == null) return
        finished = true; title.text = if (mode == "explore") "View form finished" else "Run finished"; status.text = msg
        status.maxLines = 6; dotColor(false); root?.visibility = View.VISIBLE
        pauseBtn.visibility = View.GONE; panel.background = bg(Color.argb(235, 28, 32, 38), 14)
        stopBtn.text = "Close"; stopBtn.isEnabled = true; dot.text = "✓"
    }

    /** The agent paused itself and needs the person to answer this screen. */
    fun ask(record: Int, done: Int, total: Int, text: String) {
        if (root == null) return
        setCollapsed(false)
        title.text = "Record $record  ·  needs you"
        status.text = text
        pauseBtn.text = "Continue"; pauseBtn.background = bg(Color.rgb(40, 140, 80), 8)
        panel.background = bg(Color.argb(240, 120, 80, 0), 14)
        dot.text = "$done/$total"; dotColor(true)
        try { (svc.getSystemService(android.os.Vibrator::class.java))?.vibrate(android.os.VibrationEffect.createOneShot(250, 180)) } catch (_: Exception) {}
    }

    /** Open the full panel (Pause / Continue / Stop), e.g. from the green shortcut button or the dot. */
    fun expand() { if (root != null) setCollapsed(false) }

    /** Hide the bubble for a moment (View form screenshots are taken without it). */
    fun setHidden(h: Boolean) { root?.visibility = if (h) View.INVISIBLE else View.VISIBLE }

    /** The collapsed dot turns amber while paused / waiting for you, green while working. */
    private fun dotColor(paused: Boolean) {
        if (root == null) return
        (dot.background as? GradientDrawable)?.setColor(if (paused) dotPaused else dotRun)
    }

    fun hide() { root?.let { try { wm.removeView(it) } catch (_: Exception) {} }; root = null }

    private fun setCollapsed(c: Boolean) {
        panel.visibility = if (c) View.GONE else View.VISIBLE
        dot.visibility = if (c) View.VISIBLE else View.GONE
    }

    /** Drag the bubble by this view; a short tap runs onTap. */
    @SuppressLint("ClickableViewAccessibility")
    private fun draggable(v: View, onTap: () -> Unit) {
        val slop = ViewConfiguration.get(svc).scaledTouchSlop
        var sx = 0f; var sy = 0f; var px = 0; var py = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; px = params.x; py = params.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) { params.x = px + dx.toInt(); params.y = py + dy.toInt(); root?.let { wm.updateViewLayout(it, params) } }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) onTap(); true }
                else -> false
            }
        }
    }
}
