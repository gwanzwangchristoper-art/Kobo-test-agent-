package com.surveytest.agent.core

import java.io.InputStream
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Element

/** Test records (one map per household) plus the per-appliance repeat rows. */
class Dataset(val records: List<Rec>, val appliances: List<Rec>, val source: String) {
    private val byId = records.associateBy { recordId(it) }
    fun record(id: Int): Rec? = byId[id]
    fun appliancesFor(id: Int): List<Rec> = appliances.filter { recordId(it) == id }
    fun ids(): List<Int> = records.mapNotNull { recordId(it) }.sorted()

    fun toJson(): String = Json.write(mapOf("source" to source, "records" to records, "appliances" to appliances), pretty = false)

    companion object {
        fun recordId(r: Rec): Int? = fmt(r["Record"] ?: "").toIntOrNull()

        fun fromJson(s: String): Dataset {
            val m = Json.parse(s) as Map<*, *>
            fun rows(k: String) = (m[k] as? List<*> ?: emptyList<Any>()).map { r -> (r as Map<*, *>).entries.associate { it.key.toString() to fmt(it.value) } }
            return Dataset(rows("records"), rows("appliances"), m["source"]?.toString() ?: "")
        }

        // ---------------- CSV
        fun parseCsv(text: String): List<Rec> {
            val rows = ArrayList<List<String>>(); var row = ArrayList<String>(); val cell = StringBuilder(); var q = false; var i = 0
            val t = text.removePrefix("﻿")
            // Excel saves CSV with ';' (or tabs) in some countries: use the separator the header line has most of
            val head0 = t.substringBefore('\n')
            val delim = listOf(',', ';', '\t').maxByOrNull { c -> head0.count { it == c } }?.takeIf { c -> head0.count { it == c } > 0 } ?: ','
            while (i < t.length) {
                val c = t[i]
                if (q) {
                    if (c == '"') { if (t.getOrNull(i + 1) == '"') { cell.append('"'); i++ } else q = false } else cell.append(c)
                } else when (c) {
                    '"' -> q = true
                    delim -> { row.add(cell.toString()); cell.clear() }
                    '\r' -> {}
                    '\n' -> { row.add(cell.toString()); cell.clear(); rows.add(row); row = ArrayList() }
                    else -> cell.append(c)
                }
                i++
            }
            if (cell.isNotEmpty() || row.isNotEmpty()) { row.add(cell.toString()); rows.add(row) }
            if (rows.isEmpty()) return emptyList()
            val head = rows[0].map { it.trim() }
            return rows.drop(1).filter { r -> r.any { it.isNotBlank() } }.map { r -> head.indices.associate { head[it] to fmt(r.getOrElse(it) { "" }.trim()) } }
        }

        // ---------------- XLSX (read with the built-in zip + XML parser)
        fun readXlsx(input: InputStream): Map<String, List<Rec>> {
            val files = HashMap<String, ByteArray>()
            ZipInputStream(input).use { z ->
                while (true) { val e = z.nextEntry ?: break; if (!e.isDirectory) files[e.name] = z.readBytes() }
            }
            val f = DocumentBuilderFactory.newInstance().apply { isNamespaceAware = false }
            fun doc(name: String) = files[name]?.let { f.newDocumentBuilder().parse(it.inputStream()) }
            val shared = ArrayList<String>()
            doc("xl/sharedStrings.xml")?.getElementsByTagName("si")?.let { l ->
                for (k in 0 until l.length) {
                    val ts = (l.item(k) as Element).getElementsByTagName("t")
                    shared.add((0 until ts.length).joinToString("") { ts.item(it).textContent })
                }
            }
            val rels = HashMap<String, String>()
            doc("xl/_rels/workbook.xml.rels")?.getElementsByTagName("Relationship")?.let { l ->
                for (k in 0 until l.length) { val e = l.item(k) as Element; rels[e.getAttribute("Id")] = e.getAttribute("Target") }
            }
            val out = LinkedHashMap<String, List<Rec>>()
            val sheets = doc("xl/workbook.xml")?.getElementsByTagName("sheet") ?: return out
            for (k in 0 until sheets.length) {
                val e = sheets.item(k) as Element
                var target = rels[e.getAttribute("r:id")] ?: continue
                target = target.removePrefix("/").let { if (it.startsWith("xl/")) it else "xl/$it" }
                val sd = doc(target) ?: continue
                val grid = ArrayList<Map<Int, String>>()
                val rowsEl = sd.getElementsByTagName("row")
                for (r in 0 until rowsEl.length) {
                    val cells = (rowsEl.item(r) as Element).getElementsByTagName("c"); val m = HashMap<Int, String>()
                    for (c in 0 until cells.length) {
                        val ce = cells.item(c) as Element
                        val col = colIndex(ce.getAttribute("r"))
                        val type = ce.getAttribute("t")
                        val v = when (type) {
                            "s" -> ce.getElementsByTagName("v").item(0)?.textContent?.toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                            "inlineStr" -> ce.getElementsByTagName("t").let { ts -> (0 until ts.length).joinToString("") { ts.item(it).textContent } }
                            else -> ce.getElementsByTagName("v").item(0)?.textContent ?: ""
                        }
                        m[col] = fmt(v)
                    }
                    grid.add(m)
                }
                if (grid.isEmpty()) continue
                val head = grid[0]; val maxCol = head.keys.maxOrNull() ?: continue
                out[e.getAttribute("name")] = grid.drop(1).filter { it.values.any { v -> v.isNotBlank() } }
                    .map { r -> (0..maxCol).filter { head[it] != null }.associate { head[it]!! to (r[it] ?: "") } }
            }
            return out
        }

        private fun colIndex(ref: String): Int {
            var n = 0; for (ch in ref) { if (!ch.isLetter()) break; n = n * 26 + (ch.uppercaseChar() - 'A' + 1) }
            return n - 1
        }

        /** Build a dataset from an imported file. Accepts .xlsx (Responses + C1_Appliances sheets) or .csv. */
        /** Tidy column names (spaces, "record" in any case) and number the rows when the file has no Record column. */
        fun tidy(rows: List<Rec>, numberIfMissing: Boolean): Pair<List<Rec>, Boolean> {
            val fixed = rows.map { r -> LinkedHashMap<String, String>().apply {
                for ((k, v) in r) { val key = k.trim().let { if (it.equals("record", ignoreCase = true)) "Record" else it }; if (key.isNotEmpty()) put(key, v) }
            } }
            if (!numberIfMissing || fixed.isEmpty() || fixed.any { recordId(it) != null }) return fixed to false
            return fixed.mapIndexed { i, r -> LinkedHashMap<String, String>().apply { put("Record", (i + 1).toString()); putAll(r) } } to true
        }

        private fun note(rows: List<Rec>, numbered: Boolean): String {
            val ids = rows.mapNotNull { recordId(it) }
            val dup = ids.groupBy { it }.filter { it.value.size > 1 }.keys
            return (if (numbered) " Your file has no 'Record' column, so the rows were numbered 1-${rows.size}." else "") +
                (if (ids.size < rows.size) " ${rows.size - ids.size} row(s) have no record number and will be skipped." else "") +
                (if (dup.isNotEmpty()) " Record number(s) used twice (only the last row is used): ${dup.take(5).joinToString()}." else "")
        }

        /** Build a dataset from an imported file. Accepts .xlsx (Responses + C1_Appliances sheets) or .csv. */
        fun import(name: String, bytes: ByteArray, current: Dataset?): Pair<Dataset, String> {
            if (bytes.isEmpty()) throw IllegalArgumentException("The file is empty")
            if (name.lowercase().endsWith(".xls") && !name.lowercase().endsWith(".xlsx") && !(bytes.size > 2 && bytes[0] == 'P'.code.toByte()))
                throw IllegalArgumentException("Old Excel (.xls) files cannot be read. In Excel use Save As > .xlsx (or .csv) and import that.")
            if (name.lowercase().endsWith(".xlsx") || (bytes.size > 2 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte())) {
                val sheets = readXlsx(bytes.inputStream()).mapValues { tidy(it.value, false).first }
                fun named(n: String) = sheets.entries.firstOrNull { it.key.trim().equals(n, ignoreCase = true) }?.value
                fun isApps(rows: List<Rec>) = rows.firstOrNull()?.containsKey("Appliance") == true
                val apps = named("C1_Appliances") ?: sheets.values.firstOrNull { isApps(it) } ?: emptyList()
                val raw = named("Responses") ?: sheets.values.firstOrNull { rows -> rows.firstOrNull()?.containsKey("Record") == true && !isApps(rows) }
                    ?: sheets.values.firstOrNull { it.isNotEmpty() && !isApps(it) }
                    ?: throw IllegalArgumentException("No sheet with data found in $name")
                val (resp, numbered) = tidy(raw, true)
                return Dataset(resp, apps, "imported $name") to "Imported ${resp.size} records and ${apps.size} appliance rows from $name." + note(resp, numbered)
            }
            val all = parseCsv(String(bytes, Charsets.UTF_8))
            if (all.isEmpty()) throw IllegalArgumentException("The CSV has no rows under the header line")
            if (all[0].keys.any { it.trim() == "Appliance" }) {
                val (rows, _) = tidy(all, false)
                if (!rows[0].containsKey("Record")) throw IllegalArgumentException("The appliances CSV needs a 'Record' column (which household each row belongs to)")
                val base = current ?: throw IllegalArgumentException("Import the responses first, then the appliances CSV")
                return Dataset(base.records, rows, base.source + " + $name") to "Added ${rows.size} appliance rows from $name"
            }
            val (rows, numbered) = tidy(all, true)
            return Dataset(rows, emptyList(), "imported $name") to
                "Imported ${rows.size} records from $name." + note(rows, numbered) + " Now import the C1_Appliances CSV too, if your form has the appliance questions."
        }
    }
}
