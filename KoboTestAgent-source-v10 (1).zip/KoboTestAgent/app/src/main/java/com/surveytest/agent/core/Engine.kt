package com.surveytest.agent.core

/** What the engine needs from the phone. The Android app implements this with the accessibility service. */
interface Device {
    fun root(): UiNode?
    fun click(n: UiNode): Boolean
    fun setText(n: UiNode, text: String): Boolean
    fun scrollForward(root: UiNode): Boolean
    fun back()
    fun launch(pkg: String): Boolean
    fun sleep(ms: Long)
    fun snapshot(name: String, root: UiNode?)
    /** Is the on-screen keyboard open? (it can hide KoboCollect's Next button) */
    fun keyboardShown(): Boolean = false
    /** Swipe right-to-left, KoboCollect's gesture for "next screen". */
    fun swipeNext(): Boolean = false
    /** Package of the app in front ("" if unknown). Used so the agent never taps inside the wrong app. */
    fun currentPackage(): String = ""
    /** Save this screen (screenshot + text) into a folder and wait until it is written. Used by "View form". */
    fun capture(folder: String, name: String, root: UiNode?, text: String) = snapshot(name, root)
}

/**
 * How long the agent waits. `factor` scales the fixed pauses inside pickers and pop-ups.
 * Super = as fast as the phone allows; Ultra = every wait 7 times shorter than Super.
 * Answers are still read back from the screen before Next at every speed.
 */
class Timing(val poll: Long, val settle: Long, val clickWait: Long, val typeWait: Long, val nextWait: Long, val launchWait: Long,
             val factor: Double = 1.0, val name: String = "") {
    /** A fixed pause scaled to this speed (never below 1 ms, so the phone still gets a turn). */
    fun ms(base: Long): Long = maxOf(1L, (base * factor).toLong())
    companion object {
        val NORMAL = Timing(poll = 100, settle = 150, clickWait = 40, typeWait = 80, nextWait = 150, launchWait = 1200, factor = 1.0, name = "normal")
        val SUPER = Timing(poll = 40, settle = 30, clickWait = 0, typeWait = 20, nextWait = 40, launchWait = 700, factor = 0.5, name = "super")
        /** 7 x Super: every wait divided by 7. */
        val ULTRA = Timing(poll = 6, settle = 4, clickWait = 0, typeWait = 3, nextWait = 6, launchWait = 100, factor = 0.5 / 7, name = "ultra")
    }
}

interface Reporter {
    fun status(record: Int, done: Int, total: Int, text: String)
    fun log(record: Int, kind: String, key: String, value: String, note: String)
    /** The run has paused itself: ask the person to answer the screen and tap Continue. */
    fun askHuman(record: Int, done: Int, total: Int, text: String) = status(record, done, total, text)
    /** Save an answer given by hand as a rule (pattern + value). */
    fun learned(pattern: String, value: String) {}
}

class Control { @Volatile var paused = false; @Volatile var stopped = false }
class StopRequested : RuntimeException("stopped")

class Action(val kind: String, val item: Item, val key: String, val text: String, val auto: Boolean = false)

/** Options a test answer should avoid when choosing on its own. */
private val AVOID = Regex("(?i)\\bother\\b|don.?t know|do not know|not sure|refus|prefer not|not applicable|\\bn/?a\\b|none of|no answer|specify")
private val NUMERIC_LABEL = Regex("(?i)how many|number|\\bngn\\b|amount|\\bage\\b|hours|kwh|cost|price|quantity|total|tariff|fee|\\(w\\)|watts?|years?|months?|days?|0-10|0 to 10")

/** Picks sensible answers for questions that have no rule (or whose data is blank but the form insists). */
class Auto(seed: Long) {
    private val rnd = java.util.Random(seed)
    fun pick(items: List<Item>): Item? {
        if (items.isEmpty()) return null
        val good = items.filter { !AVOID.containsMatchIn(it.text) && norm(it.text) != "none" && norm(it.text) != "no" }
        val pool = good.ifEmpty { items.filter { !AVOID.containsMatchIn(it.text) } }.ifEmpty { items }
        return pool[rnd.nextInt(pool.size)]
    }
    /** A number that fits the question; a different one is tried each time the form rejects it (constraints). */
    fun number(level: Int, label: String = ""): String {
        val l = label.lowercase()
        val tries = when {
            Regex("ngn|naira|amount|cost|price|fee|paid|spend|tariff").containsMatchIn(l) -> listOf("5000", "2000", "10000", "500", "15000", "1000")
            Regex("kwh").containsMatchIn(l) -> listOf("30", "20", "45", "10")
            Regex("hours").containsMatchIn(l) -> listOf("6", "4", "8", "2", "10")
            Regex("\\bage\\b").containsMatchIn(l) -> listOf("35", "28", "45", "52")
            Regex("watt|\\(w\\)|rated").containsMatchIn(l) -> listOf("60", "40", "100", "150")
            Regex("0-10|0 to 10|scale").containsMatchIn(l) -> listOf("7", "8", "6", "9")
            Regex("year").containsMatchIn(l) -> listOf("3", "5", "2", "8")
            Regex("month").containsMatchIn(l) -> listOf("6", "3", "12", "1")
            Regex("how many|number|members|people|persons").containsMatchIn(l) -> listOf("2", "1", "3", "4", "0")
            else -> listOf("1", "2", "0", "5", "10", "3", "20")
        }
        return tries[level % tries.size]
    }

    /** A realistic short answer for a free-text box that has no data column (never a visible placeholder). */
    fun text(label: String): String {
        val l = label.lowercase()
        val pool = when {
            Regex("kind of work|occupation|what work|type of work").containsMatchIn(l) -> listOf("Subsistence crop farming", "Petty trading of foodstuff", "Motorcycle taxi (okada)", "Tailoring from home")
            Regex("generator").containsMatchIn(l) -> listOf("Kept as a backup for outages", "Sold after connecting to the mini-grid", "Stopped using it due to fuel cost")
            Regex("affect|impact").containsMatchIn(l) -> listOf("Work stops when the power goes off", "Fewer operating hours each day", "Goods spoil without cooling")
            Regex("income|livelihood|business|activity").containsMatchIn(l) -> listOf("Petty trading of provisions", "Seasonal farm labour", "Grinding machine operation")
            Regex("need|want|wish|priority").containsMatchIn(l) -> listOf("Power for an irrigation pump", "A cheaper monthly tariff", "Stronger supply for machines")
            Regex("unit|quantity|litre|piece").containsMatchIn(l) -> listOf("20 litres", "10 pieces", "5 litres")
            Regex("reason|why").containsMatchIn(l) -> listOf("Cost is too high", "Supply is not reliable enough", "No other option available")
            Regex("name|village|community|settlement|place|town").containsMatchIn(l) -> listOf("Kilankwa", "Petti", "Kwali")
            else -> listOf("Not applicable", "None", "No further details")
        }
        return pool[rnd.nextInt(pool.size)]
    }
    fun numericField(it: Item, label: String) = it.numeric || NUMERIC_LABEL.containsMatchIn(label)
}

/**
 * Decide the next tap/typing on the visible screen, or null when everything visible is answered.
 * level = how many times Next has failed on this screen; from 1 up, blank required answers are filled automatically.
 */
fun plan(scr: Screen, rules: Rules, rec: Rec, apps: List<Rec>, counts: MutableMap<String, Int>, atEnd: Boolean,
         log: (String, String, String, String) -> Unit, auto: Auto? = null, level: Int = 0,
         memory: MutableMap<String, String> = HashMap(), scrolled: Boolean = false, strict: Boolean = false): Action? {
    for ((fi, f) in scr.fields.withIndex()) {
        var lab = f.lab
        // After scrolling, the top question's title may be off-screen: recognise it by the options seen earlier.
        if ((f.t == "radio" || f.t == "check") && fi == 0 && scrolled && rules.resolve(scr.sub, lab) == null)
            f.items.firstNotNullOfOrNull { memory["opt|" + it.text] }?.let { lab = it }
        if (f.t == "radio" || f.t == "check") f.items.forEach { memory.putIfAbsent("opt|" + it.text, lab) }
        var key = rules.resolve(scr.sub, lab)
        if (key == "@auto") key = null
        if (key != null && key.startsWith("~")) key = key.substring(1).takeIf { rules.valueFor(it, scr.sub, rec, apps).isNotEmpty() }
        if (key == null && auto == null) {
            if (counts.put("unmatched|" + lab, 1) == null) log("UNMATCHED", lab.take(80), "", "no rule and automatic answers are off")
            if (lab.isNotBlank() && f.items.none { it.checked } && (f.t != "edit" || f.items[0].text.isBlank())) counts["needhuman|learn|$lab"] = 1
            continue
        }
        if (key == null && lab.isBlank()) continue   // a question whose title is off-screen: never guess it
        val want = if (key != null) rules.valueFor(key, scr.sub, rec, apps) else ""
        val useAuto = auto != null && (key == null || (want.isEmpty() && level >= 1))
        val name = key ?: ("AUTO: " + lab.take(60))
        if (useAuto) {
            val tag = "auto|${f.t}|$lab|$level"
            if (counts.containsKey(tag)) continue
            when (f.t) {
                "edit" -> {
                    val it = f.items[0]
                    val num = auto!!.numericField(it, lab)
                    val retry = level >= 2 && num && counts.containsKey("autofilled|$lab")
                    if (it.text.isBlank() || retry) {
                        counts[tag] = 1; counts["autofilled|$lab"] = 1
                        return Action("type", it, name, if (num) auto.number(level, lab) else auto.text(lab), auto = true)
                    }
                }
                "date" -> { counts[tag] = 1; return Action("date", f.items[0], name, "2025-06", auto = true) }
                "radio" -> if (f.items.none { it.checked }) { counts[tag] = 1; auto!!.pick(f.items)?.let { return Action("click", it, name, it.text, auto = true) } }
                "check" -> if (f.items.none { it.checked }) { counts[tag] = 1; auto!!.pick(f.items)?.let { return Action("click", it, name, it.text, auto = true) } }
                "spinner" -> if (f.items[0].text.isBlank() || DROPDOWN_TXT.containsMatchIn(f.items[0].text)) {
                    counts[tag] = 1; return Action("dropdown", f.items[0], name, "", auto = true)
                }
            }
            continue
        }
        if (key == null) continue
        when (f.t) {
            "edit" -> {
                val it = f.items[0]; val tag = "$key|edit"
                // typed text is read back: if the box is still empty / different (phone missed it), type again (max 3 tries)
                if (want.isNotEmpty() && !sameValue(it.text, want) && (counts[tag] ?: 0) < 3) {
                    counts[tag] = (counts[tag] ?: 0) + 1; return Action("type", it, key, want)
                }
            }
            "date" -> {
                val tag = "$key|date"
                if (want.isNotEmpty() && (counts[tag] ?: 0) < 1) { counts[tag] = 1; return Action("date", f.items[0], key, want) }
            }
            "spinner" -> {
                val tag = "$key|dropdown"
                if (want.isNotEmpty() && norm(f.items[0].text) != norm(want) && (counts[tag] ?: 0) < 1) {
                    counts[tag] = 1; return Action("dropdown", f.items[0], key, want)
                }
            }
            "radio" -> {
                if (want.isEmpty()) continue
                val hit = matchOption(f.items, want)
                if (hit != null && hit.checked) counts["done|$key"] = 1
                if (hit == null && counts.containsKey("done|$key")) continue   // already chosen, just scrolled out of view
                if (hit == null) {
                    if (atEnd && counts.put("$key|warn", 1) == null) {
                        log("MISMATCH", key, want, "data value is not an option here: " + f.items.take(6).joinToString(" / ") { it.text.take(30) })
                        if (strict && f.items.none { it.checked }) counts["needhuman|mismatch|$lab"] = 1
                    }
                    // not strict: choose the closest sensible option instead of leaving it empty (logged above)
                    if (!strict && auto != null && atEnd && f.items.none { it.checked } && counts.put("$key|autofix", 1) == null) {
                        counts["done|$key"] = 1
                        auto.pick(f.items)?.let { return Action("click", it, key, it.text, auto = true) }
                    }
                    continue
                }
                val tag = "$key|${hit.text}"
                if (!hit.checked && (counts[tag] ?: 0) < 2) { counts[tag] = (counts[tag] ?: 0) + 1; counts["done|$key"] = 1; return Action("click", hit, key, want) }
            }
            "check" -> {
                val wants = want.split(";").map { it.trim() }.filter { it.isNotEmpty() }
                val targets = HashSet<String>()
                for (w in wants) {
                    val hit = matchOption(f.items, w)
                    if (hit != null) counts["seen|$key|$w"] = 1
                    // a long multi-select spreads its options over several scroll positions: only a value never seen is a mismatch
                    if (hit == null) { if (atEnd && !counts.containsKey("seen|$key|$w") && counts.put("$key|$w|warn", 1) == null) log("MISMATCH", key, w, "data value is not an option here") }
                    else targets.add(hit.text)
                }
                if (wants.isEmpty()) f.items.firstOrNull { norm(it.text) == "none" }?.let { targets.add(it.text) }
                for (it in f.items) {
                    val should = it.text in targets; val tag = "$key|${it.text}"
                    if (it.checked != should && (counts[tag] ?: 0) < 2) { counts[tag] = (counts[tag] ?: 0) + 1; return Action("click", it, key, it.text) }
                }
            }
        }
    }
    return null
}

/** Does the text shown in a box already hold the wanted value? ("5,000" = "5000", "8.0" = "8", spacing/case ignored) */
fun sameValue(shown: String, want: String): Boolean {
    if (norm(shown.replace(",", "")) == norm(want.replace(",", ""))) return true
    val a = shown.replace(",", "").trim().toDoubleOrNull(); val b = want.replace(",", "").trim().toDoubleOrNull()
    return a != null && b != null && a == b
}

private val MONTHS = listOf("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")

class Engine(
    private val dev: Device, private val rules: Rules, private val data: Dataset,
    private val rep: Reporter, private val ctl: Control,
    private val delayMs: Long = 300, private val maxSteps: Int = 900, private val dateOrder: String = "dmy",
    autoAnswer: Boolean = true, seed: Long = 7, private val keepGoing: Boolean = true,
    private val t: Timing = Timing.NORMAL, private val strict: Boolean = false,
    private val askWhenStuck: Boolean = false,
) {
    @Volatile private var asking = false
    private var nData = 0; private var nAuto = 0; private var nMismatch = 0
    private val auto: Auto? = if (autoAnswer) Auto(seed) else null
    private var recNo = 0; private var done = 0; private var total = 0

    private fun check() {
        if (ctl.paused && !ctl.stopped) {
            if (!asking) rep.status(recNo, done, total, "PAUSED")
            while (ctl.paused && !ctl.stopped) dev.sleep(150)
            if (!ctl.stopped) rep.status(recNo, done, total, "Continuing…")
        }
        if (ctl.stopped) throw StopRequested()
    }
    /** Sleep that still reacts to Pause/Stop straight away. */
    private fun nap(ms: Long) { var left = ms; while (left > 0) { check(); val s = minOf(left, 100L); dev.sleep(s); left -= s }; check() }
    private fun log(kind: String, key: String, value: String, note: String) {
        when (kind) { "ANSWER" -> nData++; "AUTO" -> nAuto++; "MISMATCH" -> nMismatch++ }
        rep.log(recNo, kind, key, value, note)
    }
    private fun say(text: String) = rep.status(recNo, done, total, text)

    private fun read(): Pair<UiNode?, String> { val r = dev.root(); return r to (r?.signature() ?: "") }

    /** Wait until the screen differs from `before` (real phones lag), then let it settle. */
    private fun waitChange(before: String, timeoutMs: Long = 3000, settleMs: Long = t.settle): UiNode? {
        var waited = 0L; var r: UiNode? = null
        while (waited < timeoutMs) {
            dev.sleep(t.poll); waited += t.poll; check()
            r = dev.root(); if (r != null && r.signature() != before) break
        }
        if (settleMs > 0) dev.sleep(settleMs)
        return dev.root() ?: r
    }

    /** Runs the given record numbers, one new form each, saved as a draft. Returns how many were saved. */
    fun run(ids: List<Int>, formAlreadyOpen: Boolean = false): Int {
        total = ids.size
        var failed = 0; var streak = 0
        try {
            for ((n, id) in ids.withIndex()) {
                recNo = id
                val rec = data.record(id) ?: run { log("ERROR", "", "", "record $id is not in the test data"); return done }
                val apps = data.appliancesFor(id)
                say("Opening a new form…")
                val t0 = System.currentTimeMillis(); nData = 0; nAuto = 0; nMismatch = 0
                val opened = (formAlreadyOpen && n == 0) || openNewForm()
                val ok = opened && runRecord(rec, apps)
                if (!opened) log("ERROR", "", "", "could not open the form '${rules.formName}' - check the form name")
                if (ok) {
                    done++; streak = 0
                    log("INFO", "", "", "record saved as DRAFT in ${(System.currentTimeMillis() - t0) / 1000}s - " +
                        "$nData answers from the data, $nAuto automatic, $nMismatch data values not offered by the form")
                    say("Saved as draft (${(System.currentTimeMillis() - t0) / 1000}s)")
                    continue
                }
                failed++; streak++
                if (!keepGoing || streak >= 3) {
                    say(if (streak >= 3) "Stopped: 3 forms in a row failed - see log" else "Stopped with a problem - see log"); return done
                }
                log("INFO", "", "", "form not saved - discarding it and moving on to the next record")
                say("Form failed - discarding it, moving on")
                recoverToMenu()
            }
            say("Finished: $done saved as drafts" + if (failed > 0) ", $failed failed (see log)" else "")
        } catch (e: StopRequested) {
            log("INFO", "", "", "stopped by user"); say("Stopped. Form left open: press Back > Ignore changes")
        }
        return done
    }

    /** Pause the run on this screen until the person taps Continue; then remember answers to questions that had no rule. */
    private fun askHuman(reason: String, labels: List<String>, learnable: List<String>) {
        log("ASK", labels.joinToString(" | ").take(150), "", "paused for you: $reason")
        asking = true; ctl.paused = true
        rep.askHuman(recNo, done, total, "Please answer this screen yourself ($reason), then tap Continue.")
        try { check() } finally { asking = false }
        if (learnable.isEmpty()) return
        val r = dev.root() ?: return
        for (f in parseScreen(r, rules).fields) {
            if (f.lab !in learnable) continue
            val v = when (f.t) {
                "radio" -> f.items.firstOrNull { it.checked }?.text
                "check" -> f.items.filter { it.checked }.joinToString("; ") { it.text }.ifEmpty { null }
                "edit" -> f.items[0].text.ifBlank { null }
                "spinner" -> f.items[0].text.takeIf { it.isNotBlank() && !DROPDOWN_TXT.containsMatchIn(it) }
                else -> null
            } ?: continue
            val pattern = rules.learn(f.lab, v)
            rep.learned(pattern, v)
            log("LEARNED", f.lab.take(80), v, "your answer is saved as a rule and will be used from now on")
        }
    }

    /** When a screen has no Next button: close the keyboard, swipe, or use "Go to end" in the question list. */
    private fun moveOnWithoutNext(root: UiNode, sig: String, allowGoToEnd: Boolean = true): Boolean {
        fun arrived(r: UiNode?): Boolean = r != null && r.signature() != sig && parseScreen(r, rules).let { it.isEnd || it.fields.isNotEmpty() || it.next != null }
        if (dev.keyboardShown()) {
            log("INFO", "", "", "keyboard was hiding the Next button - closing it"); dev.back()
            val r = waitChange(sig, 1000); if (r != null && parseScreen(r, rules).next != null) return true
        }
        if (dev.swipeNext()) {
            val r = waitChange(sig, 1500)
            if (arrived(r)) { log("INFO", "", "", "no Next button - moved on by swiping"); return true }
        }
        // question list (toolbar icon) -> "Go to end"
        if (!allowGoToEnd) return false
        val list = root.walk().firstOrNull { Regex("(?i)hierarchy|go to|jump|question list|view form").containsMatchIn(it.desc + " " + it.text) && it.top < (root.bottom - root.top) * 0.13 }
        if (list != null) {
            dev.click(list); var r = waitChange(sig, 2000) ?: return false
            val end = r.walk().firstOrNull { Regex("(?i)^(go to end|jump to end|go to the end)$").matches(it.text.trim()) || Regex("(?i)go to end|jump to end").containsMatchIn(it.desc) }
            if (end != null) {
                dev.click(end); r = waitChange(r.signature(), 2500) ?: return false
                if (parseScreen(r, rules).isEnd) { log("INFO", "", "", "no Next button - used 'Go to end'"); return true }
            }
            dev.back(); waitChange(r.signature(), 1500)
        }
        return false
    }

    /** Leave a half-filled form WITHOUT saving it and get back to KoboCollect's main menu. */
    private fun recoverToMenu(): Boolean {
        val discard = setOf("ignore changes", "discard", "discard changes", "don't save", "do not save", "exit without saving", "discard form")
        for (i in 0 until 8) {
            check()
            val r = dev.root() ?: run { dev.sleep(maxOf(50L, t.ms(300))); null } ?: continue
            if (r.walk().any { it.text.trim().equals("Start new form", ignoreCase = true) }) return true
            val d = r.walk().firstOrNull { it.text.trim().lowercase() in discard }
            if (d != null) dev.click(d) else dev.back()
            waitChange(r.signature(), 2000, t.ms(300))
        }
        return false
    }

    private fun handleDialog(scr: Screen): Boolean {
        if (scr.dialog.isEmpty()) return false
        val names = scr.dialog.associateBy { norm(it.text) }
        for (k in listOf("do not add", "don t add", "dont add")) names[k]?.let {
            log("WARN", "repeat dialog", scr.dialogMsg.take(60), "declined 'add another'"); say("Pop-up: declined 'add another'"); dev.click(it.node!!); return true
        }
        for (k in listOf("ok", "close", "dismiss", "continue")) names[k]?.let {
            log("WARN", "dialog", scr.dialogMsg.take(80), "closed with ${it.text}"); say("Pop-up closed: ${scr.dialogMsg.take(40)}"); dev.click(it.node!!); return true
        }
        return false
    }

    private fun saveAsDraft(start: Screen): Boolean {
        var scr = start
        for (i in 0 until 3) {
            val m = scr.markFinal
            if (m != null && m.checked) {
                dev.click(m.node!!); log("INFO", "", "", "unticked 'Mark form as finalized'")
                scr = parseScreen(waitChange(dev.root()?.signature() ?: "", 2000) ?: return false, rules); continue
            }
            break
        }
        if (scr.markFinal?.checked == true) { log("ERROR", "", "", "could not untick 'Mark form as finalized' - NOT saving"); return false }
        val d = scr.saveDraft ?: run { log("ERROR", "", "", "save screen has no draft button (only Finalize) - NOT saving"); return false }
        say("Saving as DRAFT…")
        val before = dev.root()?.signature() ?: ""
        dev.click(d.node!!)
        val after = waitChange(before, 8000)
        if (after != null && parseScreen(after, rules).isEnd) { log("ERROR", "", "", "still on the save screen after tapping draft"); return false }
        log("SAVED", "", d.text, "draft"); return true
    }

    private fun runRecord(rec: Rec, apps: List<Rec>): Boolean {
        var counts = HashMap<String, Int>(); var atEnd = false; var level = 0
        var memory = HashMap<String, String>(); var scrolled = false; var curSub = ""
        fun newScreen() { counts = HashMap(); atEnd = false; level = 0; memory = HashMap(); scrolled = false; curSub = "" }
        var away = 0L
        for (step in 0 until maxSteps) {
            check()
            if (!inKobo()) {
                // another app is in front (a call, a notification opened...): never tap inside it; wait up to 20 s
                if (away == 0L) say("Waiting for KoboCollect to be in front…")
                dev.sleep(200); away += 200
                if (away >= 20000) { log("ERROR", "", "", "KoboCollect is no longer in front - stopped this form"); return false }
                continue
            }
            away = 0L
            val (root, sig) = read()
            if (root == null) { dev.sleep(maxOf(50L, t.ms(300))); continue }
            val scr = parseScreen(root, rules)
            if (handleDialog(scr)) { waitChange(sig, 2000); continue }
            // the section title scrolls away on long screens: keep using the one seen at the top
            if (scr.sub.isEmpty() && curSub.isNotEmpty()) scr.sub = curSub else if (scr.sub.isNotEmpty()) curSub = scr.sub
            if (scr.isEnd) return saveAsDraft(scr)
            val act = plan(scr, rules, rec, apps, counts, atEnd, ::log, auto, level, memory, scrolled, strict)
            if (act != null) {
                say((if (act.auto) "Auto: " else "") + "${act.key} → ${act.text}".take(120))
                var ok = true
                when (act.kind) {
                    "click" -> { dev.click(act.item.node!!); if (act.item.t == "check") waitChange(sig, 1200, maxOf(t.clickWait, 30)) else waitChange(sig, 700, t.clickWait) }
                    "type" -> { dev.setText(act.item.node!!, act.text); if (t.typeWait > 0) dev.sleep(t.typeWait) }
                    "date" -> { ok = enterDate(act); if (!ok) log("WARN", act.key, act.text, "date entry failed - check the picker") }
                    "dropdown" -> { ok = enterDropdown(act); if (!ok) log("WARN", act.key, act.text, "dropdown option not found") }
                }
                if (ok) log(if (act.auto) "AUTO" else "ANSWER", act.key, act.text, if (act.auto) "no rule/data - chosen by question type" else "")
                if (delayMs > 0) nap(delayMs); continue
            }
            if (scr.scrollable && !atEnd) {
                val moved = dev.scrollForward(root)
                if (moved) scrolled = true
                val after = if (moved) waitChange(sig, 800, 100) else root
                if (!moved || after == null || parseScreen(after, rules).layoutSig == scr.layoutSig) atEnd = true
                continue
            }
            val needs = counts.keys.filter { it.startsWith("needhuman|") && !counts.containsKey("asked|$it") }
            if (askWhenStuck && needs.isNotEmpty()) {
                needs.forEach { counts["asked|$it"] = 1 }
                val learnable = needs.filter { it.startsWith("needhuman|learn|") }.map { it.removePrefix("needhuman|learn|") }
                askHuman(if (learnable.isNotEmpty()) "no answer in your data" else "your data value is not offered here",
                    needs.map { it.substringAfter('|').substringAfter('|') }, learnable)
                continue
            }
            val nx = scr.next
            if (nx == null) {
                // e.g. the last question (E2 photo): no Next button. Find another way forward to the save screen.
                if (moveOnWithoutNext(root, sig)) { newScreen(); continue }
                dev.snapshot("r${recNo}_nonext", root); log("ERROR", scr.sid.take(60), "", "no Next button and not a save screen"); return false
            }
            say("Next ›  ${scr.sub.ifEmpty { scr.texts.firstOrNull() ?: "" }}".take(120))
            dev.click(nx.node!!)
            var afterRoot = waitChange(sig, 3000, t.nextWait); if (delayMs > 0) nap(delayMs)
            var after = afterRoot?.let { parseScreen(it, rules) }
            if (after != null && after.sid == scr.sid && !after.isEnd && after.dialog.isEmpty() && afterRoot != null) {
                // the screen may only have shifted (keyboard closing, page sliding in): look once more before calling it stuck
                val again = waitChange(afterRoot.signature(), 900, t.nextWait)
                if (again != null) { afterRoot = again; after = parseScreen(again, rules) }
            }
            if (after != null && after.sid == scr.sid && !after.isEnd && after.dialog.isEmpty()) {
                // The form would not move on: a required answer is missing or a value broke a rule. Try again, filling more.
                level++
                if (level == 1) dev.snapshot("r${recNo}_retry", afterRoot)
                // the keyboard can cover the box or the Next button: close it (only when it is really open)
                if (dev.keyboardShown()) { dev.back(); waitChange(afterRoot?.signature() ?: sig, 800, t.settle) }
                // the LAST question (E3 note): never throw away a finished form because of it - go to the save screen
                val isLast = rules.isLastQuestion(after.fields.map { it.lab } + after.texts)
                if (isLast && level >= 3) {
                    val r = dev.root()
                    if (r != null && moveOnWithoutNext(r, r.signature(), allowGoToEnd = true)) {
                        log("WARN", scr.sid.take(60), "", "last question would not accept Next - went to the save screen; check this answer in the draft")
                        newScreen(); continue
                    }
                }
                if (askWhenStuck && (auto == null || level >= 3) && level <= 6 && afterRoot != null) {
                    // the form will not move on: let the person answer what is missing, then try Next again
                    val blanks = parseScreen(afterRoot, rules).fields.filter { f -> f.lab.isNotBlank() && f.items.none { it.checked } && (f.t != "edit" || f.items[0].text.isBlank()) }.map { it.lab }
                    askHuman("the form will not move on", blanks, blanks.filter { rules.resolve(curSub, it) == null })
                    continue
                }
                if (auto == null || level > 5) {
                    dev.snapshot("r${recNo}_stuck", afterRoot)
                    log("ERROR", scr.sid.take(60), "", "stuck (required question not answered?) - snapshot saved"); return false
                }
                log("WARN", scr.sid.take(60), "", "form did not move on - retry $level, filling blanks / other values")
                say("Retrying this screen ($level)…")
                counts = HashMap(counts.filterKeys { it.startsWith("autofilled|") }); atEnd = false
            } else newScreen()
        }
        log("ERROR", "", "", "too many steps"); return false
    }

    /**
     * Dropdown (spinner / "minimal" select): open it, pick the wanted option (or a sensible one), close it.
     * `chooser` (View form) picks from the options on screen; every option seen is added to `seen`.
     */
    private fun enterDropdown(act: Action, chooser: ((List<Item>) -> Item?)? = null, seen: MutableList<String>? = null): Boolean {
        val before = dev.root()?.signature() ?: ""
        dev.click(act.item.node!!)
        var root = waitChange(before, 3000) ?: return false
        if (root.signature() == before) { log("WARN", act.key, act.text, "the dropdown did not open"); return false }
        val all = ArrayList<Item>()
        for (page in 0 until 12) {
            val opts = root.walk().filter {
                it.text.isNotBlank() && it.text.trim() != act.item.text.trim() && !it.id.endsWith("alertTitle") && !it.id.endsWith("title") &&
                    (it.cls.endsWith("CheckedTextView") || it.cls.endsWith("TextView") || it.cls.endsWith("RadioButton") || it.cls.endsWith("CheckBox")) &&
                    it.text.length < 120
            }.map { Item("opt", it.text.trim(), it) }.toList()
            opts.forEach { o -> if (all.none { it.text == o.text }) all.add(o) }
            seen?.let { s -> opts.forEach { o -> if (o.text !in s) s.add(o.text) } }
            val target = when {
                chooser != null -> chooser(opts)
                act.text.isEmpty() -> auto?.pick(opts)
                else -> matchOption(opts, act.text)
            }
            if (target != null) {
                val sig = root.signature()
                dev.click(target.node!!)
                // wait for the list to close instead of a fixed pause (safe at every speed)
                val after = waitChange(sig, 1500, t.settle)
                after?.walk()?.firstOrNull { it.cls.endsWith("Button") && it.text.trim().uppercase() in setOf("OK", "DONE") }?.let {
                    val s2 = after.signature(); dev.click(it); waitChange(s2, 1500, t.settle)
                }
                return true
            }
            if (!dev.scrollForward(root)) break
            val moved = waitChange(root.signature(), 1200) ?: break
            if (moved.signature() == root.signature()) break
            root = moved
        }
        dev.back(); waitChange(root.signature(), 1500, t.settle); return false
    }

    private fun clickText(root: UiNode, texts: List<String>): Boolean {
        for (t in texts) for (n in root.walk()) if (n.text.isNotEmpty() && n.text.contains(t, ignoreCase = true)) { dev.click(n); return true }
        return false
    }

    /** True when KoboCollect is the app in front (or the phone cannot tell). Never tap inside another app. */
    private fun inKobo(): Boolean { val p = dev.currentPackage(); return p.isEmpty() || p == rules.packageName }

    private fun openNewForm(): Boolean {
        dev.launch(rules.packageName); nap(t.launchWait)
        // wait for KoboCollect to come to the front (at high speed it may still be loading): up to 6 s
        var waited = 0L
        while (!inKobo() && waited < 6000) { dev.sleep(50); waited += 50; check() }
        if (!inKobo()) { log("ERROR", "", "", "KoboCollect did not open (another app is in front)"); return false }
        var started = false; var misses = 0
        for (i in 0 until 14) {
            check()
            val (root, sig) = read()
            if (root == null || !inKobo()) { dev.sleep(maxOf(50L, t.ms(300))); continue }
            val scr = parseScreen(root, rules)
            if (scr.next != null || scr.isEnd) {
                if (started) return true
                // a form left open from before: discard it, then start a fresh one
                log("INFO", "", "", "a form was already open - leaving it without saving")
                if (!recoverToMenu()) return false
                continue
            }
            if (clickText(root, listOf(rules.formName)) || clickText(root, listOf("Start new form", "Fill Blank Form", "Fill blank form"))) { started = true; misses = 0 }
            else if (++misses >= 2) { dev.back(); misses = 0 }   // the screen may still be loading: wait once before going back
            waitChange(sig, 3000, maxOf(t.settle, t.ms(300)))
        }
        return false
    }

    /** Calendar pickers (switch to typing) and scroll-wheel pickers. */
    private fun enterDate(act: Action): Boolean {
        val m0 = Regex("(\\d{4})-(\\d{2})").find(act.text) ?: return false
        val (y, m) = m0.destructured
        val before = dev.root()?.signature() ?: ""
        dev.click(act.item.node!!)
        var root = waitChange(before, 3000) ?: return false
        fun okButton(r: UiNode) = r.walk().firstOrNull { it.text.trim().uppercase() in setOf("OK", "SET", "DONE") }
        val wheels = root.walk().filter { it.id.endsWith("numberpicker_input") }.toList()
        if (wheels.isNotEmpty()) {
            val texts = wheels.map { it.text.trim().lowercase() }
            val want = HashMap<Int, String>()
            val nums = texts.indices.filter { Regex("\\d{1,2}").matches(texts[it]) }
            texts.forEachIndexed { k, t ->
                if (Regex("\\d{4}").matches(t)) want[k] = y
                else if (t.take(3) in MONTHS) want[k] = MONTHS[m.toInt() - 1].replaceFirstChar { it.uppercase() }
            }
            val hasName = texts.any { it.take(3) in MONTHS }
            if (hasName) nums.forEach { want[it] = "15" }
            else if (nums.size == 1) want[nums[0]] = m.toInt().toString()
            else if (nums.size == 2) {
                val (day, mon) = if (dateOrder == "dmy") nums[0] to nums[1] else nums[1] to nums[0]
                want[day] = "15"; want[mon] = m.toInt().toString()
            }
            for ((k, v) in want) if (texts[k] != v.lowercase()) { dev.setText(wheels[k], v); dev.sleep(t.ms(300)) }
            root = dev.root() ?: return false
            okButton(root)?.let { dev.click(it); dev.sleep(t.ms(600)); return true }
            dev.back(); return false
        }
        root.walk().firstOrNull { it.desc.contains("text input", ignoreCase = true) }?.let {
            dev.click(it); root = waitChange(root.signature(), 2000) ?: root
        }
        val ed = root.walk().firstOrNull { it.cls.endsWith("EditText") } ?: run { dev.back(); return false }
        val hint = ed.text.lowercase()
        val s = if (hint.startsWith("dd") || (!hint.startsWith("mm") && dateOrder == "dmy")) "15/$m/$y" else "$m/15/$y"
        dev.setText(ed, s); dev.sleep(t.ms(300))
        root = dev.root() ?: return false
        okButton(root)?.let { dev.click(it); dev.sleep(t.ms(600)); return true }
        dev.back(); return false
    }
    // =====================================================================================================
    // "View form": click through every route of the form, record every screen, never save anything.
    // =====================================================================================================

    /** Options to leave until last when opening branches (they still get tried: they often open "specify" questions). */
    private val LATER = Regex("(?i)\\bother\\b|don.?t know|do not know|not sure|refus|prefer not|not applicable|\\bn/?a\\b")
    /** Multi-select options that usually cannot be combined with others. */
    private val ALONE = Regex("(?i)^(none|none of (the|these).*|no one|nothing|don.?t know|do not know|refused?|prefer not.*|not applicable)$")

    /**
     * Explore the form in up to `maxPasses` passes. Each pass opens a new form, answers every question with an option
     * not tried before (main path otherwise), goes to the save screen, and leaves WITHOUT saving.
     * Stops early when no new screen appears and every option of every short list has been tried.
     */
    fun explore(maxPasses: Int, map: FormMap, folder: String = "screens"): FormMap {
        val ex = auto ?: Auto(7)
        total = maxPasses
        var quiet = 0
        try {
            for (pass in 1..maxPasses) {
                recNo = pass; done = map.screens.size
                val before = map.screens.size; val triedBefore = map.triedCount()
                val route = MapRoute(pass); map.routes.add(route)
                say("View form: pass $pass of up to $maxPasses - opening a new form…")
                val t0 = System.currentTimeMillis()
                if (!openNewForm()) {
                    route.end = "could not open the form '${rules.formName}'"; log("ERROR", "", "", route.end + " - check the form name")
                    map.finishedReason = route.end; break
                }
                explorePass(pass, route, map, ex, folder)
                route.seconds = (System.currentTimeMillis() - t0) / 1000
                val newScreens = map.screens.size - before; val newTries = map.triedCount() - triedBefore
                log("INFO", "", "", "View form pass $pass: ${route.steps.size} screens, $newScreens new, $newTries new answers tried - ${route.end}")
                done = map.screens.size
                if (newScreens == 0 && map.untriedShortOptions() == 0) { map.finishedReason = "every option of every short list was tried and no new screen appeared"; break }
                quiet = if (newScreens == 0) quiet + 1 else 0
                if (quiet >= 3) { map.finishedReason = "3 passes in a row found no new screen"; break }
                if (pass == maxPasses) map.finishedReason = "reached the most passes allowed ($maxPasses)"
            }
            say("View form finished: ${map.screens.size} screens, ${map.questionCount()} questions")
        } catch (e: StopRequested) {
            map.finishedReason = "stopped by you after ${map.routes.size} pass(es)"
            log("INFO", "", "", "View form stopped by user"); say("Stopped. Form left open: press Back > Ignore changes")
        }
        return map
    }

    /** Pick an option for this question: one never tried first (usual ones before Other/Don't know), else the main path. */
    private fun choose(mf: MapField, items: List<Item>): Item? {
        if (items.isEmpty()) return null
        val longList = mf.options.size > 12 || items.size > 12
        if (!(longList && mf.tried.size >= 3)) {
            items.firstOrNull { it.text !in mf.tried && !LATER.containsMatchIn(it.text) }?.let { return it }
            items.firstOrNull { it.text !in mf.tried }?.let { return it }
        }
        // everything tried: follow the option that led furthest (the main path), so later questions get their turn
        val best = items.maxByOrNull { mf.reach[it.text] ?: -1 }
        return if (best != null && (mf.reach[best.text] ?: -1) >= 0) best else (items.firstOrNull { !LATER.containsMatchIn(it.text) } ?: items[0])
    }

    private fun numberFor(mf: MapField, lab: String, used: Set<String>, ex: Auto): String {
        val cands = listOf(ex.number(0, lab), "0", ex.number(1, lab), "1", ex.number(2, lab), ex.number(3, lab), "2", "5", "10").distinct()
        return cands.firstOrNull { it !in mf.tried && it !in used } ?: cands.firstOrNull { it !in used } ?: cands[used.size % cands.size]
    }

    private fun shot(folder: String, ms: MapScreen, root: UiNode, suffix: String = "") {
        val name = ms.id + if (suffix.isNotEmpty()) "_$suffix" else ""
        if (name in ms.shots) return
        ms.shots.add(name)
        try { dev.capture(folder, name, root, "Screen ${ms.id}  ${ms.section}\n\n" + explain(root, rules)) } catch (e: Exception) { log("WARN", "", "", "screenshot failed: $e") }
    }

    private fun explorePass(pass: Int, route: MapRoute, map: FormMap, ex: Auto, folder: String) {
        var level = 0; var atEnd = false; var scrolled = false; var curSub = ""; var cur: MapScreen? = null; var fresh = false
        var counts = HashMap<String, Int>(); var memory = HashMap<String, String>()
        var decided = HashMap<String, Boolean>()          // multi-select: tick or not, per "label|option"
        var answers = LinkedHashMap<String, MutableList<String>>(); var parts = 0
        fun said() = answers.entries.joinToString("; ") { "${it.key} = ${it.value.joinToString(", ")}" }
        val chosen = ArrayList<Pair<MapField, String>>()  // (question, option) per screen index -> reach
        val chosenAt = ArrayList<Int>()
        var from: Pair<Int, String>? = null
        var addedRepeat = 0; var away = 0L
        fun newScreen() { level = 0; atEnd = false; scrolled = false; curSub = ""; cur = null; fresh = false; counts = HashMap(); memory = HashMap(); decided = HashMap(); answers = LinkedHashMap(); parts = 0 }
        fun finishPass(end: String) {
            route.end = end
            // credit each chosen option with how many screens followed it (keeps later passes on the longest path)
            for ((i, c) in chosen.withIndex()) { val after = route.steps.size - chosenAt[i]; if (after > (c.first.reach[c.second] ?: -1)) c.first.reach[c.second] = after }
            say("View form: pass $pass done - leaving WITHOUT saving")
            recoverToMenu()
        }
        for (step in 0 until maxSteps * 2) {
            check()
            if (!inKobo()) {
                dev.sleep(200); away += 200
                if (away >= 20000) { finishPass("KoboCollect left the front"); return }
                continue
            }
            away = 0L
            val (root, sig) = read()
            if (root == null) { dev.sleep(maxOf(50L, t.ms(300))); continue }
            val scr = parseScreen(root, rules)
            if (scr.dialog.isNotEmpty()) {
                val names = scr.dialog.associateBy { norm(it.text) }
                cur?.notes?.add("pop-up: " + scr.dialogMsg.take(120) + "  [" + scr.dialog.joinToString(" / ") { it.text } + "]")
                val add = names["add"]
                val canDecline = names.keys.any { it == "do not add" || it == "don t add" || it == "dont add" }
                if (add != null && canDecline && pass % 2 == 0 && addedRepeat == 0) {
                    addedRepeat++; answers["pop-up 'add another'"] = mutableListOf("Add")
                    log("INFO", "", "", "View form: added one more repeat to see its questions"); dev.click(add.node!!); waitChange(sig, 2000); continue
                }
                if (handleDialog(scr)) { waitChange(sig, 2000); continue }
                dev.back(); waitChange(sig, 1500); continue
            }
            if (scr.sub.isEmpty() && curSub.isNotEmpty()) scr.sub = curSub else if (scr.sub.isNotEmpty()) curSub = scr.sub
            if (scr.isEnd) {
                val (ms, isNew) = map.screen("END", "save screen")
                ms.isEnd = true; ms.passes.add(pass)
                from?.let { map.edge(it.first, it.second, ms.no) }
                if (isNew) shot(folder, ms, root)
                route.steps.add(MapStep(ms.no, ""))
                finishPass("reached the save screen - NOT saved (Ignore changes)"); return
            }
            if (cur == null) {
                val key = scr.sub + "|" + (scr.texts.firstOrNull() ?: scr.fields.firstOrNull()?.lab ?: scr.sid)
                val (ms, isNew) = map.screen(key, scr.crumb.split(">").drop(1).joinToString(" > ") { it.trim() }.ifEmpty { scr.sub })
                cur = ms; fresh = isNew; ms.passes.add(pass)
                from?.let { map.edge(it.first, it.second, ms.no) }; from = null
                say("View form · pass $pass · ${ms.id} ${if (isNew) "NEW" else ""} ${scr.sub.ifEmpty { scr.texts.firstOrNull() ?: "" }}".take(120))
                if (isNew) shot(folder, ms, root)
            }
            val ms = cur!!
            // what is on screen now: questions, their options, the rule column
            for ((fi, f) in scr.fields.withIndex()) {
                var lab = f.lab
                if ((f.t == "radio" || f.t == "check") && fi == 0 && scrolled)
                    f.items.firstNotNullOfOrNull { memory["opt|" + it.text] }?.let { lab = it }
                if (lab.isBlank()) continue
                val mf = ms.field(f.t, lab)
                if (mf.column == null) mf.column = rules.resolve(scr.sub, lab)
                if (f.t == "radio" || f.t == "check") f.items.forEach { if (it.text !in mf.options) mf.options.add(it.text) }
            }
            // ---- answer the next unanswered question
            var act: Action? = null; var actField: MapField? = null
            loop@ for ((fi, f) in scr.fields.withIndex()) {
                var lab = f.lab
                if ((f.t == "radio" || f.t == "check") && fi == 0 && scrolled)
                    f.items.firstNotNullOfOrNull { memory["opt|" + it.text] }?.let { lab = it }
                if (f.t == "radio" || f.t == "check") f.items.forEach { memory.putIfAbsent("opt|" + it.text, lab) }
                if (lab.isBlank()) continue
                val mf = ms.field(f.t, lab)
                when (f.t) {
                    "radio" -> {
                        if (f.items.any { it.checked } || counts.containsKey("did|$lab")) continue@loop
                        val pick = choose(mf, f.items) ?: continue@loop
                        counts["did|$lab"] = 1; act = Action("click", pick, lab, pick.text, auto = true); actField = mf; break@loop
                    }
                    "check" -> {
                        if (!counts.containsKey("decided|$lab")) {
                            counts["decided|$lab"] = 1
                            val untried = f.items.filter { it.text !in mf.tried }
                            val many = untried.filter { !ALONE.matches(norm(it.text)) && !LATER.containsMatchIn(it.text) }
                            val pick = when {
                                level >= 1 -> listOfNotNull(f.items.firstOrNull { it.checked } ?: choose(mf, f.items))   // refused: one option only
                                many.isNotEmpty() -> many
                                untried.isNotEmpty() -> listOf(untried.first())
                                else -> listOfNotNull(choose(mf, f.items))
                            }.map { it.text }.toSet()
                            f.items.forEach { decided["$lab|${it.text}"] = it.text in pick }
                        } else f.items.forEach { decided.putIfAbsent("$lab|${it.text}", false) }   // later scroll part: leave the rest unticked
                        val it = f.items.firstOrNull { i -> i.checked != (decided["$lab|${i.text}"] ?: false) && (counts["clk|$lab|${i.text}"] ?: 0) < 2 }
                        if (it != null) {
                            counts["clk|$lab|${it.text}"] = (counts["clk|$lab|${it.text}"] ?: 0) + 1
                            act = Action("click", it, lab, it.text, auto = true); actField = mf; break@loop
                        }
                    }
                    "edit" -> {
                        val box = f.items[0]
                        val num = ex.numericField(box, lab)
                        val retype = level >= 1 && num && !counts.containsKey("retyped|$lab|$level") && counts.containsKey("typed|$lab")
                        if ((box.text.isBlank() || retype) && (counts["n|$lab"] ?: 0) < 6) {
                            counts["n|$lab"] = (counts["n|$lab"] ?: 0) + 1
                            val used = counts.keys.filter { it.startsWith("used|$lab|") }.map { it.substringAfterLast('|') }.toSet()
                            val v = if (num) numberFor(mf, lab, used, ex) else ex.text(lab)
                            counts["typed|$lab"] = 1; counts["used|$lab|$v"] = 1; if (level >= 1) counts["retyped|$lab|$level"] = 1
                            act = Action("type", box, lab, v, auto = true); actField = mf; break@loop
                        }
                    }
                    "date" -> if (!counts.containsKey("date|$lab")) {
                        counts["date|$lab"] = 1; act = Action("date", f.items[0], lab, "2025-06", auto = true); actField = mf; break@loop
                    }
                    "spinner" -> if ((f.items[0].text.isBlank() || DROPDOWN_TXT.containsMatchIn(f.items[0].text)) && !counts.containsKey("dd|$lab")) {
                        counts["dd|$lab"] = 1; act = Action("dropdown", f.items[0], lab, "", auto = true); actField = mf; break@loop
                    }
                }
            }
            val a = act
            if (a != null) {
                val mf = actField!!
                var value = a.text; var ok = true
                when (a.kind) {
                    "click" -> { dev.click(a.item.node!!); if (a.item.t == "check") waitChange(sig, 1200, maxOf(t.clickWait, 30)) else waitChange(sig, 700, t.clickWait) }
                    "type" -> { dev.setText(a.item.node!!, a.text); if (t.typeWait > 0) dev.sleep(t.typeWait) }
                    "date" -> ok = enterDate(a)
                    "dropdown" -> {
                        var picked: String? = null
                        ok = enterDropdown(a, chooser = { opts -> choose(mf, opts)?.also { picked = it.text } }, seen = mf.options)
                        value = picked ?: ""
                    }
                }
                if (ok && value.isNotEmpty()) {
                    val isTick = a.item.t != "check" || !a.item.checked
                    if (isTick) {
                        mf.tried.add(value)
                        val k = shortLabel(a.key)
                        if (a.item.t == "check") answers.getOrPut(k) { ArrayList() }.add(value) else answers[k] = mutableListOf(value)
                        if (mf.isChoice) { chosen.add(mf to value); chosenAt.add(route.steps.size) }
                    } else answers[shortLabel(a.key)]?.remove(value)
                } else if (!ok) ms.notes.add("could not answer: ${a.key.take(60)} (${a.kind})")
                continue
            }
            if (scr.scrollable && !atEnd) {
                val moved = dev.scrollForward(root)
                if (moved) scrolled = true
                val after = if (moved) waitChange(sig, 800, 100) else root
                if (!moved || after == null || parseScreen(after, rules).layoutSig == scr.layoutSig) atEnd = true
                else if (fresh && parts < 6) { parts++; shot(folder, ms, after, ('a' + parts).toString()) }
                continue
            }
            val nx = scr.next
            if (nx == null) {
                if (moveOnWithoutNext(root, sig)) {
                    route.steps.add(MapStep(ms.no, said())); from = ms.no to said(); newScreen(); continue
                }
                ms.notes.add("no Next button and not the save screen"); route.steps.add(MapStep(ms.no, said()))
                finishPass("stopped at ${ms.id}: no Next button"); return
            }
            dev.click(nx.node!!)
            var afterRoot = waitChange(sig, 3000, t.nextWait)
            var after = afterRoot?.let { parseScreen(it, rules) }
            if (after != null && after.sid == scr.sid && !after.isEnd && after.dialog.isEmpty() && afterRoot != null) {
                val again = waitChange(afterRoot.signature(), 900, t.nextWait)
                if (again != null) { afterRoot = again; after = parseScreen(again, rules) }
            }
            if (after != null && after.sid == scr.sid && !after.isEnd && after.dialog.isEmpty()) {
                level++
                if (level == 1) { ms.notes.add("the form refused Next with the first answers (required question or a limit) - other values were tried"); afterRoot?.let { shot(folder, ms, it, "refused") } }
                if (dev.keyboardShown()) { dev.back(); waitChange(afterRoot?.signature() ?: sig, 800, t.settle) }
                if (level > 4) {
                    ms.notes.add("stuck: the form would not move on in pass $pass")
                    route.steps.add(MapStep(ms.no, said()))
                    finishPass("stuck at ${ms.id} (form would not move on)"); return
                }
                counts = HashMap(counts.filterKeys { it.startsWith("typed|") || it.startsWith("used|") || it.startsWith("n|") || it.startsWith("retyped|") })
                decided = HashMap(); atEnd = false
                continue
            }
            route.steps.add(MapStep(ms.no, said()))
            from = ms.no to said()
            newScreen()
        }
        finishPass("too many steps")
    }

    /** "A1. Sex of respondent" -> "A1"; long labels are cut. */
    private fun shortLabel(lab: String): String = Regex("^([A-Za-z]{1,3}\\d+[a-z]?)[.:)]").find(lab.trim())?.groupValues?.get(1) ?: lab.take(40)

}

/** "1", "1-44", "2,5,7-9" -> record numbers that exist in the data. Throws with a readable message. */
fun parseRange(text: String, available: List<Int>): List<Int> {
    val out = ArrayList<Int>()
    for (part in text.split(",").map { it.trim() }.filter { it.isNotEmpty() }) {
        val ab = part.split("-").map { it.trim() }
        val a = ab[0].toIntOrNull() ?: throw IllegalArgumentException("'$part' is not a number")
        val b = if (ab.size > 1) ab[1].toIntOrNull() ?: throw IllegalArgumentException("'$part' is not a range like 2-44") else a
        if (b < a) throw IllegalArgumentException("'$part': the second number must be bigger")
        out.addAll(a..b)
    }
    if (out.isEmpty()) throw IllegalArgumentException("Type which records to run, e.g. 1 or 1-44")
    val missing = out.filter { it !in available }
    if (missing.isNotEmpty()) throw IllegalArgumentException("Not in the test data: ${missing.take(5).joinToString()}" + if (missing.size > 5) "…" else "")
    return out.distinct()
}
