package com.surveytest.agent.core

/*
 * "View form": what the agent learned by clicking through every route of a form.
 * Plain Kotlin (no Android), so it is tested on a normal computer. The app turns it into a zip:
 *   form_map.txt        every screen, its questions, options, data column, and where each answer leads
 *   routes.txt          each pass through the form, screen by screen, with the answers used
 *   questions.csv       one row per question: column, question, type, options (to build accurate test data)
 *   form_map.json       the same, for tools
 *   screens/S001.jpg …  a screenshot and a text reading of every screen seen
 */

/** One question as seen on a screen. */
class MapField(val type: String, val label: String) {
    /** Options in the order the form shows them. */
    val options = ArrayList<String>()
    /** Options / values the agent has used, over all passes. */
    val tried = LinkedHashSet<String>()
    /** How many screens followed after choosing an option (the longest seen) - used to keep later passes on the main path. */
    val reach = HashMap<String, Int>()
    /** Data column the rules give this question (null = no rule: the data file has nothing for it). */
    var column: String? = null
    val isChoice get() = type == "radio" || type == "check" || type == "spinner"
    fun untried(): List<String> = options.filter { it !in tried }
}

class MapScreen(val no: Int, val key: String, val section: String) {
    val fields = ArrayList<MapField>()
    val passes = sortedSetOf<Int>()
    val shots = ArrayList<String>()
    val notes = LinkedHashSet<String>()
    var isEnd = false
    val id get() = "S%03d".format(no)
    fun field(type: String, label: String): MapField =
        fields.firstOrNull { it.label == label && it.type == type } ?: MapField(type, label).also { fields.add(it) }
}

class MapStep(val screen: Int, val answers: String)
class MapRoute(val pass: Int) { val steps = ArrayList<MapStep>(); var end = ""; var seconds = 0L }
class MapEdge(val from: Int, val answers: String, val to: Int)

class FormMap(val formName: String, val started: String = "") {
    val screens = LinkedHashMap<String, MapScreen>()
    val routes = ArrayList<MapRoute>()
    val edges = ArrayList<MapEdge>()
    private val edgeKeys = HashSet<String>()
    var finishedReason = ""

    /** The screen with this key, and whether it is new. */
    fun screen(key: String, section: String): Pair<MapScreen, Boolean> {
        screens[key]?.let { return it to false }
        val s = MapScreen(screens.size + 1, key, section); screens[key] = s; return s to true
    }
    fun byNo(no: Int): MapScreen? = screens.values.firstOrNull { it.no == no }
    fun edge(from: Int, answers: String, to: Int) {
        val k = "$from|$answers|$to"
        if (from > 0 && edgeKeys.add(k)) edges.add(MapEdge(from, answers, to))
    }
    fun triedCount(): Int = screens.values.sumOf { s -> s.fields.sumOf { it.tried.size } }
    /** Options of short choice lists (2-12 options) never tried yet: when 0, every branch the form offers has been opened. */
    fun untriedShortOptions(): Int = screens.values.sumOf { s -> s.fields.filter { it.isChoice && it.options.size in 2..12 }.sumOf { it.untried().size } }
    fun questionCount(): Int = screens.values.sumOf { it.fields.size }

    // ------------------------------------------------------------------ outputs
    fun formMapText(): String = buildString {
        append("VIEW FORM - ").append(formName).append('\n')
        if (started.isNotEmpty()) append("Explored: ").append(started).append('\n')
        append("Passes through the form: ").append(routes.size).append("   Screens found: ").append(screens.size)
            .append("   Questions: ").append(questionCount()).append('\n')
        if (finishedReason.isNotEmpty()) append("Finished because: ").append(finishedReason).append('\n')
        val untried = untriedShortOptions()
        append(if (untried == 0) "Every option of every short list was tried.\n" else "Options never tried (later passes could open more branches): $untried\n")
        val noRule = screens.values.flatMap { it.fields }.filter { it.column == null }
        if (noRule.isNotEmpty()) append("Questions with NO data column in the rules: ").append(noRule.size).append(" (marked  ** NO RULE **)\n")
        append("Nothing was saved: every pass was left with 'Ignore changes'.\n")
        append("\nKey:  [x] option tried   [ ] option never tried   -> what happened next\n")
        for (s in screens.values) {
            append("\n").append("=".repeat(70)).append('\n')
            append(s.id).append("  ").append(if (s.isEnd) "SAVE SCREEN (end of form)" else s.section.ifEmpty { "(no section title)" }).append('\n')
            append("   seen in pass ").append(s.passes.joinToString(", "))
            if (s.shots.isNotEmpty()) append("   screenshot: ").append(s.shots.joinToString(", ") { "screens/$it.jpg" })
            append('\n')
            for (f in s.fields) {
                append("   - ").append(typeName(f.type)).append(": ").append(f.label.take(160)).append('\n')
                append("        data column: ").append(f.column?.ifEmpty { "(left blank by the rules)" } ?: "** NO RULE **").append('\n')
                if (f.isChoice) for (o in f.options) append("        ").append(if (o in f.tried) "[x] " else "[ ] ").append(o).append('\n')
                else if (f.tried.isNotEmpty()) append("        values used: ").append(f.tried.joinToString(" | ")).append('\n')
            }
            for (n in s.notes) append("   ! ").append(n).append('\n')
            val out = edges.filter { it.from == s.no }
            if (out.isNotEmpty()) {
                append("   leads to:\n")
                for (e in out) append("        ").append(e.answers.ifEmpty { "(no answer needed)" }.take(140)).append("  ->  ")
                    .append(byNo(e.to)?.let { "${it.id} " + if (it.isEnd) "save screen" else it.section.ifEmpty { it.key.substringAfter('|') }.take(60) } ?: "?").append('\n')
            }
        }
    }

    fun routesText(): String = buildString {
        append("ROUTES THROUGH ").append(formName).append(" (each pass = one form, never saved)\n")
        for (r in routes) {
            append("\nPass ").append(r.pass).append(" - ").append(r.steps.size).append(" screens")
            if (r.seconds > 0) append(", ").append(r.seconds).append(" s")
            append(" - ").append(r.end).append('\n')
            for (st in r.steps) {
                val s = byNo(st.screen)
                append("  ").append(s?.id ?: "?").append("  ").append((s?.section ?: "").take(50))
                if (st.answers.isNotEmpty()) append("  |  ").append(st.answers.take(220))
                append('\n')
            }
        }
    }

    /** One row per question: what a test-data file needs to answer this form exactly. */
    fun questionsCsv(): String = buildString {
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        append("screen,section,question,type,data_column,options,options_tried,options_never_tried\n")
        for (s in screens.values) for (f in s.fields) {
            append(listOf(s.id, s.section, f.label, typeName(f.type), f.column ?: "NO RULE",
                f.options.joinToString("; "), f.options.filter { it in f.tried }.joinToString("; "),
                f.untried().joinToString("; ")).joinToString(",") { q(it) }).append('\n')
        }
    }

    fun toJson(): String = Json.write(linkedMapOf(
        "form" to formName, "explored" to started, "finished" to finishedReason,
        "screens" to screens.values.map { s ->
            linkedMapOf("id" to s.id, "section" to s.section, "end" to s.isEnd, "passes" to s.passes.toList(), "shots" to s.shots,
                "notes" to s.notes.toList(),
                "questions" to s.fields.map { f -> linkedMapOf("type" to typeName(f.type), "label" to f.label, "column" to f.column,
                    "options" to f.options, "tried" to f.tried.toList()) },
                "leads_to" to edges.filter { it.from == s.no }.map { linkedMapOf("answers" to it.answers, "to" to (byNo(it.to)?.id ?: "")) })
        },
        "routes" to routes.map { r -> linkedMapOf("pass" to r.pass, "end" to r.end, "seconds" to r.seconds,
            "steps" to r.steps.map { st -> linkedMapOf("screen" to (byNo(st.screen)?.id ?: ""), "answers" to st.answers) }) },
    ))

    companion object {
        fun typeName(t: String) = when (t) {
            "radio" -> "single choice"; "check" -> "multiple choice"; "spinner" -> "dropdown"; "edit" -> "text/number"; "date" -> "date"; else -> t
        }
    }
}
