package com.surveytest.agent

import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.surveytest.agent.core.Json
import com.surveytest.agent.core.Rules

/** Edit the question rules (rules.json) without rebuilding the app. */
class RulesActivity : AppCompatActivity() {
    private lateinit var ed: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Question rules"
        val pad = (12 * resources.displayMetrics.density).toInt()
        ed = EditText(this).apply {
            setText(AppStore.rulesText(this@RulesActivity)); typeface = Typeface.MONOSPACE; textSize = 12f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setHorizontallyScrolling(true); gravity = Gravity.TOP or Gravity.START; setPadding(pad, pad, pad, pad)
        }
        val editor = ScrollView(this).apply {
            addView(HorizontalScrollView(this@RulesActivity).apply { addView(ed) })
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(pad / 2, pad / 2, pad / 2, pad / 2) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        bar.addView(btn("Check") { check() }); bar.addView(btn("Save") { save() })
        bar.addView(btn("Reset") { reset() }); bar.addView(btn("Help") { help() })
        setContentView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(bar); addView(editor) })
    }

    private fun msg(t: String, m: String) { AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("OK", null).show() }

    private fun validate(): Rules? = try { Rules.parse(ed.text.toString()) } catch (e: Json.JsonError) { msg("Problem in the rules", e.message ?: ""); null }
        catch (e: Exception) { msg("Problem in the rules", e.toString()); null }

    private fun check() {
        val r = validate() ?: return
        val d = AppStore.dataset(this)
        val missing = if (d == null) emptyList() else r.plainColumns().filter { c -> d.records.none { it.containsKey(c) } }
        msg("Rules look fine", "${r.rules.size} rules. App: ${r.packageName}. Form: ${r.formName}." +
            if (missing.isNotEmpty()) "\n\nThese columns are not in your test data (check spelling):\n" + missing.joinToString("\n") else "")
    }

    private fun save() {
        validate() ?: return
        AppStore.saveRulesText(this, ed.text.toString()); AppStore.put(this, "formName", "")
        msg("Saved", "The new rules are used from the next run.")
    }

    private fun reset() {
        AlertDialog.Builder(this).setMessage("Go back to the built-in rules? Your changes will be lost.")
            .setPositiveButton("Reset") { _, _ -> AppStore.resetRules(this); ed.setText(AppStore.defaultRulesText(this)) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun help() {
        val tv = TextView(this).apply {
            textSize = 13f; setPadding(48, 24, 48, 24); setTextIsSelectable(true)
            text = """
How the agent finds answers

Each screen of the form has a section title (the grey path at the top, e.g. "B. Energy access > B9. Kerosene") and question texts. The agent turns both into lower case and goes down the "rules" list. The FIRST rule that matches decides which column of the test data answers that question.

A rule:
  { "section": null, "question": "^a1\\.", "column": "A1_Sex" }

• question: a pattern for the question text. ^ means "starts with". A dot must be written \\. (two backslashes in this file).
• section: a pattern for the section part after the second ">", or null for any section.
• column: the test-data column to type or select.
   ""  = leave the question blank
   "@appliance:Number_owned" = value from the appliances sheet, for the appliance named in the section
   "@source_role" / "@source_amount" = B9 energy-source screens (Primary/Backup and amount)
   "@main_appliance:_rated_W" = C1b screens ("main appliance 1/2")

Other settings
• formName / packageName: which form and app to open (Kobo: org.koboc.collect.android).
• lastQuestion: pattern for the form's last question (default "^e3\\." = E3 enumerator note). If that screen will not move on, the agent goes to the save screen instead of throwing the form away. "" turns this off.
• prefixes: text put in front of a column's value, e.g. "[TEST] " for the enumerator note.
• breadcrumbStartsWith: start of the section title, so it is not mistaken for a question.

Multiple-choice answers in the data are separated with "; ". Options are matched by their visible text (close spelling is accepted).

To add a new question: copy a rule line, change the pattern and the column, tap Check, then Save. Rules higher in the list win, so put specific rules above general ones (e.g. "^b4a\\." above "^b4\\.").
""".trimIndent()
        }
        AlertDialog.Builder(this).setTitle("Rules help").setView(ScrollView(this).apply { addView(tv) }).setPositiveButton("Close", null).show()
    }
}
