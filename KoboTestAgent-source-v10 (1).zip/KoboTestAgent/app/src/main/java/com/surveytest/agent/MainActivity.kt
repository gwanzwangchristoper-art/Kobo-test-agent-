package com.surveytest.agent

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.surveytest.agent.core.DataGen
import com.surveytest.agent.core.Dataset
import com.surveytest.agent.core.parseRange
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var txtService: TextView
    private lateinit var txtKobo: TextView
    private lateinit var txtData: TextView
    private lateinit var edForm: EditText
    private lateinit var edRange: EditText
    private lateinit var rgSpeed: RadioGroup
    private lateinit var cbMdy: CheckBox
    private lateinit var cbAuto: CheckBox
    private lateinit var cbKeepGoing: CheckBox
    private lateinit var txtSpeedName: TextView
    private lateinit var txtImported: TextView
    private val ui = Handler(Looper.getMainLooper())

    /** Speed buttons 1-5 and their names. */
    private val speeds = listOf(
        Triple(R.id.sp1, "slow", "1 = Slow: long pauses, for checking by eye"),
        Triple(R.id.sp2, "normal", "2 = Normal: short pauses between answers"),
        Triple(R.id.sp3, "fast", "3 = Fast: no extra pauses, normal waits"),
        Triple(R.id.sp4, "super", "4 = Super: as fast as the phone allows"),
        Triple(R.id.sp5, "ultra", "5 = Ultra: every wait 7 times shorter than Super"),
    )
    private fun speedName(): String = speeds.firstOrNull { it.first == rgSpeed.checkedRadioButtonId }?.second ?: "fast"

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { importFile(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        txtService = findViewById(R.id.txtService); txtKobo = findViewById(R.id.txtKobo); txtData = findViewById(R.id.txtData)
        edForm = findViewById(R.id.edForm); edRange = findViewById(R.id.edRange); rgSpeed = findViewById(R.id.rgSpeed); cbMdy = findViewById(R.id.cbMdy)

        edRange.setText(AppStore.get(this, "range", "1"))
        txtSpeedName = findViewById(R.id.txtSpeedName); txtImported = findViewById(R.id.txtImported)
        rgSpeed.setOnCheckedChangeListener { _, id ->
            speeds.firstOrNull { it.first == id }?.let { txtSpeedName.text = it.third; AppStore.put(this, "speed", it.second) }
        }
        val saved = AppStore.get(this, "speed", "fast")
        rgSpeed.check(speeds.firstOrNull { it.second == saved }?.first ?: R.id.sp3)
        txtSpeedName.text = speeds.firstOrNull { it.first == rgSpeed.checkedRadioButtonId }?.third ?: ""
        findViewById<CheckBox>(R.id.cbStrict).isChecked = AppStore.get(this, "strict", "1") == "1"
        cbMdy.isChecked = AppStore.get(this, "dateOrder", "dmy") == "mdy"
        cbAuto = findViewById(R.id.cbAuto); cbAuto.isChecked = AppStore.get(this, "auto", "1") == "1"
        cbKeepGoing = findViewById(R.id.cbKeepGoing); cbKeepGoing.isChecked = AppStore.get(this, "keepGoing", "1") == "1"
        findViewById<CheckBox>(R.id.cbAsk).isChecked = AppStore.get(this, "ask", "1") == "1"
        findViewById<Button>(R.id.btnRecord).setOnClickListener { record() }

        findViewById<Button>(R.id.btnA11y).setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        findViewById<Button>(R.id.btnAppInfo).setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
        }
        findViewById<Button>(R.id.btnGenerate).setOnClickListener { generate() }
        findViewById<Button>(R.id.btnImport).setOnClickListener { pickFile.launch(arrayOf("*/*")) }
        findViewById<Button>(R.id.btnPreview).setOnClickListener { preview() }
        findViewById<Button>(R.id.btnViewData).setOnClickListener { AppStore.dataset(this)?.let { showDataTable(it, null) } ?: toast("No test data yet") }
        findViewById<Button>(R.id.btnStart).setOnClickListener { startRun() }
        findViewById<Button>(R.id.btnLog).setOnClickListener { showText("Log (latest at the bottom)", AppStore.logTail(this), scrollToEnd = true) }
        findViewById<Button>(R.id.btnShare).setOnClickListener { shareReport() }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            AlertDialog.Builder(this).setMessage("Clear the log and snapshots?").setPositiveButton("Clear") { _, _ -> AppStore.clearLog(this); toast("Log cleared") }
                .setNegativeButton("Cancel", null).show()
        }
        findViewById<Button>(R.id.btnRules).setOnClickListener { startActivity(Intent(this, RulesActivity::class.java)) }
        findViewById<Button>(R.id.btnViewForm).setOnClickListener { viewForm() }
        findViewById<Button>(R.id.btnShareViewForm).setOnClickListener { shareViewForm() }
        txtImported.setOnLongClickListener {
            AlertDialog.Builder(this).setMessage("Clear the list of imported files? (Your test data stays loaded.)")
                .setPositiveButton("Clear") { _, _ -> AppStore.clearImported(this); refresh() }.setNegativeButton("Cancel", null).show(); true
        }
    }

    override fun onResume() {
        super.onResume()
        if (!edForm.hasFocus()) edForm.setText(AppStore.rules(this).formName)
        refresh()
    }

    private fun refresh() {
        val on = AgentService.instance != null
        txtService.text = if (on) "✅ Agent is ON (Accessibility)" else "❌ Agent is OFF — tap the button below, find Kobo Test Agent, switch it on"
        val rules = AppStore.rules(this)
        val kobo = packageManager.getLaunchIntentForPackage(rules.packageName) != null
        txtKobo.text = if (kobo) "✅ KoboCollect found (${rules.packageName})" else "❌ ${rules.packageName} is not installed"
        val d = AppStore.dataset(this)
        txtData.text = if (d == null) "No test data yet. Generate or import." else "✅ ${d.records.size} records, ${d.appliances.size} appliance rows (${d.source})"
        val files = AppStore.imported(this)
        txtImported.text = if (files.isEmpty()) "No files imported yet." else
            "Files imported (newest first, hold to clear):\n" + files.joinToString("\n") { f ->
                val inUse = d != null && d.source.contains(f["name"] ?: "\u0000")
                "• ${f["name"]}  -  ${f["summary"]}  -  ${f["time"]}" + if (inUse) "  (in use)" else ""
            }
        findViewById<TextView>(R.id.txtViewForm).text = AppStore.lastExploreZip(this)?.let { "Last zip: ${it.name}" } ?: ""
    }

    private fun generate() {
        val n = findViewById<EditText>(R.id.edCount).text.toString().toIntOrNull()?.coerceIn(1, 1000) ?: return toast("Type how many records")
        val seed = findViewById<EditText>(R.id.edSeed).text.toString().toLongOrNull() ?: 1L
        val preset = findViewById<CheckBox>(R.id.cbPreset).isChecked
        val d = DataGen(seed, preset).generate(n)
        AppStore.saveDataset(this, d); setRangeToAll(d); refresh(); toast("Generated ${d.records.size} test records")
    }

    private fun importFile(uri: Uri) {
        // reading a big .xlsx can take a few seconds: do it off the screen thread, with a "Reading…" box
        val wait = AlertDialog.Builder(this).setTitle("Reading the file…").setView(ProgressBar(this).apply { setPadding(0, 40, 0, 40) })
            .setCancelable(false).show()
        Thread {
            try {
                var name = "file"
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: name }
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IllegalArgumentException("Could not read the file")
                val (d, msg) = Dataset.import(name, bytes, AppStore.dataset(this))
                AppStore.saveDataset(this, d)
                AppStore.addImported(this, name, "${d.records.size} records, ${d.appliances.size} appliance rows")
                ui.post {
                    wait.dismiss()
                    if (isFinishing || isDestroyed) return@post
                    setRangeToAll(d)
                    // your own file: fill any gaps with realistic answers, and don't pause on every blank
                    cbAuto.isChecked = true; AppStore.put(this, "auto", "1")
                    findViewById<CheckBox>(R.id.cbAsk).isChecked = false; AppStore.put(this, "ask", "0")
                    refresh(); showDataTable(d, msg)
                }
            } catch (e: Throwable) {
                ui.post {
                    wait.dismiss()
                    if (isFinishing || isDestroyed) return@post
                    AlertDialog.Builder(this).setTitle("Import failed").setMessage(e.message ?: e.toString()).setPositiveButton("OK", null).show()
                }
            }
        }.apply { name = "import" }.start()
    }

    /** Show the loaded file as a scrollable table: every record, every column (appliances below). */
    private fun showDataTable(d: Dataset, message: String?) {
        val pad = (6 * resources.displayMetrics.density).toInt()
        fun cell(t: String, head: Boolean) = TextView(this).apply {
            text = t; textSize = 12f; setPadding(pad, pad / 2, pad, pad / 2); maxWidth = (220 * resources.displayMetrics.density).toInt()
            if (head) { setTypeface(typeface, android.graphics.Typeface.BOLD); setBackgroundColor(0x221E6B4E) }
        }
        val maxRows = 150
        fun table(all: List<Map<String, String>>): TableLayout {
            val rows = all.take(maxRows)
            val cols = LinkedHashSet<String>(); all.forEach { cols.addAll(it.keys) }
            return TableLayout(this).apply {
                addView(TableRow(this@MainActivity).apply { cols.forEach { addView(cell(it, true)) } })
                rows.forEachIndexed { i, r ->
                    addView(TableRow(this@MainActivity).apply {
                        if (i % 2 == 1) setBackgroundColor(0x0F000000)
                        cols.forEach { addView(cell(r[it] ?: "", false)) }
                    })
                }
            }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad * 2, pad, pad * 2, pad)
            addView(TextView(this@MainActivity).apply {
                text = (message?.let { "$it\n" } ?: "") + "${d.records.size} records · ${d.records.firstOrNull()?.size ?: 0} columns · ${d.appliances.size} appliance rows · ${d.source}\nScroll sideways to see all columns." +
                    if (d.records.size > maxRows || d.appliances.size > maxRows) "\nShowing the first $maxRows rows of each table (all rows are used in runs)." else ""
                textSize = 13f; setPadding(0, 0, 0, pad)
            })
            addView(TextView(this@MainActivity).apply { text = "Responses"; setTypeface(typeface, android.graphics.Typeface.BOLD) })
            addView(HorizontalScrollView(this@MainActivity).apply { addView(table(d.records)) })
            if (d.appliances.isNotEmpty()) {
                addView(TextView(this@MainActivity).apply { text = "\nAppliances (C1)"; setTypeface(typeface, android.graphics.Typeface.BOLD) })
                addView(HorizontalScrollView(this@MainActivity).apply { addView(table(d.appliances)) })
            }
        }
        AlertDialog.Builder(this).setTitle(if (message != null) "File loaded" else "Test data")
            .setView(ScrollView(this).apply { addView(box) }).setPositiveButton("Close", null).show()
    }

    private fun setRangeToAll(d: Dataset) {
        val ids = d.ids(); if (ids.isEmpty()) return
        val r = if (ids.size == 1) "${ids[0]}" else "${ids.first()}-${ids.last()}"
        edRange.setText(r); AppStore.put(this, "range", r)
    }

    private fun preview() {
        val d = AppStore.dataset(this) ?: return toast("No test data yet")
        val id = try { parseRange(edRange.text.toString(), d.ids()).first() } catch (e: Exception) { d.ids().first() }
        val rec = d.record(id) ?: return
        val body = rec.filter { it.value.isNotEmpty() }.entries.joinToString("\n") { "${it.key}: ${it.value}" } +
            "\n\nAppliances:\n" + d.appliancesFor(id).joinToString("\n") { "• ${it["Appliance"]}: owned ${it["Number_owned"]}, working ${it["Number_working_W"]}, partly ${it["Number_partly_working_PW"]}" }
        showText("Record $id", body)
    }

    private fun startRun() {
        val svc = AgentService.instance ?: return AlertDialog.Builder(this).setTitle("Agent is off")
            .setMessage("Turn on Kobo Test Agent in Accessibility settings first (step 1).").setPositiveButton("OK", null).show().let { }
        val d = AppStore.dataset(this) ?: return toast("Generate or import test data first")
        val ids = try { parseRange(edRange.text.toString(), d.ids()) } catch (e: Exception) { return toast(e.message ?: "Bad record list") }
        val form = edForm.text.toString().trim()
        if (form.isEmpty()) return toast("Type the form name")
        AppStore.put(this, "formName", form); AppStore.put(this, "range", edRange.text.toString())
        val speed = speedName()
        AppStore.put(this, "speed", speed)
        val dateOrder = if (cbMdy.isChecked) "mdy" else "dmy"; AppStore.put(this, "dateOrder", dateOrder)
        val delay = mapOf("ultra" to 0L, "super" to 0L, "fast" to 0L, "normal" to 150L, "slow" to 500L)[speed] ?: 0L
        val strict = findViewById<CheckBox>(R.id.cbStrict).isChecked; AppStore.put(this, "strict", if (strict) "1" else "0")
        val ask = findViewById<CheckBox>(R.id.cbAsk).isChecked; AppStore.put(this, "ask", if (ask) "1" else "0")
        val keepGoing = cbKeepGoing.isChecked; AppStore.put(this, "keepGoing", if (keepGoing) "1" else "0")
        val autoAnswer = cbAuto.isChecked; AppStore.put(this, "auto", if (autoAnswer) "1" else "0")
        AlertDialog.Builder(this).setTitle("Start test run?")
            .setMessage("Fill ${ids.size} form(s) in '$form', one after another, with TEST answers. Each is saved as a DRAFT, then a new form is started.\n\nKeep the phone unlocked and don't touch the screen while it works. Use the bubble to pause or stop.")
            .setPositiveButton("Start") { _, _ -> (AgentService.instance ?: svc).start(ids, delay, dateOrder, autoAnswer, keepGoing, speed, strict, ask)?.let { toast(it) } }
            .setNegativeButton("Cancel", null).show()
    }

    /** "View form": click through every route of the form, save every screen, make a zip. */
    private fun viewForm() {
        val svc = AgentService.instance ?: return AlertDialog.Builder(this).setTitle("Agent is off")
            .setMessage("Turn on Kobo Test Agent in Accessibility settings first (step 1).").setPositiveButton("OK", null).show().let { }
        val form = edForm.text.toString().trim()
        if (form.isEmpty()) return toast("Type the form name (step 3)")
        AppStore.put(this, "formName", form)
        val speed = speedName()
        val pad = (16 * resources.displayMetrics.density).toInt()
        val passes = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(AppStore.get(this@MainActivity, "viewPasses", "12")) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad * 3 / 2, pad / 2, pad * 3 / 2, 0)
            addView(TextView(this@MainActivity).apply {
                text = "The agent opens '$form' again and again. Each time it chooses answers it has not tried yet (every option, Yes and No, numbers like 0), " +
                    "so every page and branch is reached. Every new screen is saved with a screenshot.\n\n" +
                    "Nothing is saved in KoboCollect: each pass is left with 'Ignore changes'. At the end a zip is saved to Downloads/KoboTestAgent.\n\n" +
                    "Speed: ${speeds.firstOrNull { it.second == speed }?.third ?: speed}\n\nMost passes (it stops sooner when nothing new is found):"
                textSize = 14f
            })
            addView(passes)
        }
        AlertDialog.Builder(this).setTitle("View form").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Start") { _, _ ->
                val n = passes.text.toString().toIntOrNull()?.coerceIn(1, 200) ?: 12
                AppStore.put(this, "viewPasses", n.toString())
                val dateOrder = if (cbMdy.isChecked) "mdy" else "dmy"
                (AgentService.instance ?: svc).explore(n, speed, dateOrder)?.let { toast(it) }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun shareViewForm() {
        val zip = AppStore.lastExploreZip(this) ?: return toast("No View form zip yet - tap View form first")
        val dir = File(cacheDir, "share").apply { mkdirs() }
        val copy = File(dir, zip.name)
        try { zip.copyTo(copy, overwrite = true) } catch (e: Exception) { return toast("Could not prepare the zip: ${e.message}") }
        val uri = FileProvider.getUriForFile(this, "$packageName.files", copy)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Share View form zip"))
    }

    private fun record() {
        val svc = AgentService.instance ?: return toast("Turn the agent on first (step 1)")
        AlertDialog.Builder(this).setTitle("Record screens")
            .setMessage("KoboCollect will open. Fill ONE form by hand from start to the end screen (use test answers). The app saves each new screen: a screenshot, its layout and how the agent reads it.\n\nWhen done, tap 'Stop recording' on the bubble, come back here and tap 'Share log + snapshots'. Tip: tap 'Clear log' first so only this recording is shared.")
            .setPositiveButton("Start recording") { _, _ ->
                svc.startRecording()?.let { return@setPositiveButton toast(it) }
                packageManager.getLaunchIntentForPackage(AppStore.rules(this).packageName)?.let { startActivity(it) }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun shareReport() {
        val dir = File(cacheDir, "share").apply { mkdirs() }
        val zip = File(dir, "kobo_agent_report.zip")
        val files = listOfNotNull(AppStore.logFile(this).takeIf { it.exists() }) + (AppStore.snapshotDir(this).listFiles()?.filter { it.isFile }?.toList() ?: emptyList())
        if (files.isEmpty()) return toast("Nothing to share yet")
        ZipOutputStream(zip.outputStream()).use { z ->
            for (f in files) { z.putNextEntry(ZipEntry(f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry() }
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.files", zip)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Share log + snapshots"))
    }

    private fun showText(title: String, text: String, scrollToEnd: Boolean = false) {
        val tv = TextView(this).apply { setText(text); setTextIsSelectable(true); textSize = 12f; setPadding(40, 20, 40, 20); typeface = android.graphics.Typeface.MONOSPACE }
        val sv = ScrollView(this).apply { addView(tv) }
        if (scrollToEnd) sv.post { sv.fullScroll(ScrollView.FOCUS_DOWN) }
        AlertDialog.Builder(this).setTitle(title).setView(sv).setPositiveButton("Close", null).show()
    }

    private fun toast(s: String) { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
}
