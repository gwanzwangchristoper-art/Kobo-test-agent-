package com.surveytest.agent

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import com.surveytest.agent.core.Dataset
import com.surveytest.agent.core.FormMap
import com.surveytest.agent.core.Json
import com.surveytest.agent.core.Rules
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Where the app keeps its rules, test data, settings and log. */
object AppStore {
    private fun prefs(c: Context) = c.getSharedPreferences("agent", Context.MODE_PRIVATE)

    fun defaultRulesText(c: Context): String = c.assets.open("rules.json").bufferedReader().use { it.readText() }
    fun rulesText(c: Context): String = File(c.filesDir, "rules.json").takeIf { it.exists() }?.readText() ?: defaultRulesText(c)
    fun saveRulesText(c: Context, text: String) { Rules.parse(text); File(c.filesDir, "rules.json").writeText(text) }
    fun resetRules(c: Context) { File(c.filesDir, "rules.json").delete() }

    /** Store a rule learned from an answer given by hand (top of the list, so it wins). */
    @Synchronized fun saveLearned(c: Context, pattern: String, value: String) {
        try {
            @Suppress("UNCHECKED_CAST")
            val root = LinkedHashMap(Json.parse(rulesText(c)) as Map<String, Any?>)
            val rules = ArrayList((root["rules"] as? List<*>) ?: emptyList<Any?>())
            rules.removeAll { (it as? Map<*, *>)?.get("question") == pattern }
            rules.add(0, linkedMapOf("section" to null, "question" to pattern, "column" to "=$value", "learned" to true))
            root["rules"] = rules
            saveRulesText(c, Json.write(root))
        } catch (_: Exception) {}
    }

    /** Rules with the form name / app chosen on the main screen applied on top. */
    fun rules(c: Context): Rules {
        val r = try { Rules.parse(rulesText(c)) } catch (e: Exception) { Rules.parse(defaultRulesText(c)) }
        prefs(c).getString("formName", null)?.takeIf { it.isNotBlank() }?.let { r.formName = it }
        return r
    }

    fun dataset(c: Context): Dataset? = File(c.filesDir, "dataset.json").takeIf { it.exists() }?.let {
        try { Dataset.fromJson(it.readText()) } catch (e: Exception) { null }
    }
    fun saveDataset(c: Context, d: Dataset) = File(c.filesDir, "dataset.json").writeText(d.toJson())

    fun get(c: Context, k: String, def: String) = prefs(c).getString(k, def) ?: def
    fun put(c: Context, k: String, v: String) = prefs(c).edit().putString(k, v).apply()

    // ---------------- log
    fun logFile(c: Context) = File(c.getExternalFilesDir(null) ?: c.filesDir, "agent_log.csv")
    fun snapshotDir(c: Context) = File(c.getExternalFilesDir(null) ?: c.filesDir, "snapshots").apply { mkdirs() }
    private val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    @Synchronized fun log(c: Context, record: Int, kind: String, key: String, value: String, note: String) {
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val f = logFile(c)
        if (!f.exists()) f.writeText("time,record,kind,question,value,note\n")
        f.appendText(listOf(ts.format(Date()), record.toString(), kind, key, value, note).joinToString(",") { q(it) } + "\n")
    }
    fun logTail(c: Context, lines: Int = 300): String = logFile(c).takeIf { it.exists() }?.readLines()?.takeLast(lines)?.joinToString("\n") ?: "(log is empty)"
    fun clearLog(c: Context) { logFile(c).delete(); snapshotDir(c).listFiles()?.forEach { it.delete() } }

    // ---------------- files imported (shown under the Import button)
    /** Remember an imported file: newest first, one line per file name, at most 15. */
    fun addImported(c: Context, name: String, summary: String) {
        val now = SimpleDateFormat("d MMM HH:mm", Locale.US).format(Date())
        val list = imported(c).filter { it["name"] != name }.toMutableList()
        list.add(0, mapOf("name" to name, "summary" to summary, "time" to now))
        put(c, "imported", Json.write(list.take(15), pretty = false))
    }
    fun imported(c: Context): List<Map<String, String>> = try {
        (Json.parse(get(c, "imported", "[]")) as? List<*>)?.mapNotNull { e -> (e as? Map<*, *>)?.entries?.associate { it.key.toString() to (it.value?.toString() ?: "") } } ?: emptyList()
    } catch (_: Exception) { emptyList() }
    fun clearImported(c: Context) = put(c, "imported", "[]")

    // ---------------- "View form" output
    fun exploreWorkDir(c: Context) = File(c.getExternalFilesDir(null) ?: c.filesDir, "view_form").apply { mkdirs() }
    fun clearExploreWork(c: Context) { exploreWorkDir(c).deleteRecursively(); exploreWorkDir(c) }
    fun lastExploreZip(c: Context): File? = get(c, "lastExploreZip", "").takeIf { it.isNotEmpty() }?.let { File(it) }?.takeIf { it.exists() }

    /**
     * Write the View form zip (form map, routes, questions list, screenshots), keep it in the app and copy it to
     * Downloads/KoboTestAgent. Returns the zip and a plain description of where it is.
     */
    fun writeExploreZip(c: Context, map: FormMap, stamp: String): Pair<File, String> {
        val safe = map.formName.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').take(40).ifEmpty { "form" }
        val name = "view_form_${safe}_$stamp.zip"
        val outDir = File(c.getExternalFilesDir(null) ?: c.filesDir, "exports").apply { mkdirs() }
        val zip = File(outDir, name)
        ZipOutputStream(zip.outputStream().buffered()).use { z ->
            fun text(entry: String, body: String) { z.putNextEntry(ZipEntry(entry)); z.write(body.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            text("README.txt", "View form - ${map.formName}\n\nform_map.txt   every screen, question, option, data column and where each answer leads\n" +
                "routes.txt     each pass through the form with the answers used\nquestions.csv  one row per question (open in Excel) - use it to build accurate test data\n" +
                "form_map.json  the same for other tools\nscreens/       screenshot (.jpg) and text reading (.txt) of every screen, named S001, S002 ... as in form_map.txt\n\n" +
                "Nothing was saved in KoboCollect: every pass was left with 'Ignore changes'.\n")
            text("form_map.txt", map.formMapText())
            text("routes.txt", map.routesText())
            text("questions.csv", "\uFEFF" + map.questionsCsv())
            text("form_map.json", map.toJson())
            val shots = File(exploreWorkDir(c), "screens").listFiles()?.sortedBy { it.name } ?: emptyList()
            for (f in shots) { z.putNextEntry(ZipEntry("screens/" + f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry() }
        }
        put(c, "lastExploreZip", zip.absolutePath)
        var where = "the app (tap 'Share View form zip')"
        try {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/KoboTestAgent")
            }
            val uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                c.contentResolver.openOutputStream(uri)?.use { out -> zip.inputStream().use { it.copyTo(out) } }
                where = "Downloads/KoboTestAgent"
            }
        } catch (_: Exception) {}
        return zip to where
    }
}
