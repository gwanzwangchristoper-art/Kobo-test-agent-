package com.surveytest.agent

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.text.InputType
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.surveytest.agent.core.Control
import com.surveytest.agent.core.Dataset
import com.surveytest.agent.core.Device
import com.surveytest.agent.core.Engine
import com.surveytest.agent.core.FormMap
import com.surveytest.agent.core.Reporter
import com.surveytest.agent.core.Timing
import com.surveytest.agent.core.UiNode
import com.surveytest.agent.core.explain
import com.surveytest.agent.core.sameValue
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * The accessibility service: reads KoboCollect's screen and taps/types on it.
 * It only acts while a test run (or View form) is going; the rest of the time it does nothing.
 */
class AgentService : AccessibilityService() {
    companion object {
        @Volatile var instance: AgentService? = null
        @Volatile var running = false
        @Volatile var recording = false

        /** Speed names used in the app: 1 slow, 2 normal, 3 fast, 4 super, 5 ultra. */
        fun timing(speed: String): Timing = when (speed) { "super" -> Timing.SUPER; "ultra" -> Timing.ULTRA; else -> Timing.NORMAL }
    }
    private var recCount = 0
    private var lastRecSig = ""
    private var recPending = false
    private var recPkg = ""

    private val ui = Handler(Looper.getMainLooper())
    private var bubble: Bubble? = null
    private var control: Control? = null
    private var wake: PowerManager.WakeLock? = null
    /** Scales the agent's own short pauses (typing fallback) to the chosen speed. */
    @Volatile private var pauseFactor = 1.0
    /** Android allows about one screenshot every 1/3 second. */
    @Volatile private var lastShot = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        bubble = Bubble(this,
            onPauseToggle = { control?.let { it.paused = !it.paused; it.paused } ?: false },
            onStop = { if (recording) stopRecording() else { control?.stopped = true; control?.paused = false } },
            onClose = { bubble?.hide() })
        // The green accessibility shortcut button: show Pause / Continue instead of switching the agent off
        try {
            accessibilityButtonController.registerAccessibilityButtonCallback(object : AccessibilityButtonController.AccessibilityButtonCallback() {
                override fun onClicked(controller: AccessibilityButtonController) { ui.post { onShortcutButton() } }
            })
        } catch (_: Exception) {}
    }

    private fun onShortcutButton() {
        if (running || recording) bubble?.expand()
        else startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Keep the screen on and bright for the whole run, like a video player. */
    @Suppress("DEPRECATION")
    private fun keepScreenOn(on: Boolean) {
        try {
            if (on) {
                if (wake?.isHeld == true) return
                val pm = getSystemService(PowerManager::class.java)
                wake = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE, "KoboTestAgent:run")
                    .apply { setReferenceCounted(false); acquire(8 * 60 * 60 * 1000L) }
            } else { wake?.let { if (it.isHeld) it.release() }; wake = null }
        } catch (_: Exception) {}
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!recording || event == null || event.packageName?.toString() != recPkg) return
        if (!recPending) { recPending = true; ui.postDelayed({ recPending = false; captureScreen() }, 900) }
    }

    // ---------------------------------------------------------------- "Record screens" mode
    /** You fill a form by hand; every new KoboCollect screen is saved (layout + screenshot + how the agent reads it). */
    fun startRecording(): String? {
        if (running) return "Stop the test run first"
        recPkg = AppStore.rules(this).packageName
        recording = true; recCount = 0; lastRecSig = ""
        AppStore.log(this, 0, "INFO", "", "", "recording screens started")
        bubble?.showRecording()
        return null
    }

    fun stopRecording() {
        if (!recording) return
        recording = false
        AppStore.log(this, 0, "INFO", "", "", "recording stopped: $recCount screens saved")
        bubble?.finished("Saved $recCount screens. In the app tap 'Share log + snapshots' and send the zip.")
    }

    private fun captureScreen() {
        if (!recording) return
        val dev = AndroidDevice()
        if (dev.currentPackage() != recPkg) return
        val node = dev.root() ?: return
        val sig = node.signature()
        if (sig == lastRecSig) return
        lastRecSig = sig; recCount++
        val name = "screen_%03d".format(recCount)
        try { File(AppStore.snapshotDir(this), "$name.txt").writeText(explain(node, AppStore.rules(this))) } catch (_: Exception) {}
        dev.snapshot(name, null, textToo = false)
        bubble?.update(0, recCount, 0, "Saved screen $recCount. Keep filling the form by hand.", false)
    }
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean { shutdown(); return super.onUnbind(intent) }
    override fun onDestroy() { shutdown(); super.onDestroy() }
    private fun shutdown() { control?.stopped = true; recording = false; keepScreenOn(false); bubble?.hide(); instance = null }

    private fun reporter(ctl: Control) = object : Reporter {
        override fun status(record: Int, done: Int, total: Int, text: String) { ui.post { bubble?.update(record, done, total, text, ctl.paused) } }
        override fun log(record: Int, kind: String, key: String, value: String, note: String) = AppStore.log(this@AgentService, record, kind, key, value, note)
        override fun askHuman(record: Int, done: Int, total: Int, text: String) { ui.post { bubble?.ask(record, done, total, text) } }
        override fun learned(pattern: String, value: String) = AppStore.saveLearned(this@AgentService, pattern, value)
    }

    /** Starts a run. Returns an error message, or null when it started. */
    fun start(ids: List<Int>, delayMs: Long, dateOrder: String, autoAnswer: Boolean, keepGoing: Boolean, speed: String, strict: Boolean, askWhenStuck: Boolean): String? {
        if (running) return "A run is already going"
        if (ids.isEmpty()) return "No records chosen"
        if (recording) stopRecording()
        val data = AppStore.dataset(this) ?: return "No test data yet - generate or import it first"
        val rules = AppStore.rules(this)
        if (packageManager.getLaunchIntentForPackage(rules.packageName) == null) return "${rules.packageName} is not installed"
        val ctl = Control(); control = ctl; running = true
        val t = timing(speed); pauseFactor = t.factor
        AppStore.log(this, 0, "INFO", "", "", "run started: records ${ids.first()}..${ids.last()} (${ids.size}), form '${rules.formName}', speed $speed")
        bubble?.show(ids.size)
        keepScreenOn(true)
        Thread {
            val rep = reporter(ctl)
            var done = 0
            try {
                done = Engine(AndroidDevice(), rules, data, rep, ctl, delayMs = delayMs, dateOrder = dateOrder,
                    autoAnswer = autoAnswer, seed = System.currentTimeMillis(), keepGoing = keepGoing,
                    t = t, strict = strict, askWhenStuck = askWhenStuck).run(ids)
            } catch (e: Throwable) {
                rep.log(0, "ERROR", "", "", "agent crashed: $e")
            } finally {
                running = false
                ui.post { keepScreenOn(false) }
                AppStore.log(this, 0, "INFO", "", "", "run ended: $done of ${ids.size} saved as drafts")
                ui.post { bubble?.finished("$done of ${ids.size} saved as drafts") }
            }
        }.apply { name = "agent-run" }.start()
        return null
    }

    /**
     * "View form": click through every route of the form (several passes, different answers each time),
     * save every screen, and write a zip. Nothing is saved in KoboCollect. Returns an error message, or null.
     */
    fun explore(maxPasses: Int, speed: String, dateOrder: String): String? {
        if (running) return "A run is already going"
        if (recording) stopRecording()
        val rules = AppStore.rules(this)
        if (packageManager.getLaunchIntentForPackage(rules.packageName) == null) return "${rules.packageName} is not installed"
        val data = AppStore.dataset(this) ?: Dataset(listOf(mapOf("Record" to "1")), emptyList(), "none")
        val ctl = Control(); control = ctl; running = true
        val t = timing(speed); pauseFactor = t.factor
        val stamp = SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date())
        AppStore.clearExploreWork(this)
        AppStore.log(this, 0, "INFO", "", "", "View form started: form '${rules.formName}', up to $maxPasses passes, speed $speed")
        bubble?.show(maxPasses, explore = true)
        keepScreenOn(true)
        Thread {
            val rep = reporter(ctl)
            val map = FormMap(rules.formName, SimpleDateFormat("d MMM yyyy HH:mm", Locale.US).format(Date()))
            var msg = "View form failed - see the log"
            try {
                Engine(AndroidDevice(), rules, data, rep, ctl, delayMs = 0, dateOrder = dateOrder, autoAnswer = true,
                    seed = System.currentTimeMillis(), keepGoing = true, t = t).explore(maxPasses, map, "screens")
            } catch (e: Throwable) {
                rep.log(0, "ERROR", "", "", "View form crashed: $e")
                map.finishedReason = "the agent hit an error: $e"
            } finally {
                running = false
                ui.post { keepScreenOn(false) }
                try {
                    if (map.screens.isNotEmpty()) {
                        val (zip, where) = AppStore.writeExploreZip(this, map, stamp)
                        msg = "${map.screens.size} screens, ${map.questionCount()} questions in ${map.routes.size} passes. Zip saved to $where (${zip.name}). Nothing was saved in KoboCollect."
                    } else msg = "View form found no screens - check the form name. ${map.finishedReason}"
                } catch (e: Throwable) {
                    msg = "Could not write the View form zip: $e"; rep.log(0, "ERROR", "", "", msg)
                }
                AppStore.log(this, 0, "INFO", "", "", "View form ended: $msg")
                ui.post { bubble?.finished(msg) }
            }
        }.apply { name = "agent-view-form" }.start()
        return null
    }

    // ---------------------------------------------------------------- the phone, as the engine sees it
    /**
     * KoboCollect's window. Not simply the "active" window: right after you tap the bubble (Pause / Continue),
     * Android may treat the bubble as active, and the agent must still read the form under it.
     */
    private fun appRoot(): AccessibilityNodeInfo? {
        val active = rootInActiveWindow
        if (active != null && active.packageName?.toString() != packageName) return active
        val under = try {
            windows.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
                .sortedByDescending { it.layer }
                .firstNotNullOfOrNull { w -> w.root?.takeIf { it.packageName?.toString() != packageName } }
        } catch (_: Exception) { null }
        return under ?: active
    }

    private fun pause(ms: Long) = maxOf(1L, (ms * pauseFactor).toLong())

    inner class AndroidDevice : Device {
        override fun root(): UiNode? {
            val r = appRoot() ?: return null
            return try { convert(r, 0) } catch (_: Exception) { null }   // the screen can change while it is being read
        }

        override fun currentPackage(): String = try { appRoot()?.packageName?.toString() ?: "" } catch (_: Exception) { "" }

        private fun convert(n: AccessibilityNodeInfo, depth: Int): UiNode {
            val b = Rect(); n.getBoundsInScreen(b)
            val kids = ArrayList<UiNode>()
            if (depth < 60) for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                if (c.isVisibleToUser) kids.add(convert(c, depth + 1))
            }
            // an empty box reports its grey hint as its text: keep them apart, so "empty" really reads as empty
            val raw = n.text?.toString() ?: ""
            val hintOnly = n.isShowingHintText
            return UiNode(
                cls = n.className?.toString() ?: "", text = if (hintOnly) "" else raw,
                desc = n.contentDescription?.toString() ?: "", id = n.viewIdResourceName ?: "",
                left = b.left, top = b.top, right = b.right, bottom = b.bottom,
                checked = n.isChecked, scrollable = n.isScrollable, children = kids, ref = n,
                numeric = (n.inputType and InputType.TYPE_MASK_CLASS).let { it == InputType.TYPE_CLASS_NUMBER || it == InputType.TYPE_CLASS_PHONE },
                hint = if (hintOnly) raw else (n.hintText?.toString() ?: ""),
            )
        }

        /** The live element for `n`. If the screen was redrawn since it was read, find the same element again. */
        private fun live(n: UiNode): AccessibilityNodeInfo? {
            val node = n.ref as? AccessibilityNodeInfo ?: return null
            if (try { node.refresh() } catch (_: Exception) { false }) return node
            val r = appRoot() ?: return null
            return find(r, 0) { c ->
                val b = Rect(); c.getBoundsInScreen(b)
                c.className?.toString() == n.cls && b.left == n.left && b.top == n.top && b.right == n.right && b.bottom == n.bottom
            } ?: if (n.id.isNotEmpty()) find(r, 0) { c -> c.viewIdResourceName == n.id && (c.text?.toString() ?: "") == n.text } else null
        }

        private fun find(n: AccessibilityNodeInfo, depth: Int, p: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
            if (p(n)) return n
            if (depth > 60) return null
            for (i in 0 until n.childCount) { val c = n.getChild(i) ?: continue; find(c, depth + 1, p)?.let { return it } }
            return null
        }

        override fun click(n: UiNode): Boolean {
            val node = live(n) ?: return tap(n.cx, n.cy)
            var c: AccessibilityNodeInfo? = node
            while (c != null && !c.isClickable) c = c.parent
            val ok = try { (c ?: node).performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) { false }
            return ok || tap(n.cx, n.cy)
        }

        private fun tap(x: Int, y: Int): Boolean {
            if (x <= 0 && y <= 0) return false
            val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
            return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
        }

        private fun shown(x: AccessibilityNodeInfo): String {
            try { x.refresh() } catch (_: Exception) {}
            return if (x.isShowingHintText) "" else x.text?.toString() ?: ""
        }

        /** Type into a box and read it back. Tries: set text; focus + set text; paste from the clipboard. */
        override fun setText(n: UiNode, text: String): Boolean {
            val node = live(n) ?: return false
            val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
            if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args) && sameValue(shown(node), text)) return true
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS); Thread.sleep(pause(200))
            val again = live(n) ?: node
            if (again.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                Thread.sleep(pause(60))
                if (sameValue(shown(again), text)) return true
            }
            // last resort for boxes that ignore "set text": paste it
            return try {
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("answer", text))
                again.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                val sel = Bundle().apply {
                    putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
                    putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, shown(again).length)
                }
                again.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
                val ok = again.performAction(AccessibilityNodeInfo.ACTION_PASTE)
                Thread.sleep(pause(150))
                ok && sameValue(shown(again), text)
            } catch (_: Exception) { false }
        }

        override fun scrollForward(root: UiNode): Boolean {
            // long option lists (State, Community) can sit inside another scrolling view: try each one, biggest first
            val targets = root.walk().filter { it.scrollable && it.ref is AccessibilityNodeInfo }
                .sortedByDescending { (it.right - it.left).toLong() * (it.bottom - it.top) }.toList()
            for (t in targets) if (try { (t.ref as AccessibilityNodeInfo).performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) } catch (_: Exception) { false }) return true
            // last resort: a finger swipe up in the middle of the screen (the engine checks whether anything moved)
            val dm = resources.displayMetrics
            val x = dm.widthPixels * 0.5f
            val p = Path().apply { moveTo(x, dm.heightPixels * 0.72f); lineTo(x, dm.heightPixels * 0.32f) }
            return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(), null, null)
        }

        override fun back() { performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) }

        override fun keyboardShown(): Boolean = try { windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD } } catch (_: Exception) { false }

        override fun swipeNext(): Boolean {
            val dm = resources.displayMetrics
            val y = dm.heightPixels * 0.5f
            val p = Path().apply { moveTo(dm.widthPixels * 0.85f, y); lineTo(dm.widthPixels * 0.12f, y) }
            return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 220)).build(), null, null)
        }

        override fun launch(pkg: String): Boolean {
            val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(i); return true
        }

        override fun sleep(ms: Long) = Thread.sleep(ms)

        override fun snapshot(name: String, root: UiNode?) = snapshot(name, root, true)

        fun snapshot(name: String, root: UiNode?, textToo: Boolean) {
            val dir = AppStore.snapshotDir(this@AgentService)
            if (textToo) try { File(dir, "$name.txt").writeText(root?.let { explain(it, AppStore.rules(this@AgentService)) } ?: "(no screen)") } catch (_: Exception) {}
            val wait = 380 - (SystemClock.uptimeMillis() - lastShot)
            if (wait > 0) { ui.postDelayed({ shoot(File(dir, "$name.jpg"), null) }, wait) } else shoot(File(dir, "$name.jpg"), null)
        }

        /** "View form": save the text, then a screenshot without the bubble on it, and wait until it is written. */
        override fun capture(folder: String, name: String, root: UiNode?, text: String) {
            val dir = File(AppStore.exploreWorkDir(this@AgentService), folder).apply { mkdirs() }
            try { File(dir, "$name.txt").writeText(text) } catch (_: Exception) {}
            ui.post { bubble?.setHidden(true) }
            try {
                Thread.sleep(80)   // let the bubble leave the screen
                for (attempt in 0 until 3) {
                    val wait = 380 - (SystemClock.uptimeMillis() - lastShot)
                    if (wait > 0) Thread.sleep(wait)
                    val latch = CountDownLatch(1); var ok = false
                    ui.post { shoot(File(dir, "$name.jpg")) { success -> ok = success; latch.countDown() } }
                    latch.await(4, TimeUnit.SECONDS)
                    if (ok) break
                    Thread.sleep(400)
                }
            } finally { ui.post { bubble?.setHidden(false) } }
        }
    }

    /** Take a screenshot as a half-size JPEG. `done` (optional) is told whether it worked. Call on the main thread. */
    private fun shoot(file: File, done: ((Boolean) -> Unit)?) {
        lastShot = SystemClock.uptimeMillis()
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    var ok = false
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                        val full = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        // half size JPEG keeps the shared report small (a few MB instead of 70+)
                        val bmp = full?.let { Bitmap.createScaledBitmap(it, it.width / 2, it.height / 2, true) }
                        if (bmp != null) { FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, 70, it) }; ok = true }
                        hw?.recycle(); if (full != null && full !== bmp) full.recycle(); bmp?.recycle()
                    } catch (_: Exception) {
                    } finally { try { result.hardwareBuffer.close() } catch (_: Exception) {} }
                    lastShot = SystemClock.uptimeMillis()
                    done?.invoke(ok)
                }
                override fun onFailure(errorCode: Int) { lastShot = SystemClock.uptimeMillis(); done?.invoke(false) }
            })
        } catch (_: Exception) { done?.invoke(false) }
    }
}
