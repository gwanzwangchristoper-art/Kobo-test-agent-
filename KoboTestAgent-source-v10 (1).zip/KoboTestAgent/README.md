# Kobo Test Agent (Android)

Fills a **KoboCollect** form on the same phone with randomised **TEST** answers, by reading the screen and
tapping like a person (Android Accessibility). Built to test a form's skip logic and constraints before fieldwork.

- Saves every record as a **draft**. It never taps Finalize or Send, unticks "Mark form as finalized" on
  older versions, and refuses to save if a save screen only offers Finalize.
- The enumerator note (E3) is prefixed **[TEST]**.
- A floating bubble shows each step, with Pause/Resume and Stop. Drag it, or collapse it to a dot.
- Test data is generated in the app (count + seed), or imported from `.xlsx` (Responses + C1_Appliances sheets) or `.csv`.
- Question rules live in an editable `rules.json` (in-app editor with Check/Save/Reset/Help).
- Questions with no rule are answered automatically by type (single/multi choice, dropdown, number, text, date),
  avoiding Other / Don't know; if the form refuses to move on it fills blanks and tries other numbers. Logged as AUTO.
- **Record screens** mode: fill one form by hand; the app saves each KoboCollect screen (screenshot, layout and how
  the agent reads it) to share for improving rules.

## Changes in v10
- **Speed 1-5**: the speed buttons are now numbers; tapping one shows its name under them
  (1 Slow, 2 Normal, 3 Fast, 4 Super, **5 Ultra**). Ultra makes every wait 7 times shorter than Super.
  Pickers and pop-ups now wait for the screen to change instead of fixed pauses, so high speeds stay safe.
- **Imported files list**: the files you imported are listed right under "Import file" (newest first, the one in use is
  marked). Hold the list to clear it. Big files are read in the background, and the table shows the first 150 rows.
- **View form**: clicks through every page and branch of the form - several passes, each choosing options not tried
  before (Yes and No, every choice, numbers like 0, Other) - and saves a screenshot and text reading of every screen.
  Nothing is saved in KoboCollect (every pass is left with Ignore changes). The zip (Downloads/KoboTestAgent, or
  "Share View form zip") holds form_map.txt (every screen, question, option, data column, and where each answer
  leads), routes.txt, questions.csv (one row per question with its options and data column) and screens/.
- Fixed: the E3 note (last screen) could stay empty, and the whole form was then thrown away. Typed text is now read
  back and typed again if the phone lost it (then pasted as a last resort); if E3 still will not move on, the agent goes
  to the save screen and saves the DRAFT instead of discarding the form. Pattern: "lastQuestion" in the rules.
- Fixed: after you tapped Pause/Continue on the bubble, the agent could read the bubble instead of KoboCollect.
- Fixed: the agent never taps while another app is in front (it waits up to 20 s), and waits for KoboCollect to open
  before looking for the form (at high speed it could tap the form name inside this app).
- Fixed: a redrawn screen made taps and typing fail silently; the agent now finds the same element again.
- Fixed: empty boxes that show a grey hint were read as already answered.
- Fixed: after Next, a screen still sliding in was mistaken for "the form will not move on".
- Fixed: screenshots taken less than 1/3 s apart were lost; the collapsed dot turns amber when paused or waiting for you.
- Import: CSV files saved with ';' or tabs, column "record" in any case, and files without a Record column
  (rows are numbered) are accepted; old .xls files get a clear message. "Share log" no longer makes an empty zip.

## Changes in v9
- Fixed: runs paused with "your data value is not offered" on long lists (State, Community...) even though the right
  option was already selected. The agent now remembers what it answered on each screen while it scrolls.
- No placeholders: questions not in the file get an answer that fits the question (a trade for "what kind of work",
  a reason for "why", naira amounts for prices, hours for hours...). Logged as AUTO. The E3 [TEST] note stays.
- Test data has answers for the open questions (A9 kind of work, other income, B4c, C4, other unmet need, units).
- Importing a file turns on gap-filling and turns off pausing; a value not offered by the form is logged and the closest
  option is used (tick Strict to pause instead).
- After importing, the file is shown as a table; "View data (table)" shows it any time.

## Changes in v8
- Long option lists (State, Community): if a scroll command does nothing, a finger swipe is used, and the agent keeps
  searching down the list for your value (fixes skipped location screens).
- "Make up answers for questions not in my file" is switched off automatically when you import a file.
- Pause and ask me when stuck (default on): when a question is not in your data, your value is not offered, or the form
  will not move on, the run pauses on that screen (bubble turns amber, phone vibrates). Answer it, tap Continue.
  Answers to questions with no rule are saved as rules (column "=your answer") and used for the next forms.
- Generated appliances are partly working or broken more often, so the PW / NW counts get real values.

## Changes in v7
- FCT preset generator: communities in equal blocks (Kilankwa I, then Kilankwa II, then Petti) with one enumerator
  code each: FCT001, FCT002, FCT003.

## Changes in v6
- The green accessibility shortcut button no longer switches the agent off: during a run it opens the bubble
  with Pause / Continue / Stop; when idle it opens the app.
- Screen stays on and bright for the whole run (wake lock, like a video player), released when the run ends.

## Changes in v5
- Gets past the last question (E2 photograph), which has no Next button: closes the keyboard, swipes, or uses
  "Go to end" in the question list, then taps **Save as draft** (never Finalize). This was why runs stopped and saved nothing.
- Strict mode (default on): follows the test data exactly; when a data value is not an option it logs MISMATCH
  instead of choosing something else. AUTO answers only for questions with no data column.
- Pause works within a fraction of a second; the bubble turns amber and says PAUSED.
- Screen stays awake during a run (no lock part-way through a batch).
- Super speed: minimal waits; answers are still read back from the screen before Next.
- Each saved form logs a summary: seconds taken, answers from data, automatic answers, mismatches.
- Test data: approximate price paid for the main appliances (C1b).

## Changes in v4
- Batch runs: "1-50" fills 50 forms one after another, each saved as a draft; the range is filled in after generating/importing.
- Keep going: a form that cannot be completed is left WITHOUT saving (Ignore changes) and the next one starts;
  stops after 3 failures in a row. Never continues a half-filled form left open from before.
- Faster: shorter waits throughout; Fast is the default speed.
- FCT preset (default on): Household Energy survey, FCT, Kwali, Kilankwa I / Kilankwa II / Petti with the matching NEP site,
  FCT001, WP5.2, consent Yes, Male; variation starts after that.
- Rules read State, LGA, Community, Enumerator_code and Project_site from the data ("~Column": automatic if empty).
- Option matching no longer confuses "Kilankwa I" with "Kilankwa II".

## Changes in v3 (from the recorded KoboCollect v2026.3 screens)
- Dropdowns shown as a text box ("Select Answer") are opened and answered (fixes the stop at "Select Instrument Section").
- Remembers the section and question title after scrolling, so rules keep matching on long screens.
- New rules: instrument section, work package, location/enumerator/site (auto), A9 follow-ups, C1a main energy source
  and number not working. Rule columns can be "=fixed text" or "@auto".
- If a test-data value is not among a question's options, a sensible option is chosen instead of leaving it empty.
- Screenshots are saved as small JPEGs so the shared report stays small.

## Changes in v2
- Fixed: the KoboCollect toolbar Save icon was mistaken for the end-of-form screen (run stopped with
  "still on the save screen after tapping draft").
- Dropdown ("minimal") questions, automatic answers for unknown questions, retries on required/limit errors,
  Record screens mode.

## Install on the phone (Android 11+, tested target Android 14)
1. Open the repo's **Releases** page on the phone, download `KoboTestAgent.apk`, open it and allow
   "Install unknown apps" for your browser/files app when asked.
2. Open **Kobo Test Agent** → *Turn on the agent* → find *Kobo Test Agent* → switch on.
   If the switch is greyed out ("Restricted setting"): in the app tap *Open app info* → **⋮** (top right)
   → **Allow restricted settings** → go back and switch it on.
3. Generate test records, type the form name exactly as KoboCollect shows it, choose records (start with `1`), tap **Start**.
4. After a run, check KoboCollect → **Drafts**. Share the log + snapshots from the app if anything stops.

## Build
Every push to `main` builds the APK with GitHub Actions and publishes it as a release (`.github/workflows/build.yml`).
Local build: Android Studio, or `gradle assembleDebug` with JDK 17 + Android SDK 34.

## Code
- `core/` plain Kotlin, no Android: screen parser, answer planner, run engine (draft-only), View form explorer + form map, rules, generator, xlsx/csv import.
- `AgentService` accessibility service (reads/taps KoboCollect), `Bubble` overlay, `MainActivity`, `RulesActivity`.
- `core-tests/` run the engine (and View form, on a form with skip logic) against a simulated KoboCollect on a normal JVM.
